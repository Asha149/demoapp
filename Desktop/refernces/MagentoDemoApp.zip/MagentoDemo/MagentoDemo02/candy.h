//
//  candy.h
//  SearchBarDemoStoryBoard
//
//  Created by ajeet Singh on 27/02/14.
//  Copyright (c) 2014 ajeet Singh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface candy : NSObject {
    NSString *category;
    NSString *name;
}

@property (nonatomic, copy) NSString *category;
@property (nonatomic, copy) NSString *name;

+ (id)candyOfCategory:(NSString*)category name:(NSString*)name;

@end
