//
//  OffersVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 07/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface OffersVC : UIViewController
{
    UIButton *btnLeftMenu,*btnCart;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;

@end
