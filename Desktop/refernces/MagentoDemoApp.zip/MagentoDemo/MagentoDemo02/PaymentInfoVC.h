//
//  PaymentInfoVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface PaymentInfoVC : UIViewController <UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate,UIPickerViewDataSource,UIPickerViewDelegate,UITextFieldDelegate>
{
    UIButton *btnLeftMenu,*btnCart,*btnBack,*btnContinue;
    UITableView *tblPaymentMethods;
    UIScrollView *Scroll;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart,*btnBack,*btnContinue;
@property (nonatomic,retain) IBOutlet UITableView *tblPaymentMethods;
@property (nonatomic,retain) IBOutlet UIScrollView *Scroll;
@property (nonatomic,retain) IBOutlet UIPickerView *pkCardType;
@property (nonatomic,retain) IBOutlet UIPickerView *pkMonth;
@property (nonatomic,retain) IBOutlet UIPickerView *pkYear;
@property (nonatomic,retain) IBOutlet UITextField *txtCardNumber;
@property (nonatomic,retain) IBOutlet UITextField *txtCCId;

@property (nonatomic,retain) NSMutableArray *arrCCType;
@property (nonatomic,retain) NSMutableArray *arrCType;
@property (nonatomic,retain) NSMutableArray *arrDigitMonth;

@property (nonatomic,retain) NSMutableArray *arrMonth;
@property (nonatomic,retain) NSMutableArray *arrYear;
@property (nonatomic,retain) IBOutlet UILabel *lblCardType;
@property (nonatomic,retain) IBOutlet UILabel *lblMonth;
@property (nonatomic,retain) IBOutlet UILabel *lblYear;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnBack:(id)sender;
-(IBAction)btnContinueClick:(id)sender;
@end
