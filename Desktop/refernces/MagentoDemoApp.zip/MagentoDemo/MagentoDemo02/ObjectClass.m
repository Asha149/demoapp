//
//  ObjectClass.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 06/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "ObjectClass.h"

@implementation ObjectClass

@synthesize MainCategoryTitle,MainCategoryID,SubCategoryID,SubCategoryTitle,SubCategoryAttribID,ProductID,ProductTitle,ProductPrice,ProductDesc,ProductAttribID,ProductImagePath,PID,ShippingMethodName,ShippingIsActive,PaymentMethodName,PaymentIsActive;
@synthesize coFirstName,coLastName,coCompany,coEmailAddress,coAddress,coCity,coState,coZipCode,coCountry,coTelephone,coFax,coShipFirstName,coShipLastName,coShipCompany,coShipEmailAddress,coShipAddress,coShipCity,coShipState,coShipZipCode,coShipCountry,coShipTelephone,coShipFax,coAs,coShipTo,coUseBilling,coShippingMethod,coPaymentMethod,coOrderId,coGrandTotal;
@synthesize ProductImage;
@synthesize arrProImages;

    @synthesize strShippingPrice;
    @synthesize strOrderID;

@synthesize strCardType,strCCCid,strCCMonth,strCCNumber,strCCYear;

-(id)initWithTask:(NSString *)task
{
    NSString *str;
    str = task;
    return self;
}

@end
