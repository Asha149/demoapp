//
//  candy.m
//  SearchBarDemoStoryBoard
//
//  Created by ajeet Singh on 27/02/14.
//  Copyright (c) 2014 ajeet Singh. All rights reserved.
//

#import "candy.h"

@implementation candy
@synthesize category;
@synthesize name;

+ (id)candyOfCategory:(NSString *)category name:(NSString *)name
{
    candy *newCandy = [[self alloc] init];
    newCandy.category = category;
    newCandy.name = name;
    return newCandy;
}

@end
