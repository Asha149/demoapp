//
//  MainMenuCell.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 12/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "MainMenuCell.h"

@implementation MainMenuCell
@synthesize lblTitle;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
