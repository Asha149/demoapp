//
//  COMethodVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "COMethodVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"
#import "MyCartVC.h"
#import "BillingInfoVC.h"
#import "RegistrationVC.h"
#import "AppDelegate.h"
#import "ObjectClass.h"

@interface COMethodVC ()

@end

@implementation COMethodVC
@synthesize btnLeftMenu,btnCart,btnLogin,btnContinue,btnAsGuest,btnRegister,checked,Scroll;
@synthesize txtEmailAddress,txtPassword;
AppDelegate *app;
NSString *str;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    [Scroll setContentSize:CGSizeMake(Scroll.frame.size.width, Scroll.frame.size.height+10)];
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    checked=@"unchecked";
}


#pragma mark
#pragma mark - Button Clicks Methods...
-(IBAction)btnLeftMenuClick:(id)sender
{
    str=@"menu";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnCartClick:(id)sender
{
    str=@"cart";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnLoginClick:(id)sender
{
    UIAlertView *CheckAlert = [[UIAlertView alloc]initWithTitle:@"Some Fields are Empty"
                                                        message:@"..."
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
    [CheckAlert setDelegate:self];
    [CheckAlert setTitle:@"Warning"];
    NSLog(@"btnLoginClick");
    NSString *textEmailAddress= [txtEmailAddress.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textPassword= [txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (textEmailAddress.length==0 || textPassword.length==0)
    {
        if (textEmailAddress.length==0)
        {
            [CheckAlert setMessage:@"Please Enter UserName"];
        }
        else if (textPassword.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Password"];
        }
        else
        {
            [CheckAlert setMessage:@"Some Fields are Blank"];
        }
        [CheckAlert show];
    }
    else
    { NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
        [param setValue:txtEmailAddress.text forKey:@"email"];
        // [param setValue:textPassword forKey:@"password"];
        WebApiController *obj=[[WebApiController alloc]init];
        [obj callAPI_GET:@"LoginUser.php" andParams:param SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
        [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
    }
}
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"Json dictionary :: %@",jsonDictionary);
    NSString *EntityID = [jsonDictionary valueForKey:@"customer_id"];
    if (EntityID == nil)
    {
        UIAlertView *CheckAlert = [[UIAlertView alloc]initWithTitle:@"Warning"
                                                            message:@"Email id or Password mismatch"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil, nil];
        [CheckAlert show];
        txtPassword.text = @"";
    }
    else
    {
        app.UserFname=[jsonDictionary valueForKey:@"firstname"];
        app.strCustomer_id = [jsonDictionary valueForKey:@"customer_id"];
        NSLog(@"user name :: %@",app.UserFname);
        NSLog(@"Customer_id :: %@",app.strCustomer_id);
        BillingInfoVC *objVC = [[BillingInfoVC alloc] initWithNibName:@"BillingInfoVC" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
        ObjectClass *obj = [[ObjectClass alloc]init];
        obj.coAs=app.UserFname;
        app.COArr = [[NSMutableArray alloc]init];
        [app.COArr addObject:obj];
        //        NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
        //        [param setValue:EntityID forKey:@"eid"];
        //        WebApiController *obj=[[WebApiController alloc]init];
        //        [obj callAPI_GET:@"getFname.php" andParams:param SuccessCallback:@selector(service_reponse2:Response:) andDelegate:self];
        [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
    }
    [SVProgressHUD dismiss];
}
-(void)service_reponse2:(NSString *)apiAlias Response:(NSData *)response
{
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    app.UserFname = [[jsonDictionary objectAtIndex:0]valueForKey:@"First_Name"];
    [SVProgressHUD dismiss];
    
    NSString *textEmailAddress= [txtEmailAddress.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];    
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj.coAs=textEmailAddress;
    app.COArr = [[NSMutableArray alloc]init];
    [app.COArr addObject:obj];
    
    BillingInfoVC *objVC = [[BillingInfoVC alloc] initWithNibName:@"BillingInfoVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:objVC animated:YES];
    [objVC release];
}
-(IBAction)btnContinueClick:(id)sender
{
    if ([checked isEqualToString:@"register"])
    {
        RegistrationVC *objVC = [[RegistrationVC alloc] initWithNibName:@"RegistrationVC" bundle:[NSBundle mainBundle]];
        objVC.From = @"checkout";
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
    }
    else if ([checked isEqualToString:@"Guest"])
    {
        ObjectClass *obj = [[ObjectClass alloc]init];
        obj.coAs=@"Guest";
        app.COArr = [[NSMutableArray alloc]init];
        [app.COArr addObject:obj];
        NSLog(@"arr : %@", app.COArr);
        BillingInfoVC *objVC = [[BillingInfoVC alloc] initWithNibName:@"BillingInfoVC" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
    }
    else
    {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Warning"
                              message:@"Please Select any Method to CheckOut"
                              delegate:self
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil,
                              nil];
        [alert show];
    }
    
}
-(IBAction)btnAsGuestClick:(id)sender
{
    checked=@"Guest";
    [btnAsGuest setBackgroundImage:[UIImage imageNamed:@"RadioChecked.png"] forState:UIControlStateNormal];
    [btnRegister setBackgroundImage:[UIImage imageNamed:@"RadioUnchecked.png"] forState:UIControlStateNormal];
}
-(IBAction)btnRegisterClick:(id)sender
{
    checked=@"register";
    [btnAsGuest setBackgroundImage:[UIImage imageNamed:@"RadioUnchecked.png"] forState:UIControlStateNormal];
    [btnRegister setBackgroundImage:[UIImage imageNamed:@"RadioChecked.png"] forState:UIControlStateNormal];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"YES"])
    {
        if ([str isEqualToString:@"menu"])
        {
            LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
            [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
            [obj release];
        }
        else if ([str isEqualToString:@"cart"])
        {
            MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:obj animated:YES];
            [obj release];
        }
        
    }
    else if([title isEqualToString:@"NO"])
    {
        NSLog(@"Button 2 was selected.");
    }
}


#pragma mark
#pragma mark - TextField Methods...
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlUp animations:^{
        CGRect rc = [textField bounds];
        rc = [textField convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = 170 ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlDown animations:^{
        CGRect rc = [textField bounds];
        rc = [textField convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = 0 ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
