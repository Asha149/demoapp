//
//  OrderPlacedVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 20/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface OrderPlacedVC : UIViewController <UITableViewDelegate,UITableViewDataSource,UIScrollViewDelegate>
{
    UIButton *btnLeftMenu,*btnCart,*btnBack;
    UILabel *OrderID,*lblBillName,*lblBillAddress,*lblBillState,*lblBillCountry,*lblBillTelephone,*lblShipName,*lblShipAddress,*lblShipState,*lblShipCountry,*lblShipTelephone;
    sqlite3 *_database;
    UITableView *tblOrderDetails;
    UILabel *lblEmptyCart,*lblGT,*lblShipppingMethod,*lblShippingCharges;
    UIScrollView *Scroll;
    UIView *GrandTotalView,*ViewContainingTable;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart,*btnBack;
@property (nonatomic,retain) IBOutlet UILabel *OrderID,*lblBillName,*lblBillAddress,*lblBillState,*lblBillCountry,*lblBillTelephone,*lblShipName,*lblShipAddress,*lblShipState,*lblShipCountry,*lblShipTelephone;
@property (nonatomic,retain) IBOutlet UITableView *tblOrderDetails;
@property (nonatomic,retain) IBOutlet UILabel *lblEmptyCart,*lblGT,*lblShipppingMethod,*lblShippingCharges;
@property (nonatomic,retain) IBOutlet UIScrollView *Scroll;
@property (nonatomic,retain) IBOutlet UIView *GrandTotalView,*ViewContainingTable;
@property (nonatomic,retain) NSString *From,*PassedOrderID;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnBack:(id)sender;
@end
