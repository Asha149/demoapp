//
//  Header.h
//  ShoppingCart
//
//  Created by ajeet Singh on 06/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#ifndef ShoppingCart_Header_h
#define ShoppingCart_Header_h

#define SERVERNAME   @"http://localhost/project01/"

#endif
