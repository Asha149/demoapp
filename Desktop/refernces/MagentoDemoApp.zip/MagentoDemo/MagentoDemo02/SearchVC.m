
//
//  Created by ajeet Singh on 07/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "SearchVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "MyCartVC.h"
#import "candy.h"

@interface SearchVC ()

@end

@implementation SearchVC
{
    NSArray *recipes;
    NSArray *searchResults;
}
@synthesize btnLeftMenu,btnCart;
@synthesize tableView = _tableView;
@synthesize candyArray;
@synthesize filteredCandyArray;
@synthesize candySearchBar;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    //candyArray = [[NSArray alloc]init];
    //filteredCandyArray = [[NSMutableArray alloc]init];
    candyArray = [NSArray arrayWithObjects:
                  [candy candyOfCategory:@"chocolate" name:@"chocolate bar"],
                  [candy candyOfCategory:@"chocolate" name:@"chocolate chip"],
                  [candy candyOfCategory:@"chocolate" name:@"dark chocolate"],
                  [candy candyOfCategory:@"hard" name:@"lollipop"],
                  [candy candyOfCategory:@"hard" name:@"candy cane"],
                  [candy candyOfCategory:@"hard" name:@"jaw breaker"],
                  [candy candyOfCategory:@"other" name:@"caramel"],
                  [candy candyOfCategory:@"other" name:@"sour chew"],
                  [candy candyOfCategory:@"other" name:@"peanut butter cup"],
                  [candy candyOfCategory:@"other" name:@"gummi bear"], nil];
    NSLog(@"candy array :: %@",candyArray);
    // Reload the table
    self.filteredCandyArray = [NSMutableArray arrayWithCapacity:[candyArray count]];
    
    candySearchBar.delegate = self;
//    candySearchBar.searchResultsDataSource = self;
//    candySearchBar.searchResultsDelegate = self;
    [self.tableView reloadData];
}

-(IBAction)btnLeftMenuClick:(id)sender
{
    LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
    [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
    [obj release];
}
-(IBAction)btnCartClick:(id)sender
{
    MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:obj animated:YES];
    [obj release];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    return (interfaceOrientation != UIInterfaceOrientationPortraitUpsideDown);
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        return [filteredCandyArray count];
    } else {
        return [candyArray count];
    }
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if ( cell == nil ) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    // Create a new Candy Object
    candy *candy = nil;
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        candy = [filteredCandyArray objectAtIndex:indexPath.row];
    } else {
        candy = [candyArray objectAtIndex:indexPath.row];
    }
    // Configure the cell
    cell.textLabel.text = candy.name;
    [cell setAccessoryType:UITableViewCellAccessoryDisclosureIndicator];
    return cell;}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (tableView == self.searchDisplayController.searchResultsTableView) {
        [self performSegueWithIdentifier: @"showRecipeDetail" sender: self];
    }
}

//- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
//    if ([segue.identifier isEqualToString:@"showRecipeDetail"]) {
//        RecipeDetailViewController *destViewController = segue.destinationViewController;
//        
//        NSIndexPath *indexPath = nil;
//        if ([self.searchDisplayController isActive]) {
//            indexPath = [self.searchDisplayController.searchResultsTableView indexPathForSelectedRow];
//            destViewController.recipeName = [searchResults objectAtIndex:indexPath.row];
//            
//        } else {
//            indexPath = [self.tableView indexPathForSelectedRow];
//            destViewController.recipeName = [recipes objectAtIndex:indexPath.row];
//        }
//    }
//    
//}

#pragma mark Content Filtering
-(void)filterContentForSearchText:(NSString*)searchText scope:(NSString*)scope {
    // Update the filtered array based on the search text and scope.
    // Remove all objects from the filtered search array
    [self.filteredCandyArray removeAllObjects];
  //  filteredCandyArray = [[NSMutableArray alloc]init];
    // Filter the array using NSPredicate
    NSPredicate *predicate = [NSPredicate predicateWithFormat:@"SELF.name contains[c] %@",searchText];
    NSLog(@"search text :: %@",searchText);
    NSLog(@"filter candy array :: %@",filteredCandyArray);

    NSLog(@"candy array :: %@",candyArray);
    filteredCandyArray = [NSMutableArray arrayWithArray:[candyArray filteredArrayUsingPredicate:predicate]];
}

#pragma mark - UISearchDisplayController Delegate Methods
-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchString:(NSString *)searchString {
    // Tells the table data source to reload when text changes
    [self filterContentForSearchText:searchString scope:
     [[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:[self.searchDisplayController.searchBar selectedScopeButtonIndex]]];
    // Return YES to cause the search result table view to be reloaded.
    return YES;
}

-(BOOL)searchDisplayController:(UISearchDisplayController *)controller shouldReloadTableForSearchScope:(NSInteger)searchOption {
    // Tells the table data source to reload when scope bar selection changes
    [self filterContentForSearchText:self.searchDisplayController.searchBar.text scope:
     [[self.searchDisplayController.searchBar scopeButtonTitles] objectAtIndex:searchOption]];
    // Return YES to cause the search result table view to be reloaded.
    return YES;
}
@end
