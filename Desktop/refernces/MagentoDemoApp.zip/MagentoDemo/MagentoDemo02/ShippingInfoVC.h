//
//  ShippingInfoVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShippingInfoVC : UIViewController <UITextFieldDelegate>
{
    UIButton *btnLeftMenu,*btnCart,*btnBack,*btnContinue,*btnUseBillingInfo;
    UITextField *txtFirstName,*txtLastName,*txtCompany,*txtEmailAddress,*txtCity,*txtState,*txtZipCode,*txtCountry,*txtTelephone,*txtFax;
    UITextView *txtAddress;
    UIScrollView *Scroll;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart,*btnBack,*btnContinue,*btnUseBillingInfo;
@property (nonatomic,retain) IBOutlet UITextField *txtFirstName,*txtLastName,*txtCompany,*txtEmailAddress,*txtCity,*txtState,*txtZipCode,*txtCountry,*txtTelephone,*txtFax;
@property (nonatomic,retain) IBOutlet UITextView *txtAddress;
@property (nonatomic,retain) IBOutlet UIScrollView *Scroll;
@property (nonatomic,retain) NSString *textFirstName,*textLastName,*textCompany,*textEmailAddress,*textAddress,*textCity,*textState,*textZipCode,*textCountry,*textTelephone,*textFax,*checked;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnBack:(id)sender;
-(IBAction)btnContinueClick:(id)sender;
-(IBAction)btnUseBillingInfoClick:(id)sender;
@end
