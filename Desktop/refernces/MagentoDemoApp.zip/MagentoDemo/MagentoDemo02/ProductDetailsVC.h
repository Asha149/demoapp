//
//  ProductDetailsVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 09/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZZFlipsideViewController.h"
#import "PayPalMobile.h"
#import <MessageUI/MessageUI.h>
#import <Twitter/Twitter.h>
#import "Facebook.h"
#import "FBConnect.h"
#import "ProductsVC.h"

@interface ProductDetailsVC : UIViewController <UIScrollViewDelegate, MFMailComposeViewControllerDelegate,FBDialogDelegate,FBLoginDialogDelegate,FBRequestDelegate,FBSessionDelegate,PayPalPaymentDelegate, ZZFlipsideViewControllerDelegate, UIPopoverControllerDelegate>
{
    UIButton *btnLeftMenu,*btnCart,*btnBuy,*btnAddtoCart,*btnShare,*btnZoom,*btnFacebook,*btnTwitter,*btnEmail,*btnCancel,*btnBack,*btnLoginLink;
    UILabel *lblProductName,*lblProductPrice,*lblProductDesc,*lblProductDiscount,*lblGeneralSpec;
    UIImageView *imgProductImage;
    UIView *SharePopUpView;
    UIImageView *tempImageView;
    UIScrollView *Scroll;
    UILabel *lblHeading;
    
    ///FB-TWitter-Email...
    TWTweetComposeViewController *tweetSheet;
    int currentAPICall;
    UITableView *friends_tblvw;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart,*btnBuy,*btnAddtoCart,*btnShare,*btnZoom,*btnFacebook,*btnTwitter,*btnEmail,*btnCancel,*btnBack,*btnLoginLink;
@property (nonatomic,retain) IBOutlet UILabel *lblProductName,*lblProductPrice,*lblProductDesc,*lblProductDiscount,*lblGeneralSpec;
@property (nonatomic,retain) IBOutlet UIImageView *imgProductImage;
@property (nonatomic, retain) IBOutlet UIView *SharePopUpView;
@property (nonatomic, retain) IBOutlet UIImageView *tempImageView;
@property (nonatomic,retain) IBOutlet UIScrollView *Scroll;
@property (nonatomic, retain) IBOutlet UILabel *lblHeading;
@property (nonatomic,retain) NSString *ProductID,*ProductAttribID,*ProductRow,*From,*HeadingName;
@property (nonatomic,retain) IBOutlet UIButton *btnMulImages;
//integration
@property (nonatomic, retain) Facebook *facebook;
@property (nonatomic,retain) IBOutlet UITableView *friends_tblvw;

///PayPal...
@property(nonatomic, strong, readwrite) UIPopoverController *flipsidePopoverController;
@property(nonatomic, strong, readwrite) NSString *environment;
@property(nonatomic, assign, readwrite) BOOL acceptCreditCards;
@property(nonatomic, strong, readwrite) PayPalPayment *completedPayment;
@property (nonatomic)NSInteger selectedTag;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnBuyClick:(id)sender;
-(IBAction)btnAddtoCartClick:(id)sender;
-(IBAction)btnShareClick:(id)sender;
-(IBAction)btnZoomClick:(id)sender;
-(IBAction)btnFacebookClick:(id)sender;
-(IBAction)btnTwitterClick:(id)sender;
-(IBAction)btnEmailClick:(id)sender;
-(IBAction)btnCancelClick:(id)sender;
-(IBAction)btnBack:(id)sender;
-(IBAction)btnLoginLinkClick:(id)sender;
-(IBAction)btnMulImage_click:(id)sender;
@end
