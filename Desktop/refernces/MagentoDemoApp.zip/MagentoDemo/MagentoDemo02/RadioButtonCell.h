//
//  RadioButtonCell.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 20/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RadioButtonCell : UITableViewCell
{
    UILabel *lblMethod;
    UIButton *btnRadio;
}
@property (nonatomic,retain) IBOutlet UILabel *lblMethod;
@property (nonatomic,retain) IBOutlet UIButton *btnRadio;;
@end
