//
//  SubCategoryVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 07/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "SubCategoryVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"
#import "ObjectClass.h"
#import "AppDelegate.h"
#import "ProductsVC.h"
#import "MyCartVC.h"
#import "LoginVC.h"
#import "SubCatClass.h"
#import "ThirdCategoryVC.h"

@interface SubCategoryVC ()

@end

@implementation SubCategoryVC
@synthesize btnLeftMenu,btnCart,btnBack,MainCategoryID,tblSubCategories,btnLoginLink,lblHeading,HeadingName;
@synthesize intThirdCatCount;
    
AppDelegate *app;
int selectedIndex;

    
- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    NSLog(@"MainCategoryID = %@",MainCategoryID);
    lblHeading.text=HeadingName;
    intThirdCatCount = [[NSMutableArray alloc]init];
    if (!(app.UserFname.length==0))
        [btnLoginLink setTitle:app.UserFname forState:UIControlStateNormal];
    
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    app.SubCategoryObjArr = [[NSMutableArray alloc]init];
    WebApiController *obj=[[WebApiController alloc]init];
    
    NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
    [param setValue:MainCategoryID forKey:@"pid"];
    
    [obj callAPI_GET:@"webservice.php" andParams:param SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
}
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    
    
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"Json dictionary :: %@",jsonDictionary);
   // NSLog(@"parent id :: %@",[[[[[[[jsonDictionary valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"] objectAtIndex:0] valueForKey:@"parent_id"]);
    
    if ([[[jsonDictionary valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"]) {
        
        
        NSMutableArray *arrCat=[[NSMutableArray alloc]init];
        
        arrCat=[[[jsonDictionary valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"];
        
        
        for (int i=0; i<[arrCat count]; i++)
        {
            if ([[arrCat objectAtIndex:i] objectForKey:@"category_id"])
            {
                if ([MainCategoryID isEqualToString:[[arrCat objectAtIndex:i] objectForKey:@"category_id"]]) {
                    
                    NSMutableArray *arrSubCat=[[NSMutableArray alloc]init];
                    
                    if ([[arrCat objectAtIndex:i]  valueForKey:@"children"]) {
                        arrSubCat=[[arrCat objectAtIndex:i]  valueForKey:@"children"];
                        for (int j=0; j<[arrSubCat count]; j++)
                        {
                            SubCatClass *obj = [[SubCatClass alloc]init];
                            [obj setStrSubCategoryId:[[arrSubCat objectAtIndex:j] objectForKey:@"category_id"]];
                            [obj setStrSubCategory:[[arrSubCat objectAtIndex:j] objectForKey:@"name"]];
                            [obj setStrParentId:[[arrSubCat objectAtIndex:j] objectForKey:@"parent_id"]];
                          
                            [intThirdCatCount addObject:[NSString stringWithFormat:@"%d",[[[arrSubCat objectAtIndex:j]objectForKey:@"children"] count] ]];
                            
                            [app.SubCategoryObjArr addObject:obj];
                        }
                        
                    
                        
                    }
                }
                
            }
            
            
        }
        
    }
    [tblSubCategories reloadData];
    [SVProgressHUD dismiss];
}
-(IBAction)btnCartClick:(id)sender
{
    MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:obj animated:YES];
    [obj release];
}
-(IBAction)btnLoginLinkClick:(id)sender
{
    if (app.UserFname.length==0)
    {
        LoginVC *objVC = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
    }
}
-(IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}

#pragma
#pragma mark - TableView Methods...
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [app.SubCategoryObjArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    SubCatClass *obj = [[SubCatClass alloc]init];
    obj=[app.SubCategoryObjArr objectAtIndex:[indexPath row]];
    cell.textLabel.text=obj.strSubCategory;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    selectedIndex = [[intThirdCatCount objectAtIndex:indexPath.row]intValue];
    if(selectedIndex == 0)
    {
        SubCatClass *obj = [[SubCatClass alloc]init];
        obj=[app.SubCategoryObjArr objectAtIndex:[indexPath row]];
        ProductsVC *objVC = [[ProductsVC alloc] initWithNibName:@"ProductsVC" bundle:[NSBundle mainBundle]];
        objVC.SubCategoryID=obj.strSubCategoryId;
        objVC.strParentId = obj.strParentId;
        objVC.HeadingName=obj.strSubCategory;
        [self.navigationController pushViewController:objVC animated:YES];
        [obj release];
    }
    else
    {
        SubCatClass *obj = [[SubCatClass alloc]init];
        obj=[app.SubCategoryObjArr objectAtIndex:[indexPath row]];
         ThirdCategoryVC *vc = [[ThirdCategoryVC alloc] initWithNibName:@"ThirdCategoryVC" bundle:[NSBundle mainBundle]];
        vc.HeadingName = obj.strSubCategory;
        vc.MainCategoryID = MainCategoryID;
        vc.strSubCategoryId = obj.strSubCategoryId;
        
        [self.navigationController pushViewController:vc animated:YES];
    }
   
}

-(IBAction)btnLeftMenuClick:(id)sender
{
    LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
    [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
    [obj release];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
@end
