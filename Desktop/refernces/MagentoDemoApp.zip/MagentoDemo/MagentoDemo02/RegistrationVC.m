//
//  RegistrationVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 14/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "RegistrationVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"
#import "ObjectClass.h"
#import "AppDelegate.h"
#import "MyCartVC.h"
#import "LoginVC.h"
#import "COMethodVC.h"

@interface RegistrationVC ()

@end

@implementation RegistrationVC
@synthesize btnBack,btnCart;
@synthesize btnRegister,btnCancel;
@synthesize txtFirstName,txtLastName,txtEmailAddress,txtUserName,txtPassword,txtConfirmPass,From,Scroll;
AppDelegate *app;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    [Scroll setContentSize:CGSizeMake(Scroll.frame.size.width, Scroll.frame.size.height+5)];
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    app.ProductsObjArr = [[NSMutableArray alloc]init];
    
}
-(IBAction)btnRegisterClick:(id)sender
{
    UIAlertView *CheckAlert = [[UIAlertView alloc]initWithTitle:@"Some Fields are Empty"
                                                        message:@"..."
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
    [CheckAlert setDelegate:self];
    [CheckAlert setTitle:@"Warning"];
    NSLog(@"btnRegisterClick");
    NSString *textFirstName= [txtFirstName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textLastName= [txtLastName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textEmailAddress= [txtEmailAddress.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textUserName= [txtUserName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textPassword= [txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textConfirmPass= [txtConfirmPass.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (textFirstName.length==0 || textLastName.length==0 || textEmailAddress.length==0 || textUserName.length==0 || textPassword.length==0 || textConfirmPass.length==0)
    {
        if (textFirstName.length==0)
        {
            [CheckAlert setMessage:@"Please Enter First Name"];
        }
        else if (textLastName.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Last Name"];
        }
        else if (textEmailAddress.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Email Address"];
        }
        else if (textUserName.length==0)
        {
            [CheckAlert setMessage:@"Please Enter UserName"];
        }
        else if (textPassword.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Password"];
        }
        else if (textConfirmPass.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Confirm Password"];
        }
        else
        {
            [CheckAlert setMessage:@"Some Fields are Blank"];
        }
        [CheckAlert show];
    }
    else
    {
        BOOL isValid = [self NSStringIsValidEmail:textEmailAddress];
        if (isValid)
        {
            if ([textPassword isEqualToString:textConfirmPass])
            {
                NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
                
                [param setValue:textFirstName forKey:@"fname"];
                [param setValue:textLastName forKey:@"lname"];
                [param setValue:textEmailAddress forKey:@"email"];
                [param setValue:textPassword forKey:@"pwd"];
                
                WebApiController *obj=[[WebApiController alloc]init];
                [obj callAPI_GET:@"Registeration.php" andParams:param SuccessCallback:@selector(service_reponse2:Response:) andDelegate:self];
                [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
            }
            else
            {
                [CheckAlert setMessage:@"Confirm Password didn't match with Passwrod"];
                [CheckAlert show];
            }
        }
        else
        {
            [CheckAlert setMessage:@"Please Enter Proper Email Address"];
            [CheckAlert show];
        }
    }
}
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    NSString *str=[[NSString alloc]initWithData:response encoding:NSUTF8StringEncoding];
    NSLog(@"Json dictionary :: %@",str);
    
    NSString *textFirstName= [txtFirstName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textLastName= [txtLastName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textEmailAddress= [txtEmailAddress.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textUserName= [txtUserName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textPassword= [txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if([str intValue] == 0)
    {
        NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
       
        [param setValue:textFirstName forKey:@"fname"];
        [param setValue:textLastName forKey:@"lname"];
        [param setValue:textEmailAddress forKey:@"email"];
        [param setValue:textPassword forKey:@"pwd"];
        
        WebApiController *obj=[[WebApiController alloc]init];
        [obj callAPI_GET:@"Registeration.php" andParams:param SuccessCallback:@selector(service_reponse2:Response:) andDelegate:self];
        [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
    }
    else
    {
        UIAlertView *CheckAlert = [[UIAlertView alloc]initWithTitle:@"Warning"
                                                            message:@"This Email Address already Exists"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil, nil];
        [CheckAlert show];
        txtEmailAddress.text=@"";
    }
    [SVProgressHUD dismiss];
}
-(void)service_reponse2:(NSString *)apiAlias Response:(NSData *)response
{
    [SVProgressHUD dismiss];
    NSString *str=[[NSString alloc]initWithData:response encoding:NSUTF8StringEncoding];
    NSLog(@"Json dictionary :: %@",str);

    UIAlertView *CheckAlert = [[UIAlertView alloc]initWithTitle:@"Register Successfully..."
                                                        message:@""
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
    [CheckAlert show];
    if ([From isEqualToString:@"login"])
    {
        LoginVC *objVC = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
    }
    else if ([From isEqualToString:@"checkout"])
    {
        COMethodVC *objVC = [[COMethodVC alloc] initWithNibName:@"COMethodVC" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
    }
    else
    {
        NSLog(@"Registered SuccessFully...");
    }
    
}
-(IBAction)btnCancelClick:(id)sender
{
    NSLog(@"btnCancelClick");
    [self.navigationController popViewControllerAnimated:YES];
}


-(IBAction)btnBackClick:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnCartClick:(id)sender
{
    MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:obj animated:YES];
    [obj release];
}
-(BOOL)NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}

-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    int y=0;
    if (textField==txtUserName)
    {
        y=50;
    }
    else if (textField==txtPassword)
    {
        y=120;
    }
    else if (textField==txtConfirmPass)
    {
        y=175;
    }
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlUp animations:^{
        CGRect rc = [textField bounds];
        rc = [textField convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = y ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    int y=0;
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlDown animations:^{
        CGRect rc = [textField bounds];
        rc = [textField convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = y ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    [textField resignFirstResponder];
    return YES;
}
    
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
