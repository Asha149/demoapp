//
//  ProductsVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 08/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZZFlipsideViewController.h"
#import "PayPalMobile.h"
#import <MessageUI/MessageUI.h>
#import <Twitter/Twitter.h>
#import "Facebook.h"
#import "FBConnect.h"
#import <sqlite3.h>

typedef enum apiCall {
    kAPILogout,
    kAPIGraphUserPermissionsDelete,
    kDialogPermissionsExtended,
    kDialogRequestsSendToMany,
    kAPIGetAppUsersFriendsNotUsing,
    kAPIGetAppUsersFriendsUsing,
    kAPIFriendsForDialogRequests,
    kDialogRequestsSendToSelect,
    kAPIFriendsForTargetDialogRequests,
    kDialogRequestsSendToTarget,
    kDialogFeedUser,
    kAPIFriendsForDialogFeed,
    kDialogFeedFriend,
    kAPIGraphUserPermissions,
    kAPIGraphMe,
    kAPIGraphUserFriends,
    kDialogPermissionsCheckin,
    kDialogPermissionsCheckinForRecent,
    kDialogPermissionsCheckinForPlaces,
    kAPIGraphSearchPlace,
    kAPIGraphUserCheckins,
    kAPIGraphUserPhotosPost,
    kAPIGraphUserVideosPost,
} apiCall;


@interface ProductsVC : UIViewController <UITableViewDataSource,UITableViewDelegate,MFMailComposeViewControllerDelegate,FBDialogDelegate,FBLoginDialogDelegate,FBRequestDelegate,FBSessionDelegate,PayPalPaymentDelegate, ZZFlipsideViewControllerDelegate, UIPopoverControllerDelegate>
{
    sqlite3 *_database;
    UIButton *btnLeftMenu,*btnCart,*btnFacebook,*btnTwitter,*btnEmail,*btnCancel,*btnBack,*btnLoginLink;
    UITableView *tblProducts;
    UIView *SharePopUpView;
    UIImageView *tempImageView;
    UILabel *lblHeading;
    
    ///FB-TWitter-Email...  
    TWTweetComposeViewController *tweetSheet;
    int currentAPICall;
    UITableView *friends_tblvw;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart,*btnFacebook,*btnTwitter,*btnEmail,*btnCancel,*btnBack,*btnLoginLink;
@property (nonatomic, retain) IBOutlet UITableView *tblProducts;
@property (nonatomic, retain) IBOutlet UIView *SharePopUpView;
@property (nonatomic, retain) IBOutlet UIImageView *tempImageView;
@property (nonatomic, retain) IBOutlet UILabel *lblHeading;
@property (nonatomic,retain) NSString *SubCategoryID,*SubCategoryAttribID,*HeadingName,*strParentId;
//Integration
@property (nonatomic, retain) Facebook *facebook;
@property (nonatomic,retain) IBOutlet UITableView *friends_tblvw;

///PayPal...
@property(nonatomic, strong, readwrite) UIPopoverController *flipsidePopoverController;
@property(nonatomic, strong, readwrite) NSString *environment;
@property(nonatomic, assign, readwrite) BOOL acceptCreditCards;
@property(nonatomic, strong, readwrite) PayPalPayment *completedPayment;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnFacebookClick:(id)sender;
-(IBAction)btnTwitterClick:(id)sender;
-(IBAction)btnEmailClick:(id)sender;
-(IBAction)btnCancelClick:(id)sender;
-(IBAction)btnBack:(id)sender;
-(IBAction)btnLoginLinkClick:(id)sender;

@end
