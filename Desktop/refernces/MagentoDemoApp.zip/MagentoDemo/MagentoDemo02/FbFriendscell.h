//
//  FbFriendscell.h
//  GreetingCardsApp
//
//  Created by c37 on 13/09/12.
//  Copyright (c) 2012 __MyCompanyName__. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AsyncImageView.h"

@interface FbFriendscell : UITableViewCell
{
    AsyncImageView *profile_img;
    UILabel *Name_user;
}
@property(nonatomic,retain) IBOutlet AsyncImageView *profile_img;
@property(nonatomic,retain) IBOutlet UILabel *Name_user;
@end
