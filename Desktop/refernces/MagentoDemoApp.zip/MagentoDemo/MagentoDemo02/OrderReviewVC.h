//
//  OrderReviewVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface OrderReviewVC : UIViewController <UITableViewDelegate,UITableViewDataSource>
{
    sqlite3 *_database;
    UIButton *btnLeftMenu,*btnCart,*btnBack,*btnPlaceOrder;
    UITableView *tblOrderReview;
    UILabel *lblEmptyCart,*lblGT,*lblShipppingMethod,*lblShippingCharges;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart,*btnBack,*btnPlaceOrder;
@property (nonatomic,retain) IBOutlet UITableView *tblOrderReview;
@property (nonatomic,retain) IBOutlet UILabel *lblEmptyCart,*lblGT,*lblShipppingMethod,*lblShippingCharges;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnBack:(id)sender;
-(IBAction)btnPlaceOrderClick:(id)sender;
@end
