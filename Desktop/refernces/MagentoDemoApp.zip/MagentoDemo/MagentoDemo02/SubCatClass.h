//
//  SubCatClass.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 25/12/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface SubCatClass : NSObject
{

}
    
@property (nonatomic,retain)NSString *strSubCategoryId;
@property (nonatomic,retain)NSString *strSubCategory;
@property (nonatomic,retain)NSString *strParentId;
    
@end
