//
//  ProductMultipleImageVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 26/12/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "AppDelegate.h"

@interface ProductMultipleImageVC : UIViewController
{
    AppDelegate *appDelegate;
}

@property (nonatomic,retain)IBOutlet UIImageView *imgbig;
@property (nonatomic,retain)IBOutlet UIImageView *imgs1,*imgs2,*imgs3;
@property (nonatomic,retain)IBOutlet UIButton *btnImage1;
@property (nonatomic,retain)IBOutlet UIButton *btnImage2;
@property (nonatomic,retain)IBOutlet UIButton *btnImage3;
@property (nonatomic,retain)IBOutlet UILabel *lblHeading;
@property (nonatomic,retain)NSString *strHeading;
@property (nonatomic)NSInteger intSelectedIndex;

-(IBAction)btnImage1_click:(id)sender;
-(IBAction)btnImage2_click:(id)sender;
-(IBAction)btnImage3_click:(id)sender;
-(IBAction)btnCartClick:(id)sender;

-(IBAction)btnBack:(id)sender;

-(IBAction)btnLeftMenuClick:(id)sender;

-(IBAction)btnLoginLinkClick:(id)sender;

@end
