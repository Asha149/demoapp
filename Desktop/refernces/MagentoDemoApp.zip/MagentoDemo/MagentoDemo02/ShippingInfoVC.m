//
//  ShippingInfoVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "ShippingInfoVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "MyCartVC.h"
#import "ShippingMethodVC.h"
#import "AppDelegate.h"
#import "ObjectClass.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"

@interface ShippingInfoVC ()

@end

@implementation ShippingInfoVC
@synthesize btnLeftMenu,btnCart,btnBack,btnContinue,btnUseBillingInfo,Scroll;
@synthesize txtFirstName,txtLastName,txtCompany,txtEmailAddress,txtAddress,txtCity,txtState,txtZipCode,txtCountry,txtTelephone,txtFax;
@synthesize textFirstName,textLastName,textCompany,textEmailAddress,textAddress,textCity,textState,textZipCode,textCountry,textTelephone,textFax,checked;
AppDelegate *app;
NSString *str;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    [Scroll setContentSize:CGSizeMake(Scroll.frame.size.width, Scroll.frame.size.height+10)];
    checked=@"diff";
    
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.COArr objectAtIndex:0];
    NSLog(@"InShippingInfo.......");
    NSLog(@"obj.coAs = %@",obj.coAs);
    NSLog(@"obj.coFirstName = %@",obj.coFirstName);
    NSLog(@"obj.coLastName = %@",obj.coLastName);
    NSLog(@"obj.coCompany = %@",obj.coCompany);
    NSLog(@"obj.coEmailAddress = %@",obj.coEmailAddress);
    NSLog(@"obj.coAddress = %@",obj.coAddress);
    NSLog(@"obj.coCity = %@",obj.coCity);
    NSLog(@"obj.coState = %@",obj.coState);
    NSLog(@"obj.coZipCode = %@",obj.coZipCode);
    NSLog(@"obj.coCountry = %@",obj.coCountry);
    NSLog(@"obj.coTelephone = %@",obj.coTelephone);
    NSLog(@"obj.coFax = %@",obj.coFax);
}

#pragma mark
#pragma mark - Button Clicks Methods...
-(IBAction)btnLeftMenuClick:(id)sender
{
    str=@"menu";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnCartClick:(id)sender
{
    str=@"cart";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnUseBillingInfoClick:(id)sender
{
    if ([checked isEqualToString:@"diff"])
    {
        checked=@"this";
        ObjectClass *obj = [[ObjectClass alloc]init];
        obj=[app.COArr objectAtIndex:0];
        [btnUseBillingInfo setBackgroundImage:[UIImage imageNamed:@"check.png"] forState:UIControlStateNormal];
        txtFirstName.text=obj.coFirstName;
        txtLastName.text=obj.coLastName;
        txtCompany.text=obj.coCompany;
        txtAddress.text=obj.coAddress;
        txtCity.text=obj.coCity;
        txtState.text=obj.coState;
        txtZipCode.text=obj.coZipCode;
        txtCountry.text=obj.coCountry;
        txtTelephone.text=obj.coTelephone;
        txtFax.text=obj.coFax;
    }
    else
    {
        checked=@"diff";
        [btnUseBillingInfo setBackgroundImage:[UIImage imageNamed:@"uncheck.png"] forState:UIControlStateNormal];
        txtFirstName.text=@"";
        txtLastName.text=@"";
        txtCompany.text=@"";
        txtEmailAddress.text=@"";
        txtAddress.text=@"";
        txtCity.text=@"";
        txtState.text=@"";
        txtZipCode.text=@"";
        txtCountry.text=@"";
        txtTelephone.text=@"";
        txtFax.text=@"";
    }
}
-(IBAction)btnContinueClick:(id)sender
{
    UIAlertView *CheckAlert = [[UIAlertView alloc]initWithTitle:@"Some Fields are Empty"
                                                        message:@"..."
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
    [CheckAlert setDelegate:self];
    [CheckAlert setTitle:@"Warning"];
    textFirstName= [txtFirstName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    textLastName= [txtLastName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    textCompany= [txtCompany.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    textEmailAddress= [txtEmailAddress.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    textAddress= [txtAddress.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    textCity= [txtCity.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    textState= [txtState.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    textZipCode= [txtZipCode.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    textCountry= [txtCountry.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    textTelephone= [txtTelephone.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    textFax= [txtFax.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (textFirstName.length==0 || textLastName.length==0 || textAddress.length==0 || textCity.length==0 || textState.length==0 || textZipCode.length==0 || textCountry.length==0 || textTelephone.length==0 || textTelephone.length==0)
    {
        if (textFirstName.length==0)
        {
            [CheckAlert setMessage:@"Please Enter First Name"];
        }
        else if (textLastName.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Last Name"];
        }
        else if (textAddress.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Address"];
        }
        else if (textCity.length==0)
        {
            [CheckAlert setMessage:@"Please Enter City"];
        }
        else if (textState.length==0)
        {
            [CheckAlert setMessage:@"Please Enter State"];
        }
        else if (textZipCode.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Zip Code"];
        }
        else if (textCountry.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Country"];
        }
        else if (textTelephone.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Telephone"];
        }
        else
        {
            [CheckAlert setMessage:@"Some Fields are Blank"];
        }
        [CheckAlert show];
    }
    else
    {
        ObjectClass *obj = [[ObjectClass alloc]init];
        obj=[app.COArr objectAtIndex:0];
        NSLog(@"[app.COArr objectAtIndex:0].coAs = %@",obj.coAs);
        
        obj.coShipFirstName=textFirstName;
        obj.coShipLastName=textLastName;
        obj.coShipCompany=textCompany;
        obj.coShipAddress=textAddress;
        obj.coShipCity=textCity;
        obj.coShipState=textState;
        obj.coShipZipCode=textZipCode;
        obj.coShipCountry=textCountry;
        obj.coShipTelephone=textTelephone;
        obj.coShipFax=textFax;
        
        [app.COArr addObject:obj];
        
        NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
        NSString *cartId = [defaults objectForKey:@"cartId"];
        WebApiController *obj1=[[WebApiController alloc]init];
        
        NSMutableDictionary *param1=[[NSMutableDictionary alloc]init];
        
        
        [param1 setValue:cartId forKey:@"cart_id"];
        [param1 setValue:obj.coShipFirstName forKey:@"fname"];
        [param1 setValue:obj.coShipLastName forKey:@"lname"];
        [param1 setValue:obj.coShipAddress forKey:@"street"];
        [param1 setValue:obj.coShipCompany forKey:@"company"];
        [param1 setValue:obj.coShipCity forKey:@"city"];
        [param1 setValue:obj.coShipZipCode forKey:@"zipCode"];
        [param1 setValue:obj.coShipCountry forKey:@"country"];
        [param1 setValue:obj.coShipTelephone forKey:@"telephone"];
        [param1 setValue:obj.coShipFax forKey:@"fax"];
        [param1 setValue:obj.coShipState forKey:@"region"];
        
        
        [obj1 callAPI_GET:@"ShippingInfo.php" andParams:param1 SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
        [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];

        
       
    }
//    ShippingMethodVC *obj = [[ShippingMethodVC alloc] initWithNibName:@"ShippingMethodVC" bundle:[NSBundle mainBundle]];
//    [self.navigationController pushViewController:obj animated:YES];
//    [obj release];
}
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    [SVProgressHUD dismiss];
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"Json dictionary :: %@",jsonDictionary);
    ShippingMethodVC *objVC = [[ShippingMethodVC alloc] initWithNibName:@"ShippingMethodVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:objVC animated:YES];
    [objVC release];
   
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"YES"])
    {
        if ([str isEqualToString:@"menu"])
        {
            LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
            [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
            [obj release];
        }
        else if ([str isEqualToString:@"cart"])
        {
            MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:obj animated:YES];
            [obj release];
        }
        
    }
    else if([title isEqualToString:@"NO"])
    {
        NSLog(@"Button 2 was selected.");
    }
}


#pragma mark
#pragma mark - TextField Methods...
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    int y=0;
    if (textField==txtCompany)
    {
        y=40;
    }
    else if (textField==txtCity)
    {
        y=90;
    }
    else if (textField==txtState)
    {
        y=150;
    }
    else if (textField==txtZipCode)
    {
        y=210;
    }
    else if (textField==txtCountry)
    {
        y=270;
    }
    else if (textField==txtTelephone)
    {
        y=330;
    }
    else if (textField==txtFax)
    {
        y=390;
    }
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlUp animations:^{
        CGRect rc = [textField bounds];
        rc = [textField convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = y ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(void)textFieldDidEndEditing:(UITextField *)textField
{
    int y=0;
    if (textField==txtCompany)
    {
        y=40;
    }
    else if (textField==txtCity)
    {
        y=90;
    }
    else if (textField==txtState)
    {
        y=150;
    }
    else if (textField==txtZipCode)
    {
        y=210;
    }
    else if (textField==txtCountry)
    {
        y=270;
    }
    else if (textField==txtTelephone)
    {
        y=270;
    }
    else if (textField==txtFax)
    {
        y=270;
    }
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlDown animations:^{
        CGRect rc = [textField bounds];
        rc = [textField convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = y ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark
#pragma mark - TextView Methods...
-(void)textViewDidBeginEditing:(UITextView *)textView
{
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlUp animations:^{
        CGRect rc = [textView bounds];
        rc = [textView convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = 90 ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(void)textViewDidEndEditing:(UITextView *)textView
{
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlDown animations:^{
        CGRect rc = [textView bounds];
        rc = [textView convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = 90 ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
    }
    else if([text isEqualToString:@"\t"])
    {
        [txtCity becomeFirstResponder];
    }
    return YES;
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
