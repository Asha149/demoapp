//
//  LeftMenuController.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 06/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LeftMenuController : UIViewController <UITableViewDelegate,UITableViewDataSource>
{
    UITableView *tblMenu;
}
@property (nonatomic, retain) IBOutlet UITableView *tblMenu;

@end
