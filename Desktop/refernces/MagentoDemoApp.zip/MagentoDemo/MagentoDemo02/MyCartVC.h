//
//  MyCartVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 07/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>
#import "ZZFlipsideViewController.h"
#import "PayPalMobile.h"
#import <MessageUI/MessageUI.h>
#import <Twitter/Twitter.h>
#import "Facebook.h"
#import "FBConnect.h"
#import "ProductsVC.h"

@interface MyCartVC : UIViewController <UITableViewDataSource,UITableViewDelegate,MFMailComposeViewControllerDelegate,FBDialogDelegate,FBLoginDialogDelegate,FBRequestDelegate,FBSessionDelegate,PayPalPaymentDelegate, ZZFlipsideViewControllerDelegate, UIPopoverControllerDelegate>
{
    sqlite3 *_database;
    UIButton *btnLeftMenu,*btnFacebook,*btnTwitter,*btnEmail,*btnCancel,*btnCheckOut;
    UITableView *tblCartProducts;
    UIView *SharePopUpView,*HeadingPopUp;
    UIImageView *tempImageView;
    UILabel *lblEmptyCart,*lblGT;
    
    ///FB-TWitter-Email...
    TWTweetComposeViewController *tweetSheet;
    int currentAPICall;
    UITableView *friends_tblvw;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnFacebook,*btnTwitter,*btnEmail,*btnCancel,*btnCheckOut;
@property (nonatomic,retain) IBOutlet UITableView *tblCartProducts;
@property (nonatomic, retain) IBOutlet UIView *SharePopUpView,*HeadingPopUp;
@property (nonatomic, retain) IBOutlet UIImageView *tempImageView;
@property (nonatomic, retain) IBOutlet UILabel *lblEmptyCart,*lblGT;
@property (nonatomic,retain) NSString *MainCategoryID,*SubCategoryID;

//Integration
@property (nonatomic, retain) Facebook *facebook;
@property (nonatomic,retain) IBOutlet UITableView *friends_tblvw;

///PayPal...
@property(nonatomic, strong, readwrite) UIPopoverController *flipsidePopoverController;
@property(nonatomic, strong, readwrite) NSString *environment;
@property(nonatomic, assign, readwrite) BOOL acceptCreditCards;
@property(nonatomic, strong, readwrite) PayPalPayment *completedPayment;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnFacebookClick:(id)sender;
-(IBAction)btnTwitterClick:(id)sender;
-(IBAction)btnEmailClick:(id)sender;
-(IBAction)btnCancelClick:(id)sender;
-(IBAction)btnCheckOutClick:(id)sender;

@end
