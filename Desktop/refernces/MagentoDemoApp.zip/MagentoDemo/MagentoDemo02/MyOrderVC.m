//
//  MyOrderVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 25/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "MyOrderVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "MyCartVC.h"
#import "ObjectClass.h"
#import "AppDelegate.h"
#import "OrderReviewCell.h"
#import "OrderPlacedVC.h"

@interface MyOrderVC ()

@end

@implementation MyOrderVC
@synthesize btnLeftMenu,btnCart,tblOrders,lblEmptyOrder,lblGT,HeadingPopUp;
AppDelegate *app;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    
//    ObjectClass *obj=[[ObjectClass alloc]init];
//    obj=[app.OrderArr objectAtIndex:0];
//    NSLog(@"obj.coOrderId = %@",obj.coOrderId);
//    NSLog(@"obj.coFirstName = %@",obj.coFirstName);
//    NSLog(@"obj.coLastName = %@",obj.coLastName);
//    NSLog(@"obj.coCompany = %@",obj.coCompany);
//    NSLog(@"obj.coEmailAddress = %@",obj.coEmailAddress);
//    NSLog(@"obj.coAddress = %@",obj.coAddress);
//    NSLog(@"obj.coCity = %@",obj.coCity);
//    NSLog(@"obj.coState = %@",obj.coState);
//    NSLog(@"obj.coZipCode = %@",obj.coZipCode);
//    NSLog(@"obj.coCountry = %@",obj.coCountry);
//    NSLog(@"obj.coTelephone = %@",obj.coTelephone);
//    NSLog(@"obj.coFax = %@",obj.coFax);
//    NSLog(@"obj.coShipFirstName = %@",obj.coShipFirstName);
//    NSLog(@"obj.coShipLastName = %@",obj.coShipLastName);
//    NSLog(@"obj.coShipCompany = %@",obj.coShipCompany);
//    NSLog(@"obj.coShipAddress = %@",obj.coShipAddress);
//    NSLog(@"obj.coShipCity = %@",obj.coShipCity);
//    NSLog(@"obj.coShipState = %@",obj.coShipState);
//    NSLog(@"obj.coShipZipCode = %@",obj.coShipZipCode);
//    NSLog(@"obj.coShipCountry = %@",obj.coShipCountry);
//    NSLog(@"obj.coShipTelephone = %@",obj.coShipTelephone);
//    NSLog(@"obj.coShipFax = %@",obj.coShipFax);
//    NSLog(@"obj.coShippingMethod = %@",obj.coShippingMethod);
//    NSLog(@"obj.coPaymentMethod = %@",obj.coPaymentMethod);
//    NSLog(@"obj.coGrandTotal = %@",obj.coGrandTotal);
}

#pragma
#pragma mark - TableView Methods...
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [app.OrderArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"OrderReviewCell";
    OrderReviewCell *cell = (OrderReviewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OrderReviewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.COArr objectAtIndex:[indexPath row]];
    cell.lblNo.text=[NSString stringWithFormat:@"%d",[indexPath row]+1];
    cell.lblName.text=obj.ProductTitle;
    [cell.lblQty setHidden:YES];
    cell.lblPrice.text=obj.ProductPrice;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ObjectClass *obj=[[ObjectClass alloc]init];
    obj=[app.COArr objectAtIndex:[indexPath row]];
    OrderPlacedVC *objVC = [[OrderPlacedVC alloc] initWithNibName:@"OrderPlacedVC" bundle:[NSBundle mainBundle]];
    objVC.PassedOrderID=obj.coOrderId;
    objVC.From=@"MyOrder";
    [self.navigationController pushViewController:objVC animated:YES];
    [objVC release];
}

-(IBAction)btnLeftMenuClick:(id)sender
{
    LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
    [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
    [obj release];
}
-(IBAction)btnCartClick:(id)sender
{
    MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:obj animated:YES];
    [obj release];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
