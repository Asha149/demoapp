//
//  CategoriesVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 07/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CategoriesVC : UIViewController <UITableViewDelegate,UITableViewDataSource>
{
    UIButton *btnLeftMenu,*btnCart,*btnLoginLink;
    UITableView *tblCategories;
    UILabel *lblHeading;
}
@property (nonatomic, retain) IBOutlet UIButton *btnLeftMenu,*btnCart,*btnLoginLink;
@property (nonatomic, retain) IBOutlet UITableView *tblCategories;
@property (nonatomic, retain) IBOutlet UILabel *lblHeading;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnLoginLinkClick:(id)sender;

@end
