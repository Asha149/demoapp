//
//  BillingInfoVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "BillingInfoVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "MyCartVC.h"
#import "ShippingInfoVC.h"
#import "ShippingMethodVC.h"
#import "AppDelegate.h"
#import "ObjectClass.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"

@interface BillingInfoVC ()

@end

@implementation BillingInfoVC
@synthesize btnLeftMenu,btnCart,btnBack,btnContinue,Scroll,btnShipToThis,btnShipToDiff,checked;
@synthesize txtFirstName,txtLastName,txtCompany,txtEmailAddress,txtAddress,txtCity,txtState,txtZipCode,txtCountry,txtTelephone,txtFax;
AppDelegate *app;
NSString *str;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    [Scroll setContentSize:CGSizeMake(Scroll.frame.size.width, Scroll.frame.size.height+10)];
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    checked=@"this";
//    app.COArr 	= [[NSMutableArray alloc]init];
//  ObjectClass *obj = [[ObjectClass alloc]init];
//    obj=[app.COArr objectAtIndex:0];
//    NSLog(@"[app.COArr objectAtIndex:0].coAs = %@",obj.coAs);
}

#pragma mark
#pragma mark - Button Clicks Methods...
-(IBAction)btnLeftMenuClick:(id)sender
{
    str=@"menu";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnCartClick:(id)sender
{
    str=@"cart";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnShipToThisClick:(id)sender
{
    checked=@"this";
    [btnShipToThis setBackgroundImage:[UIImage imageNamed:@"RadioChecked.png"] forState:UIControlStateNormal];
    [btnShipToDiff setBackgroundImage:[UIImage imageNamed:@"RadioUnchecked.png"] forState:UIControlStateNormal];
}
-(IBAction)btnShipToDiffClick:(id)sender
{
    checked=@"diff";
    [btnShipToThis setBackgroundImage:[UIImage imageNamed:@"RadioUnchecked.png"] forState:UIControlStateNormal];
    [btnShipToDiff setBackgroundImage:[UIImage imageNamed:@"RadioChecked.png"] forState:UIControlStateNormal];
}
-(IBAction)btnContinueClick:(id)sender
{
    UIAlertView *CheckAlert = [[UIAlertView alloc]initWithTitle:@"Some Fields are Empty"
                                                        message:@"..."
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
    [CheckAlert setDelegate:self];
    [CheckAlert setTitle:@"Warning"];
    NSString *textFirstName= [txtFirstName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textLastName= [txtLastName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textCompany= [txtCompany.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textEmailAddress= [txtEmailAddress.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textAddress= [txtAddress.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textCity= [txtCity.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textState= [txtState.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textZipCode= [txtZipCode.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textCountry= [txtCountry.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textTelephone= [txtTelephone.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textFax= [txtFax.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (textFirstName.length==0 || textLastName.length==0 || textEmailAddress.length==0 || textAddress.length==0 || textCity.length==0 || textState.length==0 || textZipCode.length==0 || textCountry.length==0 || textTelephone.length==0)
    {
        if (textFirstName.length==0)
        {
            [CheckAlert setMessage:@"Please Enter First Name"];
        }
        else if (textLastName.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Last Name"];
        }
        else if (textEmailAddress.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Email Address"];
        }
        else if (textAddress.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Address"];
        }
        else if (textCity.length==0)
        {
            [CheckAlert setMessage:@"Please Enter City"];
        }
        else if (textState.length==0)
        {
            [CheckAlert setMessage:@"Please Enter State"];
        }
        else if (textZipCode.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Zip Code"];
        }
        else if (textCountry.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Country"];
        }
        else if (textTelephone.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Telephone"];
        }
        else
        {
            [CheckAlert setMessage:@"Some Fields are Blank"];
        }
        [CheckAlert show];
    }
    else
    {
        BOOL isValid = [self NSStringIsValidEmail:textEmailAddress];
        if (isValid)
        {
            NSLog(@"arr : %@", app.COArr);
            ObjectClass *obj = [[ObjectClass alloc]init];
         
            obj = [app.COArr objectAtIndex:0];
            NSString *str = obj.coAs;
            NSLog(@"STRING :: %@",str);
            
            if([str isEqualToString:@"Guest"])
            {
                if ([checked isEqualToString:@"diff"])
                {
                    
                ObjectClass *obj = [[ObjectClass alloc]init];
                obj=[app.COArr objectAtIndex:0];
                obj.coFirstName=textFirstName;
                obj.coLastName=textLastName;
                obj.coCompany=textCompany;
                obj.coEmailAddress=textEmailAddress;
                obj.coAddress=textAddress;
                obj.coCity=textCity;
                obj.coState=textState;
                obj.coZipCode=textZipCode;
                obj.coCountry=textCountry;
                obj.coTelephone=textTelephone;
                obj.coFax=textFax;
                obj.coShipTo=checked;
                [app.COArr addObject:obj];
                
                    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                    NSString *cartId = [defaults objectForKey:@"cartId"];
                    WebApiController *obj1=[[WebApiController alloc]init];
                    
                    NSMutableDictionary *param2=[[NSMutableDictionary alloc]init];
                    
                    
                    [param2 setValue:cartId forKey:@"cart_id"];
                    [param2 setValue:obj.coFirstName forKey:@"fname"];
                    [param2 setValue:obj.coLastName forKey:@"lname"];
                    [param2 setValue:obj.coAddress forKey:@"street"];
                    [param2 setValue:obj.coCompany forKey:@"company"];
                    [param2 setValue:obj.coCity forKey:@"city"];
                    [param2 setValue:obj.coZipCode forKey:@"zipCode"];
                    [param2 setValue:obj.coCountry forKey:@"country"];
                    [param2 setValue:obj.coTelephone forKey:@"telephone"];
                    [param2 setValue:obj.coFax forKey:@"fax"];
                    [param2 setValue:obj.coState forKey:@"region"];
                    
                    
                    [obj1 callAPI_GET:@"BillingInfo.php" andParams:param2 SuccessCallback:@selector(service_reponse4:Response:) andDelegate:self];
                    
                     [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
                    
               
            }
                else
                {
                    
                    
                    ObjectClass *obj = [[ObjectClass alloc]init];
                    obj=[app.COArr objectAtIndex:0];
                    obj.coFirstName=textFirstName;
                    obj.coLastName=textLastName;
                    obj.coCompany=textCompany;
                    obj.coEmailAddress=textEmailAddress;
                    obj.coAddress=textAddress;
                    obj.coCity=textCity;
                    obj.coState=textState;
                    obj.coZipCode=textZipCode;
                    obj.coCountry=textCountry;
                    obj.coTelephone=textTelephone;
                    obj.coFax=textFax;
                    obj.coShipTo=checked;
                    obj.coShipFirstName=textFirstName;
                    obj.coShipLastName=textLastName;
                    obj.coShipCompany=textCompany;
                    obj.coShipAddress=textAddress;
                    obj.coShipCity=textCity;
                    obj.coShipState=textState;
                    obj.coShipZipCode=textZipCode;
                    obj.coShipCountry=textCountry;
                    obj.coShipTelephone=textTelephone;
                    obj.coShipFax=textFax;
                    [app.COArr addObject:obj];
                    
                    //http://localhost/project01/billingShippingInfo.php?fname=asha&&lname=sharma&&company=lanet&&street=svroad&&city=mumbai&&zipCode=400092&&country=india&&telephone=9898989898&&fax=kdjfh&&cart_id=33&&region=maharashtra
                    
                    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                    NSString *cartId = [defaults objectForKey:@"cartId"];
                    WebApiController *obj1=[[WebApiController alloc]init];
                    
                    NSMutableDictionary *param2=[[NSMutableDictionary alloc]init];
                    
                    
                    [param2 setValue:cartId forKey:@"cart_id"];
                    [param2 setValue:obj.coFirstName forKey:@"fname"];
                    [param2 setValue:obj.coLastName forKey:@"lname"];
                    [param2 setValue:obj.coAddress forKey:@"street"];
                    [param2 setValue:obj.coCompany forKey:@"company"];
                    [param2 setValue:obj.coCity forKey:@"city"];
                    [param2 setValue:obj.coZipCode forKey:@"zipCode"];
                    [param2 setValue:obj.coCountry forKey:@"country"];
                    [param2 setValue:obj.coTelephone forKey:@"telephone"];
                    [param2 setValue:obj.coFax forKey:@"fax"];
                    [param2 setValue:obj.coState forKey:@"region"];
                    
                    
                    [obj1 callAPI_GET:@"BillingInfo.php" andParams:param2 SuccessCallback:@selector(service_reponse3:Response:) andDelegate:self];
                    
                    
                    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
                    
                    
                    
                }
            }
            
            else
            {
                if ([checked isEqualToString:@"diff"])
                {
                    ObjectClass *obj = [[ObjectClass alloc]init];
                    obj=[app.COArr objectAtIndex:0];
                    obj.coFirstName=textFirstName;
                    obj.coLastName=textLastName;
                    obj.coCompany=textCompany;
                    obj.coEmailAddress=textEmailAddress;
                    obj.coAddress=textAddress;
                    obj.coCity=textCity;
                    obj.coState=textState;
                    obj.coZipCode=textZipCode;
                    obj.coCountry=textCountry;
                    obj.coTelephone=textTelephone;
                    obj.coFax=textFax;
                    obj.coShipTo=checked;
                    [app.COArr addObject:obj];
                    
                    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                    NSString *cartId = [defaults objectForKey:@"cartId"];
                    WebApiController *obj1=[[WebApiController alloc]init];
                    
                    NSMutableDictionary *param2=[[NSMutableDictionary alloc]init];
                    
                    
                    [param2 setValue:cartId forKey:@"cart_id"];
                    [param2 setValue:obj.coFirstName forKey:@"fname"];
                    [param2 setValue:obj.coLastName forKey:@"lname"];
                    [param2 setValue:obj.coAddress forKey:@"street"];
                    [param2 setValue:obj.coCompany forKey:@"company"];
                    [param2 setValue:obj.coCity forKey:@"city"];
                    [param2 setValue:obj.coZipCode forKey:@"zipCode"];
                    [param2 setValue:obj.coCountry forKey:@"country"];
                    [param2 setValue:obj.coTelephone forKey:@"telephone"];
                    [param2 setValue:obj.coFax forKey:@"fax"];
                    [param2 setValue:obj.coState forKey:@"region"];
                    
                    
                    [obj1 callAPI_GET:@"BillingInfo.php" andParams:param2 SuccessCallback:@selector(service_reponse4:Response:) andDelegate:self];
                    
                    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];

            }
                else
                {
                    
                    
                    ObjectClass *obj = [[ObjectClass alloc]init];
                    obj=[app.COArr objectAtIndex:0];
                    obj.coFirstName=textFirstName;
                    obj.coLastName=textLastName;
                    obj.coCompany=textCompany;
                    obj.coEmailAddress=textEmailAddress;
                    obj.coAddress=textAddress;
                    obj.coCity=textCity;
                    obj.coState=textState;
                    obj.coZipCode=textZipCode;
                    obj.coCountry=textCountry;
                    obj.coTelephone=textTelephone;
                    obj.coFax=textFax;
                    obj.coShipTo=checked;
                    obj.coShipFirstName=textFirstName;
                    obj.coShipLastName=textLastName;
                    obj.coShipCompany=textCompany;
                    obj.coShipAddress=textAddress;
                    obj.coShipCity=textCity;
                    obj.coShipState=textState;
                    obj.coShipZipCode=textZipCode;
                    obj.coShipCountry=textCountry;
                    obj.coShipTelephone=textTelephone;
                    obj.coShipFax=textFax;
                    [app.COArr addObject:obj];
                    
                    //http://localhost/project01/billingShippingInfo.php?fname=asha&&lname=sharma&&company=lanet&&street=svroad&&city=mumbai&&zipCode=400092&&country=india&&telephone=9898989898&&fax=kdjfh&&cart_id=33&&region=maharashtra
                    
                    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
                    NSString *cartId = [defaults objectForKey:@"cartId"];
                    WebApiController *obj1=[[WebApiController alloc]init];
                    
                    NSMutableDictionary *param2=[[NSMutableDictionary alloc]init];
                    
                    
                    [param2 setValue:cartId forKey:@"cart_id"];
                    [param2 setValue:obj.coFirstName forKey:@"fname"];
                    [param2 setValue:obj.coLastName forKey:@"lname"];
                    [param2 setValue:obj.coAddress forKey:@"street"];
                    [param2 setValue:obj.coCompany forKey:@"company"];
                    [param2 setValue:obj.coCity forKey:@"city"];
                    [param2 setValue:obj.coZipCode forKey:@"zipCode"];
                    [param2 setValue:obj.coCountry forKey:@"country"];
                    [param2 setValue:obj.coTelephone forKey:@"telephone"];
                    [param2 setValue:obj.coFax forKey:@"fax"];
                    [param2 setValue:obj.coState forKey:@"region"];
                    
                    
                    [obj1 callAPI_GET:@"BillingInfo.php" andParams:param2 SuccessCallback:@selector(service_reponse3:Response:) andDelegate:self];
                    
                    
                    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
                    
                    
                    
                }

           
               
        }
            
                                

            }
        
            }
//    ShippingInfoVC *objVC = [[ShippingInfoVC alloc] initWithNibName:@"ShippingInfoVC" bundle:[NSBundle mainBundle]];
//    [self.navigationController pushViewController:objVC animated:YES];
//    [objVC release];
}
-(void)service_reponse4:(NSString *)apiAlias Response:(NSData *)response
{
    [SVProgressHUD dismiss];
    ObjectClass *obj = [[ObjectClass alloc]init];
    
    obj = [app.COArr objectAtIndex:0];
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"Json dictionary :: %@",jsonDictionary);
    ShippingInfoVC *objVC = [[ShippingInfoVC alloc] initWithNibName:@"ShippingInfoVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:objVC animated:YES];
    [objVC release];
    
}
-(void)service_reponse3:(NSString *)apiAlias Response:(NSData *)response
{
    [SVProgressHUD dismiss];
    ObjectClass *obj = [[ObjectClass alloc]init];

    obj = [app.COArr objectAtIndex:0];
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"Json dictionary :: %@",jsonDictionary);
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *cartId = [defaults objectForKey:@"cartId"];
    WebApiController *obj1=[[WebApiController alloc]init];

    NSMutableDictionary *param1=[[NSMutableDictionary alloc]init];
    
    
    [param1 setValue:cartId forKey:@"cart_id"];
    [param1 setValue:obj.coShipFirstName forKey:@"fname"];
    [param1 setValue:obj.coShipLastName forKey:@"lname"];
    [param1 setValue:obj.coShipAddress forKey:@"street"];
    [param1 setValue:obj.coShipCompany forKey:@"company"];
    [param1 setValue:obj.coShipCity forKey:@"city"];
    [param1 setValue:obj.coShipZipCode forKey:@"zipCode"];
    [param1 setValue:obj.coShipCountry forKey:@"country"];
    [param1 setValue:obj.coShipTelephone forKey:@"telephone"];
    [param1 setValue:obj.coShipFax forKey:@"fax"];
    [param1 setValue:obj.coShipState forKey:@"region"];
    
    
    [obj1 callAPI_GET:@"ShippingInfo.php" andParams:param1 SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];

}
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    [SVProgressHUD dismiss];
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"Json dictionary :: %@",jsonDictionary);
    NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *cartId = [defaults objectForKey:@"cartId"];
    ObjectClass *obj1 = [[ObjectClass alloc]init];
    
    [param setValue:obj1.coFirstName forKey:@"fname"];
    [param setValue:obj1.coLastName forKey:@"lname"];
    [param setValue:obj1.coEmailAddress forKey:@"email"];
    [param setValue:cartId forKey:@"cart_id"];
    
    WebApiController *obj=[[WebApiController alloc]init];
    [obj callAPI_GET:@"AddCustomerGuest.php" andParams:param SuccessCallback:@selector(service_reponse2:Response:) andDelegate:self];
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
}
-(BOOL)NSStringIsValidEmail:(NSString *)checkString
{
    BOOL stricterFilter = YES;
    NSString *stricterFilterString = @"[A-Z0-9a-z\\._%+-]+@([A-Za-z0-9-]+\\.)+[A-Za-z]{2,4}";
    NSString *laxString = @".+@([A-Za-z0-9]+\\.)+[A-Za-z]{2}[A-Za-z]*";
    NSString *emailRegex = stricterFilter ? stricterFilterString : laxString;
    NSPredicate *emailTest = [NSPredicate predicateWithFormat:@"SELF MATCHES %@", emailRegex];
    return [emailTest evaluateWithObject:checkString];
}
-(void)service_reponse2:(NSString *)apiAlias Response:(NSData *)response
{
        [SVProgressHUD dismiss];
        NSString *str=[[NSString alloc]initWithData:response encoding:NSUTF8StringEncoding];
        NSLog(@"Json dictionary :: %@",str);
    ShippingMethodVC *objVC = [[ShippingMethodVC alloc] initWithNibName:@"ShippingMethodVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:objVC animated:YES];
    [objVC release];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"YES"])
    {
        if ([str isEqualToString:@"menu"])
        {
            LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
            [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
            [obj release];
        }
        else if ([str isEqualToString:@"cart"])
        {
            MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:obj animated:YES];
            [obj release];
        }
        
    }
    else if([title isEqualToString:@"NO"])
    {
        NSLog(@"Button 2 was selected.");
    }
}


#pragma mark
#pragma mark - TextField Methods...
-(void)textFieldDidBeginEditing:(UITextField *)textField
{
    int y=0;
    
    if (textField==txtEmailAddress)
    {
        y=90;
    }
    else if (textField==txtCity)
    {
        y=150;
    }
    else if (textField==txtState)
    {
        y=210;
    }
    else if (textField==txtZipCode)
    {
        y=270;
    }
    else if (textField==txtCountry)
    {
        y=330;
    }
    else if (textField==txtTelephone)
    {
        y=390;
    }
    else if (textField==txtFax)
    {
        y=450;
    }
    
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlUp animations:^{
        CGRect rc = [textField bounds];
        rc = [textField convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = y ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}

-(void)textFieldDidEndEditing:(UITextField *)textField
{
    int y=0;
    if (textField==txtEmailAddress)
    {
        y=90;
    }
    else if (textField==txtCity)
    {
        y=150;
    }
    else if (textField==txtState)
    {
        y=210;
    }
    else if (textField==txtZipCode)
    {
        y=270;
    }
    else if (textField==txtCountry)
    {
        y=370;
    }
    else if (textField==txtTelephone)
    {
        y=370;
    }
    else if (textField==txtFax)
    {
        y=370;
    }
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlDown animations:^{
        CGRect rc = [textField bounds];
        rc = [textField convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = y ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}


#pragma mark
#pragma mark - TextView Methods...
-(void)textViewDidBeginEditing:(UITextView *)textView
{
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlUp animations:^{
        CGRect rc = [textView bounds];
        rc = [textView convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = 150 ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(void)textViewDidEndEditing:(UITextView *)textView
{
    [UIView animateWithDuration:0.1f delay:0.0f options:UIViewAnimationOptionTransitionCurlDown animations:^{
        CGRect rc = [textView bounds];
        rc = [textView convertRect:rc toView:Scroll];
        rc.origin.x = 0 ;
        rc.origin.y = 150 ;
        CGPoint pt=rc.origin;
        [self.Scroll setContentOffset:pt animated:YES];
    }completion:nil];
}
-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text
{
    if([text isEqualToString:@"\n"])
    {
        [textView resignFirstResponder];
    }
    else if([text isEqualToString:@"\t"])
    {
        [txtCity becomeFirstResponder];
    }
    return YES;
}



- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
