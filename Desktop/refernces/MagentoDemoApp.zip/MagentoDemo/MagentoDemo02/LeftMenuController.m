//
//  LeftMenuController.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 06/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "LeftMenuController.h"
#import "PPRevealSideViewController.h"
#import "ViewController.h"
#import "CategoriesVC.h"
#import "LoginVC.h"
#import "SearchVC.h"
#import "MyCartVC.h"
#import "MyOrderVC.h"
#import "OffersVC.h"
#import "MainMenuCell.h"
#import "AppDelegate.h"



@interface LeftMenuController ()

@end

@implementation LeftMenuController
@synthesize tblMenu;
AppDelegate *app;
NSMutableArray *MenuItems;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    MenuItems=[[NSMutableArray alloc]init];
    [MenuItems addObject:@"Home"];
    [MenuItems addObject:@"Categories"];
    if (app.UserFname.length==0)
    {
        [MenuItems addObject:@"Login"];
    }
    else
    {
        [MenuItems addObject:@"Logout"];
    }
    [MenuItems addObject:@"MyCart"];
    [MenuItems addObject:@"My Orders"];
    [MenuItems addObject:@"Search"];
    [MenuItems addObject:@"My Account"];
    [MenuItems addObject:@"About Us"];
    [tblMenu reloadData];
}

#pragma
#pragma mark - TableView Methods...
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 70;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [MenuItems count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"MainMenuCell";
    MainMenuCell *cell = (MainMenuCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MainMenuCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    cell.lblTitle.text=[MenuItems objectAtIndex:[indexPath row]];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    if ([indexPath row]==0)
    {
        ViewController *obj = [[ViewController alloc] initWithNibName:@"ViewController" bundle:[NSBundle mainBundle]];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:obj];
        [self.revealSideViewController replaceCentralViewControllerWithNewControllerWithoutPopping:nav];
        [self.revealSideViewController popViewControllerAnimated:YES];
        [obj release];
    }
    else if ([indexPath row]==1)
    {
        CategoriesVC *obj = [[CategoriesVC alloc] initWithNibName:@"CategoriesVC" bundle:[NSBundle mainBundle]];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:obj];
        [self.revealSideViewController replaceCentralViewControllerWithNewControllerWithoutPopping:nav];
        [self.revealSideViewController popViewControllerAnimated:YES];
        [obj release];
    }
    else if ([indexPath row]==2)
    {
        app.UserFname=nil;
        app.Email_ID=nil;
        LoginVC *obj = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:[NSBundle mainBundle]];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:obj];
        [self.revealSideViewController replaceCentralViewControllerWithNewControllerWithoutPopping:nav];
        [self.revealSideViewController popViewControllerAnimated:YES];
        [obj release];
    }
    else if ([indexPath row]==3)
    {
        MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:obj];
        [self.revealSideViewController replaceCentralViewControllerWithNewControllerWithoutPopping:nav];
        [self.revealSideViewController popViewControllerAnimated:YES];
        [obj release];
    }
    else if ([indexPath row]==4)
    {
        MyOrderVC *obj = [[MyOrderVC alloc] initWithNibName:@"MyOrderVC" bundle:[NSBundle mainBundle]];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:obj];
        [self.revealSideViewController replaceCentralViewControllerWithNewControllerWithoutPopping:nav];
        [self.revealSideViewController popViewControllerAnimated:YES];
        [obj release];
    }
    else if ([indexPath row]==5)
    {
        SearchVC *obj = [[SearchVC alloc] initWithNibName:@"SearchVC" bundle:[NSBundle mainBundle]];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:obj];
        [self.revealSideViewController replaceCentralViewControllerWithNewControllerWithoutPopping:nav];
        [self.revealSideViewController popViewControllerAnimated:YES];
        [obj release];
        
    }
    else if ([indexPath row]==6)
    {
        OffersVC *obj = [[OffersVC alloc] initWithNibName:@"OffersVC" bundle:[NSBundle mainBundle]];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:obj];
        [self.revealSideViewController replaceCentralViewControllerWithNewControllerWithoutPopping:nav];
        [self.revealSideViewController popViewControllerAnimated:YES];
        [obj release];
    }
    else
    {
        ViewController *obj = [[ViewController alloc] initWithNibName:@"ViewController" bundle:[NSBundle mainBundle]];
        UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:obj];
        [self.revealSideViewController replaceCentralViewControllerWithNewControllerWithoutPopping:nav];
        [self.revealSideViewController popViewControllerAnimated:YES];
        [obj release];
    }
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
