//
//  OrderPlacedVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 20/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "OrderPlacedVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "MyCartVC.h"
#import "ObjectClass.h"
#import "AppDelegate.h"
#import "OrderReviewCell.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"

@interface OrderPlacedVC ()

@end

@implementation OrderPlacedVC
@synthesize btnLeftMenu,btnCart,btnBack,OrderID,lblBillName,lblBillAddress,lblBillState,lblBillCountry,lblBillTelephone,lblShipName,lblShipAddress,lblShipState,lblShipCountry,lblShipTelephone,tblOrderDetails,lblEmptyCart,lblGT,lblShipppingMethod,lblShippingCharges,Scroll,GrandTotalView,ViewContainingTable,From,PassedOrderID;
AppDelegate *app;
float GT;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    [Scroll setContentSize:CGSizeMake(Scroll.frame.size.width, Scroll.frame.size.height)];
    app = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    //app.OrderArr = [[NSMutableArray alloc]init];
    
    ObjectClass *objClass = [[ObjectClass alloc]init];
    objClass=[app.COArr objectAtIndex:0];
    NSLog(@"BillingInfo.......");
    NSLog(@"objClass.coAs = %@",objClass.coAs);
    NSLog(@"objClass.coFirstName = %@",objClass.coFirstName);
    NSLog(@"objClass.coLastName = %@",objClass.coLastName);
    NSLog(@"objClass.coCompany = %@",objClass.coCompany);
    NSLog(@"objClass.coEmailAddress = %@",objClass.coEmailAddress);
    NSLog(@"objClass.coAddress = %@",objClass.coAddress);
    NSLog(@"objClass.coCity = %@",objClass.coCity);
    NSLog(@"objClass.coState = %@",objClass.coState);
    NSLog(@"objClass.coZipCode = %@",objClass.coZipCode);
    NSLog(@"objClass.coCountry = %@",objClass.coCountry);
    NSLog(@"objClass.coTelephone = %@",objClass.coTelephone);
    NSLog(@"objClass.coFax = %@",objClass.coFax);
    NSLog(@"objClass.coShipTo = %@",objClass.coShipTo);
    NSLog(@"ShippingInfo.......");
    NSLog(@"objClass.coShipFirstName = %@",objClass.coShipFirstName);
    NSLog(@"objClass.coShipLastName = %@",objClass.coShipLastName);
    NSLog(@"objClass.coShipCompany = %@",objClass.coShipCompany);
    NSLog(@"objClass.coShipAddress = %@",objClass.coShipAddress);
    NSLog(@"objClass.coShipCity = %@",objClass.coShipCity);
    NSLog(@"objClass.coShipState = %@",objClass.coShipState);
    NSLog(@"objClass.coShipZipCode = %@",objClass.coShipZipCode);
    NSLog(@"objClass.coShipCountry = %@",objClass.coShipCountry);
    NSLog(@"objClass.coShipTelephone = %@",objClass.coShipTelephone);
    NSLog(@"objClass.coShipFax = %@",objClass.coShipFax);
    NSLog(@"Methods.......");
    NSLog(@"objClass.coShippingMethod = %@",objClass.coShippingMethod);
    NSLog(@"objClass.coPaymentMethod = %@",objClass.coPaymentMethod);
    
    lblBillName.text = objClass.coFirstName;
    lblBillAddress.text = objClass.coAddress;
    lblBillState.text = objClass.coShipState;
    lblBillCountry.text = objClass.coCountry;
    lblBillTelephone.text = objClass.coTelephone;
    
    lblShipName.text = objClass.coShipFirstName;
    lblShipAddress.text = objClass.coShipAddress;
    lblShipState.text = objClass.coShipState;
    lblShipCountry.text = objClass.coShipCountry;
    lblShipTelephone.text = objClass.coShipTelephone;
    
    GT=GT+[objClass.ProductPrice floatValue];
    lblGT.text = [NSString stringWithFormat:@"%.2f",GT];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *cartId = [defaults objectForKey:@"cartId"];
    WebApiController *obj=[[WebApiController alloc]init];
    NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
    
    [param setValue:cartId forKey:@"cart_id"];
    [param setValue:objClass.coFirstName forKey:@"fname"];
    [param setValue:objClass.coLastName forKey:@"lname"];
    [param setValue:objClass.coAddress forKey:@"street"];
    [param setValue:objClass.coCity forKey:@"city"];
    [param setValue:objClass.coState forKey:@"state"];
    [param setValue:objClass.coTelephone forKey:@"tele"];
    [param setValue:objClass.coZipCode forKey:@"postcode"];
    [param setValue:objClass.coCountry forKey:@"country"];
    
    [param setValue:objClass.coShipFirstName forKey:@"Sfname"];
    [param setValue:objClass.coShipLastName forKey:@"Slname"];
    [param setValue:objClass.coShipAddress forKey:@"Sstreet"];
    [param setValue:objClass.coShipCity forKey:@"Scity"];
    [param setValue:objClass.coShipState forKey:@"Sstate"];
    [param setValue:objClass.coShipCountry forKey:@"Scountry"];
    [param setValue:objClass.coShipZipCode forKey:@"Spostcode"];
    [param setValue:objClass.coShipTelephone forKey:@"Stele"];
    [param setValue:app.SelectedPaymentMethod forKey:@"Pmethod"];
    
    [param setValue:app.SelectedShippingMethod forKey:@"Smethod"];
    
    
    [param setValue:objClass.strCCCid forKey:@"cid"];
    
    [param setValue:objClass.strCCNumber forKey:@"cNumber"];
    [param setValue:objClass.strCardType forKey:@"type"];
    [param setValue:objClass.strCCYear forKey:@"year"];
    [param setValue:objClass.strCCMonth forKey:@"month"];
    
    [obj callAPI_GET:@"getOrder.php" andParams:param SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
    
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
}
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
        NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"json dictionary:: %@",jsonDictionary);
    NSLog(@"COUNT %d",[jsonDictionary count]);
   
        for (int i=0; i<[jsonDictionary count]; i++)
        {
             ObjectClass *obj = [[ObjectClass alloc]init];
            [obj setStrOrderID:[jsonDictionary valueForKey:@"order_id"]];
            
            
            [app.OrderArr addObject:obj];
        }
    ObjectClass *objClass = [[ObjectClass alloc]init];
    objClass=[app.OrderArr objectAtIndex:0];
      OrderID.text = objClass.strOrderID;
    NSLog(@"order id :: %@",objClass.strOrderID);
    
      
    [app.ProductsObjArr removeAllObjects];
    
        [SVProgressHUD dismiss];
    
        
}
-(IBAction)btnLeftMenuClick:(id)sender
{
    LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
    [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
    [obj release];
}
-(IBAction)btnCartClick:(id)sender
{
    MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:obj animated:YES];
    [obj release];
}
-(IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(void)RemoveFromCart
{
    sqlite3_stmt *addStmt = nil;
    app = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    sqlite3 *database;
	if(sqlite3_open([[app getDBPath] UTF8String], &database) == SQLITE_OK)
    {
        NSString *DeleteQuery=[NSString stringWithFormat:@"delete from tblProduct where Email_ID='%@'",app.Email_ID];
        NSLog(@"DeleteQuery = %@",DeleteQuery);
        const char *Delete_Query=[DeleteQuery UTF8String];
        if(sqlite3_prepare_v2(database,Delete_Query,-1,&addStmt,NULL)==SQLITE_OK)
        {
            if(sqlite3_step(addStmt) == SQLITE_DONE)
            {
                NSLog(@"Done");
            }
        }
        sqlite3_finalize(addStmt);
        sqlite3_close(database);
    }
}

#pragma
#pragma mark - TableView Methods...
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    NSLog(@"app.ProductsObjArr.count = %d",[app.ProductsObjArr count]);
    return [app.ProductsObjArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"OrderReviewCell";
    OrderReviewCell *cell = (OrderReviewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OrderReviewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.ProductsObjArr objectAtIndex:[indexPath row]];
     cell.lblNo.text=[NSString stringWithFormat:@"%d",[indexPath row]+1];
        cell.lblName.text=obj.ProductTitle;
        cell.lblQty.text=@"1";
        cell.lblPrice.text=obj.ProductPrice;
  
    return cell;
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
