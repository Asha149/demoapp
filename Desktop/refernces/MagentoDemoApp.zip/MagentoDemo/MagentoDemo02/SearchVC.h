//
//  SearchVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 07/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SearchVC : UIViewController <UITableViewDelegate, UITableViewDataSource, UISearchBarDelegate, UISearchDisplayDelegate>
{
    UIButton *btnLeftMenu,*btnCart;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart;
@property (nonatomic, strong) IBOutlet UITableView *tableView;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
@property (strong,nonatomic) NSArray *candyArray;
@property (strong,nonatomic) NSMutableArray *filteredCandyArray;
@property (nonatomic,retain) IBOutlet UISearchBar *candySearchBar;

@end
