//
//  ThirdCategoryVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 25/12/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "ThirdCategoryVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"
#import "ObjectClass.h"
#import "AppDelegate.h"
#import "ProductsVC.h"
#import "MyCartVC.h"
#import "LoginVC.h"
#import "SubCatClass.h"
#import "ThirdCategory.h"

@interface ThirdCategoryVC ()

@end

@implementation ThirdCategoryVC
@synthesize btnLeftMenu,btnCart,btnBack,MainCategoryID,tblSubCategories,btnLoginLink,lblHeading,HeadingName,strSubCategoryId,strParentId;
AppDelegate *app;
int selectedIndex;
    
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    NSLog(@"MainCategoryID = %@",MainCategoryID);
    lblHeading.text=HeadingName;
    if (!(app.UserFname.length==0))
    [btnLoginLink setTitle:app.UserFname forState:UIControlStateNormal];
    app.SubCategoryObjArr = [[NSMutableArray alloc]init];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
- (void)viewWillAppear:(BOOL)animated
    {
        [super viewWillAppear:YES];
        app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
        
        WebApiController *obj=[[WebApiController alloc]init];
        
        NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
        [param setValue:MainCategoryID forKey:@"pid"];
        
        [obj callAPI_GET:@"webservice.php" andParams:param SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
        [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
    }
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    
    
        NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
        NSLog(@"Json dictionary :: %@",jsonDictionary);
        // NSLog(@"parent id :: %@",[[[[[[[jsonDictionary valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"] objectAtIndex:0] valueForKey:@"parent_id"]);
        
        if ([[[jsonDictionary valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"]) {
            
            
            NSMutableArray *arrCat=[[NSMutableArray alloc]init];
            
            arrCat=[[[jsonDictionary valueForKey:@"children"] objectAtIndex:0]valueForKey:@"children"];
            
            
            for (int i=0; i<[arrCat count]; i++)
            {
                if ([[arrCat objectAtIndex:i] objectForKey:@"category_id"])
                {
                    if ([MainCategoryID isEqualToString:[[arrCat objectAtIndex:i] objectForKey:@"category_id"]]) {
                        
                        NSMutableArray *arrSubCat=[[NSMutableArray alloc]init];
                        
                        if ([[arrCat objectAtIndex:i]  valueForKey:@"children"])
                        {
                            arrSubCat=[[arrCat objectAtIndex:i]  valueForKey:@"children"];
                           
                            for (int j=0; j<[arrSubCat count]; j++)
                            {
                                
                                NSMutableArray *arrTSubCat=[[NSMutableArray alloc]init];
                                
                                if ([[arrSubCat objectAtIndex:j]  valueForKey:@"children"])
                                {
                                    arrTSubCat=[[arrSubCat objectAtIndex:j]  valueForKey:@"children"];
                                    
                                    
                                    
                                        for (int k=0; k<[arrTSubCat count]; k++)
                                        {
                                            if ([strSubCategoryId isEqualToString:[[arrTSubCat objectAtIndex:k] objectForKey:@"parent_id"]])
                                            {

                                                
                                            ThirdCategory *obj = [[ThirdCategory alloc]init];
                                            [obj setStrThirdCategoryId:[[arrTSubCat objectAtIndex:k] objectForKey:@"category_id"]];
                                            [obj setStrThirdCategory:[[arrTSubCat objectAtIndex:k] objectForKey:@"name"]];
                                            
                                            NSLog(@" third sub category:: %@",[[arrTSubCat objectAtIndex:k] objectForKey:@"name"]);
                                            
                                            [app.SubCategoryObjArr addObject:obj];
                                                  }
                                        }
                                        
//
                                    
                                }
                            }
                 
                        }
                    }
                    
                }
                
                
            }
            
        }
        [tblSubCategories reloadData];
    
    [SVProgressHUD dismiss];
    
}
-(IBAction)btnCartClick:(id)sender
    {
        MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:obj animated:YES];
        [obj release];
    }
-(IBAction)btnLoginLinkClick:(id)sender
    {
        if (app.UserFname.length==0)
        {
            LoginVC *objVC = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:objVC animated:YES];
            [objVC release];
        }
    }
-(IBAction)btnBack:(id)sender
    {
        [self.navigationController popViewControllerAnimated:YES];
    }
    
#pragma
#pragma mark - TableView Methods...
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
    {
        return 50;
    }
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
    {
        return [app.SubCategoryObjArr count];
    }
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
    {
        static NSString *CellIdentifier = @"Cell";
        UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
        if (cell == nil) {
            cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
        }
        ThirdCategory *obj = [[ThirdCategory alloc]init];
        obj=[app.SubCategoryObjArr objectAtIndex:[indexPath row]];
        cell.textLabel.text=obj.strThirdCategory;
        return cell;
    }
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
    {
        selectedIndex=[indexPath row];
        ThirdCategory *obj = [[ThirdCategory alloc]init];
        obj=[app.SubCategoryObjArr objectAtIndex:[indexPath row]];
        ProductsVC *objVC = [[ProductsVC alloc] initWithNibName:@"ProductsVC" bundle:[NSBundle mainBundle]];
        objVC.SubCategoryID=obj.strThirdCategoryId;
        objVC.SubCategoryAttribID=obj.strParentId;
        objVC.HeadingName=obj.strThirdCategory;
        [self.navigationController pushViewController:objVC animated:YES];
        [obj release];
    }
    
-(IBAction)btnLeftMenuClick:(id)sender
    {
        LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
        [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
        [obj release];
    }

@end
