//
//  OrderReviewVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "OrderReviewVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "MyCartVC.h"
#import "OrderReviewCell.h"
#import "ObjectClass.h"
#import "AppDelegate.h"
#import "OrderPlacedVC.h"

@interface OrderReviewVC ()

@end

@implementation OrderReviewVC
@synthesize btnLeftMenu,btnCart,btnBack,btnPlaceOrder,tblOrderReview,lblEmptyCart,lblGT,lblShipppingMethod,lblShippingCharges;
NSString *str;
float GT;
AppDelegate *app;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    app = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    lblShipppingMethod.text=[NSString stringWithFormat:@"%@ Charge:",app.SelectedShippingMethod];
    
    if (![[[NSUserDefaults standardUserDefaults] objectForKey:@"FL"] isEqualToString:@"FL"])
    {
        [[NSUserDefaults standardUserDefaults] setValue:@"0" forKey:@"orderid"];
    }
    
   // [self FillOrders];
    
    ObjectClass *objClass = [[ObjectClass alloc]init];
    objClass=[app.ProductsObjArr objectAtIndex:0];
    
    
    
    GT=GT+[objClass.ProductPrice floatValue];
   lblGT.text = [NSString stringWithFormat:@"%.2f",GT];
}
-(void) FillOrders
{
    GT=0;
    app.ProductsObjArr = [[NSMutableArray alloc]init];
    NSString *sqLiteDb = [app getDBPath];
    if (sqlite3_open([sqLiteDb UTF8String], &_database) != SQLITE_OK)
    {
        NSLog(@"Failed to open database!");
    }
    sqlite3_stmt *stmt;
	NSString *str=[@""  stringByAppendingFormat:@"select * from tblProduct where Email_ID='%@'",app.Email_ID];
	const char *sql= [str cStringUsingEncoding:NSUTF8StringEncoding];
	int status;
	status= sqlite3_prepare_v2(_database,sql, -1, &stmt, NULL);
    
	if(status != SQLITE_OK)
	{
		NSLog(@"error preparing statement");
		exit(1);
	}
	while ((status=sqlite3_step(stmt)) == SQLITE_ROW)
	{
        char *pIdChar = (char *) sqlite3_column_text(stmt, 0);
        NSString *pIdString =[NSString stringWithFormat:@"%@",[[NSString alloc] initWithUTF8String:pIdChar]];
        
        NSString *pName=@"";
        char *pNameChar = (char *) sqlite3_column_text(stmt, 1);
        if (pNameChar!=NULL)
            pName =[NSString stringWithFormat:@"%@",[[NSString alloc] initWithUTF8String:pNameChar]];
        
        NSString *pPrice=@"";
        char *pPriceChar = (char *) sqlite3_column_text(stmt, 2);
        if (pPriceChar!=NULL)
            pPrice =[NSString stringWithFormat:@"%@",[[NSString alloc] initWithUTF8String:pPriceChar]];
        
        NSString *imagePath=@"";
        char *pImageChar = (char *) sqlite3_column_text(stmt, 3);
        if (pImageChar!=NULL)
            imagePath = [NSString stringWithFormat:@"%@",[[NSString alloc] initWithUTF8String:pImageChar]];
        
        ObjectClass *obj=[[ObjectClass alloc]init];
        [obj setPID:pIdString];
        [obj setProductTitle:pName];
        [obj setProductPrice:pPrice];
        [obj setProductImagePath:imagePath];
        [app.ProductsObjArr addObject:obj];
        GT=GT+[obj.ProductPrice floatValue];
	}
	sqlite3_finalize(stmt);
    if ([app.ProductsObjArr count]==0)
    {
        lblGT.text=@"000.00";
    }
    else
    {
        lblGT.text=[NSString stringWithFormat:@"%.02f",GT];
    }
    NSLog(@"GT = %.02f",GT);
    [tblOrderReview reloadData];
}

-(IBAction)btnLeftMenuClick:(id)sender
{
    str=@"menu";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
}
-(IBAction)btnCartClick:(id)sender
{
    str=@"cart";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"YES"])
    {
        if ([str isEqualToString:@"menu"])
        {
            LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
            [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
            [obj release];
        }
        else if ([str isEqualToString:@"cart"])
        {
            MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:obj animated:YES];
            [obj release];
        }
        
    }
    else if([title isEqualToString:@"NO"])
    {
        NSLog(@"Button 2 was selected.");
    }
}
-(IBAction)btnPlaceOrderClick:(id)sender
{
    NSLog(@"Order PLaced");
   // [self AddOrder:0];
    OrderPlacedVC *objVC = [[OrderPlacedVC alloc] initWithNibName:@"OrderPlacedVC" bundle:[NSBundle mainBundle]];
//    objVC.PassedOrderID = [NSString stringWithFormat:@"ORD%05d", [[[NSUserDefaults standardUserDefaults] objectForKey:@"orderid"] intValue]];
//    objVC.From=@"OrderReview";
    [self.navigationController pushViewController:objVC animated:YES];
    [objVC release];
}
-(void)AddOrder:(int)index
{
    NSLog(@"Index = %d",index);
    [[NSUserDefaults standardUserDefaults] setValue:@"FL" forKey:@"FL"];
    [[NSUserDefaults standardUserDefaults] setValue:[NSString stringWithFormat:@"%d",[[[NSUserDefaults standardUserDefaults] objectForKey:@"orderid"] intValue]+1] forKey:@"orderid"];
    
    NSLog(@"orderid = %d",[[[NSUserDefaults standardUserDefaults] objectForKey:@"orderid"] intValue]);
    NSString *OID = [NSString stringWithFormat:@"ORD%05d", [[[NSUserDefaults standardUserDefaults] objectForKey:@"orderid"] intValue]];
    NSLog(@"orderid = %@",OID);
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj = [app.COArr objectAtIndex:index];
    sqlite3_stmt *addStmt = nil;
    app = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    sqlite3 *database;
	if(sqlite3_open([[app getDBPath] UTF8String], &database) == SQLITE_OK)
    {
        NSString *insertQuery=[NSString stringWithFormat:@"insert into tblOrderDetails(oOrderID,oBillFirstName,oBillLastName,oBillCompany,oBillEmailAddress,oBillAddress,oBillCity,oBillState,oBillZipCode,oBillCountry,oBillTelephone,oBillFax,oShipFirstName,oShipLastName,oShipCompany,oShipAddress,oShipCity,oShipState,oShipZipCode,oShipCountry,oShipTelephone,oShipFax,oShippingMethod,oPaymentMethod,oGrandTotal,oAs) values('%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@','%@')",OID,obj.coFirstName,obj.coLastName,obj.coCompany,obj.coEmailAddress,obj.coAddress,obj.coCity,obj.coState,obj.coZipCode,obj.coCountry,obj.coTelephone,obj.coFax,obj.coShipFirstName,obj.coShipLastName,obj.coShipCompany,obj.coShipAddress,obj.coShipCity,obj.coShipState,obj.coShipZipCode,obj.coShipCountry,obj.coShipTelephone,obj.coShipFax,obj.coShippingMethod,obj.coPaymentMethod,[NSString stringWithFormat:@"%.02f",GT],obj.coAs];
        const char *insert_Query=[insertQuery UTF8String];
        if(sqlite3_prepare_v2(database,insert_Query,-1,&addStmt,NULL)==SQLITE_OK)
        {
            if(sqlite3_step(addStmt) == SQLITE_DONE)
            {
                NSLog(@"Done");
            }
        }
        sqlite3_finalize(addStmt);
        sqlite3_close(database);
    }
}


#pragma
#pragma mark - TableView Methods...
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 80;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [app.ProductsObjArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"OrderReviewCell";
    OrderReviewCell *cell = (OrderReviewCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"OrderReviewCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.ProductsObjArr objectAtIndex:[indexPath row]];
    cell.lblNo.text=[NSString stringWithFormat:@"%d",[indexPath row]+1];
    cell.lblName.text=obj.ProductTitle;
    cell.lblQty.text=@"1";
    cell.lblPrice.text=obj.ProductPrice;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
