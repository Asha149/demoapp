//
//  RegistrationVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 14/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface RegistrationVC : UIViewController <UITextFieldDelegate,UIScrollViewDelegate>
{
    UIButton *btnBack,*btnCart;
    UIButton *btnRegister,*btnCancel;
    UITextField *txtFirstName,*txtLastName,*txtEmailAddress,*txtUserName,*txtPassword,*txtConfirmPass;
    UIScrollView *Scroll;
}
@property (nonatomic,retain) IBOutlet UIButton *btnBack,*btnCart;
@property (nonatomic,retain) IBOutlet UIButton *btnRegister,*btnCancel;
@property (nonatomic,retain) IBOutlet UITextField *txtFirstName,*txtLastName,*txtEmailAddress,*txtUserName,*txtPassword,*txtConfirmPass;
@property (nonatomic,retain) IBOutlet UIScrollView *Scroll;
@property (nonatomic,retain) NSString *From;

-(IBAction)btnBackClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnCancelClick:(id)sender;
-(IBAction)btnRegisterClick:(id)sender;
@end
