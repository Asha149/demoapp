//
//  ShippingMethodVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ShippingMethodVC : UIViewController <UITableViewDelegate,UITableViewDataSource>
{
    UIButton *btnLeftMenu,*btnCart,*btnBack,*btnContinue;
    UITableView *tblShippingMethods;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart,*btnBack,*btnContinue;
@property (nonatomic,retain) IBOutlet UITableView *tblShippingMethods;
@property (nonatomic,retain) NSString *checked;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnBack:(id)sender;
-(IBAction)btnContinueClick:(id)sender;
@end
