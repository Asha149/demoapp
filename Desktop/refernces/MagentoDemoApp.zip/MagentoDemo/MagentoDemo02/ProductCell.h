//
//  ProductCell.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 08/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ProductCell : UITableViewCell
{
    UILabel *lblProductName,*lblProductPrice,*lblProductDiscount;
    UIButton *btnBuy,*btnAddtoCart,*btnShare;
    UIImageView *imgProductImage;
}
@property (nonatomic,retain) IBOutlet UILabel *lblProductName,*lblProductPrice,*lblProductDiscount;
@property (nonatomic,retain) IBOutlet UIButton *btnBuy,*btnAddtoCart,*btnShare;
@property (nonatomic,retain) IBOutlet UIImageView *imgProductImage;
@end
