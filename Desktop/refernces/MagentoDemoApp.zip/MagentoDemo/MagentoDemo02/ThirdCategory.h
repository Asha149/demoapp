//
//  ThirdCategory.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 25/12/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ThirdCategory : NSObject
    {
    
    }
    @property (nonatomic,retain)NSString *strThirdCategoryId;
    @property (nonatomic,retain)NSString *strThirdCategory;
    @property (nonatomic,retain)NSString *strParentId;
@property (nonatomic,retain)NSString *proImages;
@end
