//
//  SubCatClass.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 25/12/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "SubCatClass.h"

@implementation SubCatClass
    
@synthesize strSubCategory,strSubCategoryId,strParentId;
    
@end
