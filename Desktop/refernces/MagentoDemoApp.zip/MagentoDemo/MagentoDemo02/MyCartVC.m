//
//  MyCartVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 07/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "MyCartVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"
#import "ObjectClass.h"
#import "AppDelegate.h"
#import "ProductCell.h"
#import <QuartzCore/QuartzCore.h>
#import "FbFriendscell.h"
#import "ProductDetailsVC.h"
#import "UIImageView+WebCache.h"
#import "COMethodVC.h"
#import "BillingInfoVC.h"
#import "MyCartCell.h"

#define kPayPalClientId @"ASsazRAkZwO39boHijFvz1VfsviFXu0uhJiN934PbQ7FTq2uXEcMKsPfC8bY"
#define kPayPalReceiverEmail @"nirmal.lanet-facilitator@gmail.com"
#define kSampleAppKey @"c2fd85bdf5c14cbf8b482f5267212c38"

@interface MyCartVC ()
@property(nonatomic, strong, readwrite) IBOutlet UIButton *payButton;
@property(nonatomic, strong, readwrite) IBOutlet UIView *successView;
@end

@implementation MyCartVC
@synthesize btnLeftMenu,tblCartProducts,btnFacebook,btnTwitter,btnEmail,btnCancel,tempImageView,SharePopUpView,MainCategoryID,SubCategoryID,facebook,friends_tblvw,lblEmptyCart,lblGT,btnCheckOut,HeadingPopUp;
NSMutableArray *friendsArr;
float GT;
AppDelegate *app;
int pId;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    SharePopUpView.layer.cornerRadius=1;
    SharePopUpView.layer.borderColor=[[UIColor darkGrayColor]CGColor];
    SharePopUpView.layer.borderWidth=2;
    
    ///Paypal...
    self.title = @"Payment via PayPal";
    self.acceptCreditCards = YES;
    //self.environment = PayPalEnvironmentNoNetwork;
    self.successView.hidden = YES;
    ///---
    
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    app.ProductsObjArr = [[NSMutableArray alloc]init];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    
   // [self FillCart];
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *cartId = [defaults objectForKey:@"cartId"];
    WebApiController *obj=[[WebApiController alloc]init];
    
    NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
   
    
    [param setValue:cartId forKey:@"cart_id"];
    
    
    [obj callAPI_GET:@"getProductsFrmCart.php" andParams:param SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
    
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
    
    UIEdgeInsets insets = UIEdgeInsetsMake(0, 15.0f, 0, 14.0f);
    UIImage *payBackgroundImage = [[UIImage imageNamed:@"button_secondary.png"] resizableImageWithCapInsets:insets];
    UIImage *payBackgroundImageHighlighted = [[UIImage imageNamed:@"button_secondary_selected.png"] resizableImageWithCapInsets:insets];
    [self.payButton setBackgroundImage:payBackgroundImage forState:UIControlStateNormal];
    [self.payButton setBackgroundImage:payBackgroundImageHighlighted forState:UIControlStateHighlighted];
    [self.payButton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateNormal];
    [self.payButton setTitleColor:[UIColor darkGrayColor] forState:UIControlStateHighlighted];
    
    // Optimization: Prepare for display of the payment UI by getting network work done early
//    [PayPalPaymentViewController setEnvironment:self.environment];
//    [PayPalPaymentViewController prepareForPaymentUsingClientId:kPayPalClientId];
}
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"Json dictionary :: %@",jsonDictionary);
    
    for (int i=0; i<[jsonDictionary count]; i++)
    {
        ObjectClass *obj = [[ObjectClass alloc]init];
        
        [obj setProductID:[[[jsonDictionary valueForKey:@"ProductDetail"] objectAtIndex:i] valueForKey:@"product_id"]];
        
        [obj setProductTitle:[[[jsonDictionary valueForKey:@"ProductDetail"] objectAtIndex:i] valueForKey:@"name"]];
        [obj setProductPrice:[[[jsonDictionary valueForKey:@"ProductDetail"] objectAtIndex:i] valueForKey:@"price"]];
        [obj setProductDesc:[[[jsonDictionary valueForKey:@"ProductDetail"]objectAtIndex:i]valueForKey:@"description"]];
        [obj setProductImagePath:[[[[jsonDictionary objectAtIndex:i] valueForKey:@"ProductImage"]objectAtIndex:0]valueForKey:@"url"]];
        
        
        if ([obj.ProductTitle isEqual:[NSNull null]])
            obj.ProductTitle=@"No Title Available";
        
        if ([obj.ProductPrice isEqual:[NSNull null]])
            obj.ProductPrice=@"$ 123.45";
        
        if ([obj.ProductDesc isEqual:[NSNull null]])
            obj.ProductDesc=@"No Description";
        
        if ([obj.ProductImagePath isEqual:[NSNull null]])
            obj.ProductImagePath=@"NoImage";
        
        NSLog(@"Object.ProductID = %@",obj.ProductID);
        //NSLog(@"Object.ProductAttribID = %@",obj.ProductAttribID);
        NSLog(@"Object.ProductTitle = %@",obj.ProductTitle);
        NSLog(@"Object.ProductPrice = %@",obj.ProductPrice);
        NSLog(@"Object.ProductDesc = %@",obj.ProductDesc);
        
        //NSLog(@"Object.ImagePath = %@",obj.ProductImagePath);
        [app.ProductsObjArr addObject:obj];
        GT=GT+[obj.ProductPrice floatValue];
        lblGT.text = [NSString stringWithFormat:@"%.2f",GT];
    }
    
    [tblCartProducts setDataSource:self];
    [tblCartProducts setDelegate:self];
    [tblCartProducts reloadData];
    
    [SVProgressHUD dismiss];
}

-(void) FillCart
{
    if (app.Email_ID.length==0)
    {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Warning"
                              message:@"Please Login to view your Cart."
                              delegate:self
                              cancelButtonTitle:@"Ok"
                              otherButtonTitles:nil,
                              nil];
        [alert show];
        [tblCartProducts setHidden:YES];
        [HeadingPopUp setHidden:YES];
        [lblEmptyCart setHidden:NO];
        lblGT.text=@"000.00";
    }
    else
    {
        GT=0;
        app.ProductsObjArr = [[NSMutableArray alloc]init];
        NSString *sqLiteDb = [app getDBPath];
        if (sqlite3_open([sqLiteDb UTF8String], &_database) != SQLITE_OK)
        {
            NSLog(@"Failed to open database!");
        }
        sqlite3_stmt *stmt;
        NSString *str=[@""  stringByAppendingFormat:@"select * from tblProduct where Email_ID='%@'",app.Email_ID];
        const char *sql= [str cStringUsingEncoding:NSUTF8StringEncoding];
        int status;
        status= sqlite3_prepare_v2(_database,sql, -1, &stmt, NULL);
        
        if(status != SQLITE_OK)
        {
            NSLog(@"error preparing statement");
            exit(1);
        }
        
        while ((status=sqlite3_step(stmt)) == SQLITE_ROW)
        {
            NSLog(@"%s",sqlite3_column_text(stmt, 0));
            
            char *pIdChar = (char *) sqlite3_column_text(stmt, 0);
            NSString *pIdString =[NSString stringWithFormat:@"%@",[[NSString alloc] initWithUTF8String:pIdChar]];
            
            NSString *pName=@"";
            char *pNameChar = (char *) sqlite3_column_text(stmt, 1);
            if (pNameChar!=NULL)
                pName =[NSString stringWithFormat:@"%@",[[NSString alloc] initWithUTF8String:pNameChar]];
            
            NSString *pPrice=@"";
            char *pPriceChar = (char *) sqlite3_column_text(stmt, 2);
            if (pPriceChar!=NULL)
                pPrice =[NSString stringWithFormat:@"%@",[[NSString alloc] initWithUTF8String:pPriceChar]];
            
            NSString *imagePath=@"";
            char *pImageChar = (char *) sqlite3_column_text(stmt, 3);
            if (pImageChar!=NULL)
                imagePath = [NSString stringWithFormat:@"%@",[[NSString alloc] initWithUTF8String:pImageChar]];
            
            ObjectClass *obj=[[ObjectClass alloc]init];
            [obj setPID:pIdString];
            [obj setProductTitle:pName];
            [obj setProductPrice:pPrice];
            [obj setProductImagePath:imagePath];
            [app.ProductsObjArr addObject:obj];
            GT=GT+[obj.ProductPrice floatValue];
        }
        sqlite3_finalize(stmt);
        if ([app.ProductsObjArr count]==0)
        {
            [tblCartProducts setHidden:YES];
            [HeadingPopUp setHidden:YES];
            [lblEmptyCart setHidden:NO];
            lblGT.text=@"000.00";
        }
        else
        {
            [tblCartProducts setHidden:NO];
            [HeadingPopUp setHidden:NO];
            [lblEmptyCart setHidden:YES];
            [tblCartProducts reloadData];
            lblGT.text=[NSString stringWithFormat:@"%.02f",GT];
        }
    }
}
-(IBAction)btnFacebookClick:(id)sender
{
    facebook = [[Facebook alloc] initWithAppId:@"156935734460987" andDelegate:self];
    [facebook extendAccessTokenIfNeeded];
    [self apiDialogRequestsSendToMany];
    
    [SharePopUpView setHidden:YES];
    [tempImageView setHidden:YES];
    [tblCartProducts setUserInteractionEnabled:YES];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:SharePopUpView cache:YES];
    [UIView commitAnimations];
}
-(IBAction)btnTwitterClick:(id)sender
{
    [self buildTweetSheet];
    [self presentViewController:tweetSheet animated:YES completion:nil];
    
    [SharePopUpView setHidden:YES];
    [tempImageView setHidden:YES];
    [tblCartProducts setUserInteractionEnabled:YES];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:SharePopUpView cache:YES];
    [UIView commitAnimations];
}
-(IBAction)btnEmailClick:(id)sender
{
    MFMailComposeViewController *mailComposer  = [[MFMailComposeViewController alloc] init];
    mailComposer.mailComposeDelegate = self;
    mailComposer.navigationBar.tintColor = [UIColor blackColor];
    [mailComposer setModalPresentationStyle:UIModalPresentationFormSheet];
    [mailComposer setSubject:@"Shopping Cart App Share"];
    [mailComposer setMessageBody:@"This is link for sharing.." isHTML:YES];
    [self presentViewController:mailComposer animated:YES completion:nil];
    [mailComposer release];
    
    [SharePopUpView setHidden:YES];
    [tempImageView setHidden:YES];
    [tblCartProducts setUserInteractionEnabled:YES];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:SharePopUpView cache:YES];
    [UIView commitAnimations];
}
-(IBAction)btnCancelClick:(id)sender
{
    [SharePopUpView setHidden:YES];
    [tempImageView setHidden:YES];
    [tblCartProducts setUserInteractionEnabled:YES];
    
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:SharePopUpView cache:YES];
    [UIView commitAnimations];
}
-(IBAction)btnCheckOutClick:(id)sender
{
    if ([app.ProductsObjArr count]==0)
    {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Warning"
                              message:@"There is no item in your Cart, You cant CheckOut."
                              delegate:self
                              cancelButtonTitle:@"Ok"
                              otherButtonTitles:nil,
                              nil];
        [alert show];
    }
    else
    {
        if([app.strCustomer_id intValue]!=0)
        {
            BillingInfoVC *vc = [[BillingInfoVC alloc]initWithNibName:@"BillingInfoVC" bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:vc animated:YES];
            [vc release];

        }
        else
        {
        COMethodVC *objVC = [[COMethodVC alloc]initWithNibName:@"COMethodVC" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
        }
    }
}


#pragma
#pragma mark - TableView Methods...
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    
    return 85;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [app.ProductsObjArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{

    
    static NSString *simpleTableIdentifier = @"MyCartCell";
    MyCartCell *cell = (MyCartCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"MyCartCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.ProductsObjArr objectAtIndex:[indexPath row]];
    cell.lblProductName.text=obj.ProductTitle;
    cell.lblProductPrice.text=obj.ProductPrice;
    [cell.imgProductImage setImageWithURL:[NSURL URLWithString:obj.ProductImagePath]];
    cell.lblProductQty.text=@"1";
    [cell.btnRemove setTag: [obj.ProductID intValue]];
    [cell.btnRemove addTarget:self action:@selector(btnRemoveClick:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.ProductsObjArr objectAtIndex:[indexPath row]];
    ProductDetailsVC *objVC = [[ProductDetailsVC alloc] initWithNibName:@"ProductDetailsVC" bundle:[NSBundle mainBundle]];
    objVC.ProductID=obj.MainCategoryID;
    objVC.From=@"Cart";
    objVC.ProductRow=[NSString stringWithFormat:@"%d",[indexPath row]];
    objVC.HeadingName=@"My Cart";
    [self.navigationController pushViewController:objVC animated:YES];
    [obj release];
}
-(void)btnBuyClick: (id) sender
{
    COMethodVC *objVC = [[COMethodVC alloc]initWithNibName:@"COMethodVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:objVC animated:YES];
    [objVC release];
//    self.completedPayment = nil;
//    PayPalPayment *payment = [[PayPalPayment alloc] init];
//    payment.amount = [[NSDecimalNumber alloc] initWithString:@"9.95"];
//    payment.currencyCode = @"USD";
//    payment.shortDescription = @"Hipster t-shirt";
//    if (!payment.processable){}
//    NSString *customerId = @"user-11723";
//    [PayPalPaymentViewController setEnvironment:self.environment];
//    PayPalPaymentViewController *paymentViewController = [[PayPalPaymentViewController alloc] initWithClientId:kPayPalClientId
//                                                                                                 receiverEmail:kPayPalReceiverEmail
//                                                                                                       payerId:customerId
//                                                                                                       payment:payment
//                                                                                                      delegate:self];
//    paymentViewController.hideCreditCardButton = !self.acceptCreditCards;
//    paymentViewController.languageOrLocale = @"en";
//    [self presentViewController:paymentViewController animated:YES completion:nil];
}
-(IBAction)btnRemoveClick:(id)sender
{
    [self RemoveFromCart:[NSString stringWithFormat:@"%d",[sender tag]]];
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Product is  Removed from your Cart."
                          delegate:self
                          cancelButtonTitle:@"Ok"
                          otherButtonTitles:nil,
                          nil];
    [alert show];
    [self FillCart];
}
-(void)btnShareClick: (id) sender
{
    [SharePopUpView setHidden:NO];
    [tempImageView setHidden:NO];
    [tblCartProducts setUserInteractionEnabled:NO];
    [UIView beginAnimations:nil context:nil];
    [UIView setAnimationDuration:1.0];
    [UIView setAnimationDelegate:self];
    [UIView setAnimationTransition:UIViewAnimationTransitionNone forView:SharePopUpView cache:YES];
    [UIView commitAnimations];
}
-(void)RemoveFromCart: (NSString *) pro_id
{
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *cartId = [defaults objectForKey:@"cartId"];
    WebApiController *obj=[[WebApiController alloc]init];
    
    NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
    
    
    [param setValue:cartId forKey:@"cart_id"];
    [param setValue:pro_id forKey:@"pid"];
    
    [obj callAPI_GET:@"Cart_product.remove.php" andParams:param SuccessCallback:@selector(service_reponse1:Response:) andDelegate:self];
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
}
-(void)service_reponse1:(NSString *)apiAlias Response:(NSData *)response
{
        NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
        NSLog(@"Json dictionary :: %@",jsonDictionary);
    [tblCartProducts reloadData];
    [SVProgressHUD dismiss];
    
}



#pragma mark
#pragma mark - Proof of payment validation...
- (void)sendCompletedPaymentToServer:(PayPalPayment *)completedPayment
{
    // TODO: Send completedPayment.confirmation to server
    NSLog(@"Here is your proof of payment:\n\n%@\n\nSend this to your server for confirmation and fulfillment.", completedPayment.confirmation);
}

#pragma mark
#pragma mark - PayPalPaymentDelegate methods...
- (void)payPalPaymentDidComplete:(PayPalPayment *)completedPayment
{
    NSLog(@"PayPal Payment Success!");
    self.completedPayment = completedPayment;
    self.successView.hidden = NO;
    
    [self sendCompletedPaymentToServer:completedPayment]; // Payment was processed successfully; send to server for verification and fulfillment
    [self dismissViewControllerAnimated:YES completion:nil];
}
- (void)payPalPaymentDidCancel
{
    NSLog(@"PayPal Payment Canceled");
    self.completedPayment = nil;
    self.successView.hidden = YES;
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark
#pragma mark - Flipside View Controller...
- (void)flipsideViewControllerDidFinish:(ZZFlipsideViewController *)controller
{
    if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPhone) {
        [self dismissViewControllerAnimated:YES completion:nil];
    } else {
        [self.flipsidePopoverController dismissPopoverAnimated:YES];
        self.flipsidePopoverController = nil;
    }
}
- (void)popoverControllerDidDismissPopover:(UIPopoverController *)popoverController
{
    self.flipsidePopoverController = nil;
}
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender
{
    if ([[segue identifier] isEqualToString:@"showAlternate"]) {
        [[segue destinationViewController] setDelegate:self];
        
        if ([[UIDevice currentDevice] userInterfaceIdiom] == UIUserInterfaceIdiomPad) {
            UIPopoverController *popoverController = [(UIStoryboardPopoverSegue *)segue popoverController];
            self.flipsidePopoverController = popoverController;
            popoverController.delegate = self;
        }
    }
}
- (IBAction)togglePopover:(id)sender
{
    if (self.flipsidePopoverController) {
        [self.flipsidePopoverController dismissPopoverAnimated:YES];
        self.flipsidePopoverController = nil;
    } else {
        [self performSegueWithIdentifier:@"showAlternate" sender:sender];
    }
}
- (BOOL)prefersStatusBarHidden
{
    return YES;
}







- (void)apiDialogRequestsSendToMany {
    currentAPICall = kDialogRequestsSendToMany;
    SBJSON *jsonWriter = [[SBJSON new] autorelease];
    NSDictionary *gift = [NSDictionary dictionaryWithObjectsAndKeys:
                          @"5", @"social_karma",
                          @"1", @"badge_of_awesomeness",
                          nil];
    
    NSString *giftStr = [jsonWriter stringWithObject:gift];
    NSMutableDictionary* params = [NSMutableDictionary dictionaryWithObjectsAndKeys:
                                   @"Learn how to make your iOS apps social.",  @"message",
                                   @"Check this out", @"notification_text",
                                   giftStr, @"data",
                                   nil];
    
    
    [[self facebook] dialog:@"apprequests"
                  andParams:params
                andDelegate:self];
    
    
}

-(IBAction)btnTwitter_click:(id)sender
{
    
    
}
- (void)buildTweetSheet{
    
    /* make instance of tweet sheet */
    tweetSheet = [[TWTweetComposeViewController alloc] init];
    
    //[tweetSheet setInitialText:(NSString *)[NSString stringWithFormat:@"@WordBookStore "]];
    
    [tweetSheet addURL:[NSURL URLWithString:@"http://www.google.com"]];
    //Specify the completion handler
    TWTweetComposeViewControllerCompletionHandler completionHandler = ^(TWTweetComposeViewControllerResult result){
        [self dismissModalViewControllerAnimated:YES];
    };
    
    
    [tweetSheet setCompletionHandler:completionHandler];
}
#pragma mark email sending
- (void)mailComposeController:(MFMailComposeViewController*)controller
          didFinishWithResult:(MFMailComposeResult)result
                        error:(NSError*)error
{
    @try{
        switch (result)
        {
            case MFMailComposeResultCancelled:
            {
                //NSLog(@"Mail cancelled: you cancelled the operation and no email message was queued.");
                
            }
                break;
            case MFMailComposeResultSaved:
            {
                // NSLog(@"Mail saved: you saved the email message in the drafts folder.");
                
            }
                break;
            case MFMailComposeResultSent:
            {
                //NSLog(@"Mail send: the email message is queued in the outbox. It is ready to send.");
                
                UIAlertView *v = [[UIAlertView alloc] initWithTitle:@"Done !!" message:@"Email is sent successfully." delegate:self cancelButtonTitle:@"OK" otherButtonTitles:nil];
                [v show];
                [v release];
            }
                break;
            case MFMailComposeResultFailed:
            {
                //NSLog(@"Mail failed: the email message was not saved or queued, possibly due to an error.");
                
            }
                break;
            default:
            {
                //NSLog(@"Mail not sent.");
                
            }
                break;
        }
    }
    @catch (NSException *exception) {
        
    }
    
    [self dismissViewControllerAnimated:YES completion:nil];
}


#pragma
#pragma mark -Facebook
-(void)postToWall
{
    currentAPICall=kAPIGraphUserFriends;
    
    NSURL *url;
    NSData *data;
    NSMutableDictionary *params = nil;
    NSString *id_string;
    
    
    id_string=[NSString stringWithFormat:@"me/Friends"];
    
    // [facebook requestWithGraphPath:id_string andParams:params andHttpMethod:@"POST" andDelegate:self];
    
    [facebook requestWithGraphPath:@"me/friends" andDelegate:self];
}

- (IBAction)facebookShareButtonPressed:(id)sender
{
    NSLog(@"Fb clicked...");
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    if ([defaults objectForKey:@"FBAccessTokenKey"]
        && [defaults objectForKey:@"FBExpirationDateKey"]) {
        facebook.accessToken = [defaults objectForKey:@"FBAccessTokenKey"];
        facebook.expirationDate = [defaults objectForKey:@"FBExpirationDateKey"];
        NSLog(@"Acces2>>>>>%@",facebook.accessToken);
    }
    if (![facebook isSessionValid])
    {
        NSLog(@"Acces3>>>>>%@",[defaults objectForKey:@"FBAccessTokenKey"]);
        NSArray *permissions = [[NSArray alloc]initWithObjects:@"publish_stream", nil];
        [facebook authorize:permissions];
        [permissions release];
        NSLog(@"checked");
        
        
    }else
    {
        //[self apiFQLIMe];
        currentAPICall=kAPIGraphUserFriends;
        [self postToWall];
    }
}

// Pre iOS 4.2 support
- (BOOL)application:(UIApplication *)application handleOpenURL:(NSURL *)url {
    return [facebook handleOpenURL:url];
}

// For iOS 4.2+ support
- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url
  sourceApplication:(NSString *)sourceApplication annotation:(id)annotation {
    return [facebook handleOpenURL:url];
}
-(void)fbDidNotLogin:(BOOL)cancelled
{
    /* if (cancelled) {
     UIAlertView *alertView=[[UIAlertView alloc]initWithTitle:@"Could not Login" message:@"Facebook Cannot login for your application." delegate:self cancelButtonTitle:@"OK" otherButtonTitles: nil];
     [alertView show];
     }*/
}
- (void)fbDidExtendToken:(NSString*)accessToken expiresAt:(NSDate*)expiresAt
{
    NSLog(@"token extended");
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    [defaults setObject:accessToken forKey:@"FBAccessTokenKey"];
    [defaults setObject:expiresAt forKey:@"FBExpirationDateKey"];
    [defaults synchronize];
}
- (void)fbSessionInvalidated
{}
- (void)fbDidLogin
{
    if ([facebook isSessionValid])
    {
        [self postToWall];
    }
}
-(void)fbDidLogout
{}

#pragma mark - FBRequestDelegate Methods
- (void)request:(FBRequest *)request didReceiveResponse:(NSURLResponse *)response
{
    NSLog(@"received response");
    //[self.navigationController popViewControllerAnimated:YES];
}


- (void)request:(FBRequest *)request didLoad:(id)result
{
    if ([result isKindOfClass:[NSArray class]] && ([result count] > 0)) {
        result = [result objectAtIndex:0];
    }
    switch (currentAPICall)
    {
        case kAPIGraphUserFriends:
        {
            NSArray *resultData = [result objectForKey:@"data"];
            friendsArr=[[NSMutableArray alloc]init];
            NSLog(@"result data cvount>>>%@",resultData);
            if ([resultData count] > 0)
            {
                for (int i=0; i<[resultData count]; i++) {
                    [friendsArr addObject:[resultData objectAtIndex:i]];
                }
                
                friends_tblvw.hidden=NO;
                [friends_tblvw reloadData];
                
            } else {
                [self showMessage:@"You have no friends."];
            }
            // [friends release];
            break;
        }
            
        case kAPIGraphUserPhotosPost:
        {
            [self showMessage:@"Photo uploaded successfully."];
            break;
        }
        case kAPIGraphUserVideosPost:
        {
            [self showMessage:@"Video uploaded successfully."];
            break;
        }
        default:
            break;
    }
}

/**
 * Called when an error prevents the Facebook API request from completing
 * successfully.
 */
- (void)request:(FBRequest *)request didFailWithError:(NSError *)error
{
    //  [self apiGraphUserPhotosPost];
    // [self facebookShareButtonPressed:nil];
    NSLog(@"Error message: %@", [error description]);
    [self showMessage:@"Oops, something went haywire."];
}

#pragma mark - FBDialogDelegate Methods
/**
 * Called when a UIServer Dialog successfully return. Using this callback
 * instead of dialogDidComplete: to properly handle successful shares/sends
 * that return ID data back.
 */
- (void)dialogCompleteWithUrl:(NSURL *)url
{
    if (![url query])
    {
        NSLog(@"User canceled dialog or there was an error");
        return;
    }
    
    NSDictionary *params = [self parseURLParams:[url query]];
    switch (currentAPICall) {
        case kDialogFeedUser:
        case kDialogFeedFriend:
        {
            // Successful posts return a post_id
            if ([params valueForKey:@"post_id"]) {
                [self showMessage:@"Published feed successfully."];
                NSLog(@"Feed post ID: %@", [params valueForKey:@"post_id"]);
            }
            break;
        }
        case kDialogRequestsSendToMany:
        case kDialogRequestsSendToSelect:
        case kDialogRequestsSendToTarget:
        {
            // Successful requests return one or more request_ids.
            // Get any request IDs, will be in the URL in the form
            // request_ids[0]=1001316103543&request_ids[1]=10100303657380180
            NSMutableArray *requestIDs = [[[NSMutableArray alloc] init] autorelease];
            for (NSString *paramKey in params)
            {
                if ([paramKey hasPrefix:@"request_ids"])
                {
                    [requestIDs addObject:[params objectForKey:paramKey]];
                }
            }
            if ([requestIDs count] > 0) {
                [self showMessage:@"Sent request successfully."];
                NSLog(@"Request ID(s): %@", requestIDs);
            }
            break;
        }
        default:
            break;
    }
}
- (void)dialogDidNotComplete:(FBDialog *)dialog
{
    NSLog(@"Dialog dismissed.");
}
- (void)dialog:(FBDialog*)dialog didFailWithError:(NSError *)error
{
    // [self apiGraphUserPhotosPost];
    // NSLog(@"Error message: %@", [[error userInfo] objectForKey:@"error_msg"]);
    NSLog(@"Hello");
    [self showMessage:@"Oops, something went haywire."];
}

/**
 * Called when the user granted additional permissions.
 */
- (void)userDidGrantPermission {
    // After permissions granted follow up with next API call
    switch (currentAPICall) {
        case kDialogPermissionsCheckinForRecent:
        {
            // After the check-in permissions have been
            // granted, save them in app session then
            // retrieve recent check-ins
            //            [self updateCheckinPermissions];
            //            [self apiGraphUserCheckins];
            break;
        }
        case kDialogPermissionsCheckinForPlaces:
        {
            // After the check-in permissions have been
            // granted, save them in app session then
            // get nearby locations
            //            [self updateCheckinPermissions];
            //            [self getNearby];
            break;
        }
        case kDialogPermissionsExtended:
        {
            // In the sample test for getting user_likes
            // permssions, echo that success.
            [self showMessage:@"Permissions granted."];
            break;
        }
        default:
            break;
    }
}


- (void)userDidNotGrantPermission
{
    [self showMessage:@"Extended permissions not granted."];
}
- (NSDictionary *)parseURLParams:(NSString *)query
{
	NSArray *pairs = [query componentsSeparatedByString:@"&"];
	NSMutableDictionary *params = [[[NSMutableDictionary alloc] init] autorelease];
	for (NSString *pair in pairs) {
		NSArray *kv = [pair componentsSeparatedByString:@"="];
		NSString *val =
        [[kv objectAtIndex:1]
         stringByReplacingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
        
		[params setObject:val forKey:[kv objectAtIndex:0]];
	}
    return params;
}
- (void)showMessage:(NSString *)message
{
    
}
-(void)fbDialogLogin:(NSString *)token expirationDate:(NSDate *)expirationDate
{
    
}
-(void)fbDialogNotLogin:(BOOL)cancelled
{
    
}





-(IBAction)btnLeftMenuClick:(id)sender
{
    LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
    [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
    [obj release];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
@end
