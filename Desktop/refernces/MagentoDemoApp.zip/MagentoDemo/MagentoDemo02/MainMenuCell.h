//
//  MainMenuCell.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 12/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MainMenuCell : UITableViewCell
{
    UILabel *lblTitle;
}
@property (nonatomic,retain) IBOutlet UILabel *lblTitle;
@end
