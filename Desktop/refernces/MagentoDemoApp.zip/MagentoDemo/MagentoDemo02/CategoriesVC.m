//
//  CategoriesVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 07/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "CategoriesVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"
#import "ObjectClass.h"
#import "AppDelegate.h"
#import "SubCategoryVC.h"
#import "MyCartVC.h"
#import "LoginVC.h"
#import "SubCatClass.h"

@interface CategoriesVC ()

@end

@implementation CategoriesVC
@synthesize btnLeftMenu,btnCart,tblCategories,btnLoginLink,lblHeading;
AppDelegate *app;


- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    if (!(app.UserFname.length==0))
        [btnLoginLink setTitle:app.UserFname forState:UIControlStateNormal];
}
- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:YES];
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    app.MainCategoryObjArr = [[NSMutableArray alloc]init];
    WebApiController *obj=[[WebApiController alloc]init];
    
    [obj callAPI_GET:@"webservice.php" andParams:nil SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
}
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    
    NSLog(@"Json dictionary :: %@",jsonDictionary);
    NSLog(@"count :: %d",[[[[jsonDictionary valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"] count]);
    for (int i=0; i<[[[[jsonDictionary valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"] count]; i++)
    {
        ObjectClass *obj = [[ObjectClass alloc]init];
      
        [obj setMainCategoryID:[[[[[jsonDictionary valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"] objectAtIndex:i] valueForKey:@"category_id"]];
        
        [obj setMainCategoryTitle:[[[[[jsonDictionary valueForKey:@"children"] objectAtIndex:0] valueForKey:@"children"] objectAtIndex:i] valueForKey:@"name"]];
//        SubCatClass *objSubCat = [[SubCatClass alloc]init];
//        [objSubCat setStrSubCategoryId:[[[[jsonDictionary valueForKey:@"children"] objectForKey:0] valueForKey:@"children"] ]]
      
        [app.MainCategoryObjArr addObject:obj];
    }
    [tblCategories reloadData];
    [SVProgressHUD dismiss];
}
-(IBAction)btnCartClick:(id)sender
{
    MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:obj animated:YES];
    [obj release];
}
-(IBAction)btnLoginLinkClick:(id)sender
{
    if (app.UserFname.length==0)
    {
        LoginVC *objVC = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
    }
}


#pragma
#pragma mark - TableView Methods...
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 50;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [app.MainCategoryObjArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"Cell";
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleSubtitle reuseIdentifier:CellIdentifier];
    }
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.MainCategoryObjArr objectAtIndex:[indexPath row]];
    cell.textLabel.text=obj.MainCategoryTitle;
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.MainCategoryObjArr objectAtIndex:[indexPath row]];
    SubCategoryVC *objVC = [[SubCategoryVC alloc] initWithNibName:@"SubCategoryVC" bundle:[NSBundle mainBundle]];
    objVC.MainCategoryID=obj.MainCategoryID;
    objVC.HeadingName=obj.MainCategoryTitle;
    [self.navigationController pushViewController:objVC animated:YES];
    [obj release];
}


-(IBAction)btnLeftMenuClick:(id)sender
{
    LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
    [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
    [obj release];
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
