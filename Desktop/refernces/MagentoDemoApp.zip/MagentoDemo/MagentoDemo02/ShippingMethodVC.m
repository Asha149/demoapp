//
//  ShippingMethodVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "ShippingMethodVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "MyCartVC.h"
#import "PaymentInfoVC.h"
#import "RadioButtonCell.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"
#import "ObjectClass.h"
#import "AppDelegate.h"

@interface ShippingMethodVC ()

@end

@implementation ShippingMethodVC
@synthesize btnLeftMenu,btnCart,btnBack,btnContinue,checked,tblShippingMethods;
AppDelegate *app;
NSString *str;
int ns;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    ns=1000;
    app = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    app.ShippingMethodArr = [[NSMutableArray alloc]init];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *cartId = [defaults objectForKey:@"cartId"];
    
    WebApiController *obj=[[WebApiController alloc]init];
     NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
    
    [param setValue:cartId forKey:@"cart_id"];
    
    [obj callAPI_GET:@"ShippingMethod.php" andParams:param SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
    
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
    
    ObjectClass *objClass = [[ObjectClass alloc]init];
    objClass=[app.COArr objectAtIndex:0];
    NSLog(@"BillingInfo.......");
    NSLog(@"objClass.coAs = %@",objClass.coAs);
    NSLog(@"objClass.coFirstName = %@",objClass.coFirstName);
    NSLog(@"objClass.coLastName = %@",objClass.coLastName);
    NSLog(@"objClass.coCompany = %@",objClass.coCompany);
    NSLog(@"objClass.coEmailAddress = %@",objClass.coEmailAddress);
    NSLog(@"objClass.coAddress = %@",objClass.coAddress);
    NSLog(@"objClass.coCity = %@",objClass.coCity);
    NSLog(@"objClass.coState = %@",objClass.coState);
    NSLog(@"objClass.coZipCode = %@",objClass.coZipCode);
    NSLog(@"objClass.coCountry = %@",objClass.coCountry);
    NSLog(@"objClass.coTelephone = %@",objClass.coTelephone);
    NSLog(@"objClass.coFax = %@",objClass.coFax);
    NSLog(@"objClass.coShipTo = %@",objClass.coShipTo);
    NSLog(@"ShippingInfo.......");
    NSLog(@"objClass.coShipFirstName = %@",objClass.coShipFirstName);
    NSLog(@"objClass.coShipLastName = %@",objClass.coShipLastName);
    NSLog(@"objClass.coShipCompany = %@",objClass.coShipCompany);
    NSLog(@"objClass.coShipAddress = %@",objClass.coShipAddress);
    NSLog(@"objClass.coShipCity = %@",objClass.coShipCity);
    NSLog(@"objClass.coShipState = %@",objClass.coShipState);
    NSLog(@"objClass.coShipZipCode = %@",objClass.coShipZipCode);
    NSLog(@"objClass.coShipCountry = %@",objClass.coShipCountry);
    NSLog(@"objClass.coShipTelephone = %@",objClass.coShipTelephone);
    NSLog(@"objClass.coShipFax = %@",objClass.coShipFax);
}
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
     NSLog(@"Json dictionary :: %@",jsonDictionary);
    
    for (int i=0; i<[jsonDictionary count]; i++)
    {
        NSLog(@"price : %@", [[jsonDictionary objectAtIndex:i]valueForKey:@"price"]);
        ObjectClass *obj = [[ObjectClass alloc]init];
        [obj setShippingIsActive:[[jsonDictionary objectAtIndex:i]valueForKey:@"code"]];
        [obj setShippingMethodName:[[jsonDictionary objectAtIndex:i]valueForKey:@"carrier_title"]];
        [obj setStrShippingPrice:[[jsonDictionary objectAtIndex:i]valueForKey:@"price"]];
        
            [app.ShippingMethodArr addObject:obj];
    }
    [SVProgressHUD dismiss];
    [tblShippingMethods reloadData];
}

-(IBAction)btnLeftMenuClick:(id)sender
{
    str=@"menu";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnCartClick:(id)sender
{
    str=@"cart";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"YES"])
    {
        if ([str isEqualToString:@"menu"])
        {
            LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
            [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
            [obj release];
        }
        else if ([str isEqualToString:@"cart"])
        {
            MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:obj animated:YES];
            [obj release];
        }
        
    }
    else if([title isEqualToString:@"NO"])
    {
        NSLog(@"Button 2 was selected.");
    }
}
-(IBAction)btnContinueClick:(id)sender
{
    if (ns==1000)
    {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Warning"
                              message:@"Please select any Method for Shipping then proceed."
                              delegate:self
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil,
                              nil];
        [alert setDelegate:self];
        [alert show];
    }
    else
    {
        ObjectClass *obj1 = [[ObjectClass alloc]init];
        obj1=[app.COArr objectAtIndex:0];
        ObjectClass *obj2 = [[ObjectClass alloc]init];
        obj2=[app.ShippingMethodArr objectAtIndex:ns];        
        obj1.coShippingMethod=obj2.ShippingMethodName;
        [app.COArr addObject:obj1];
        
        PaymentInfoVC *objVC = [[PaymentInfoVC alloc] initWithNibName:@"PaymentInfoVC" bundle:[NSBundle mainBundle]];
        
        ObjectClass *obj = [[ObjectClass alloc]init];
        obj=[app.ShippingMethodArr objectAtIndex:ns];
       // app.SelectedShippingMethod=obj.ShippingMethodName;
        NSLog(@"shipping :: %@",obj.ShippingIsActive);
        app.SelectedShippingMethod = obj.ShippingIsActive;
        
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
    }
}


#pragma
#pragma mark - TableView Methods...
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [app.ShippingMethodArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"RadioButtonCell";
    RadioButtonCell *cell = (RadioButtonCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"RadioButtonCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    if ([indexPath row]==ns)
        [cell.btnRadio setBackgroundImage:[UIImage imageNamed:@"RadioChecked.png"] forState:UIControlStateNormal];
    else
        [cell.btnRadio setBackgroundImage:[UIImage imageNamed:@"RadioUnchecked.png"] forState:UIControlStateNormal];
    
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.ShippingMethodArr objectAtIndex:[indexPath row]];
    cell.lblMethod.text=obj.ShippingMethodName;
    
    [cell.btnRadio setTag:[indexPath row]];
    [cell.btnRadio addTarget:self action:@selector(btnRadioClick:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    ns=[indexPath row];
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.ShippingMethodArr objectAtIndex:[indexPath row]];
    app.strSelectedShippingMethod = obj.ShippingIsActive;
    NSLog(@"shipping method :: %@",app.strSelectedPaymentMethod);
    [tblShippingMethods reloadData];
}
-(void)btnRadioClick: (id) sender
{
    NSLog(@"Radio Button Tapped = %d",[sender tag]);
    ns=[sender tag];
    [tblShippingMethods reloadData];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
