//
//  PaymentInfoVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "PaymentInfoVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "MyCartVC.h"
#import "OrderReviewVC.h"
#import "RadioButtonCell.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"
#import "ObjectClass.h"
#import "AppDelegate.h"

@interface PaymentInfoVC ()

@end

@implementation PaymentInfoVC
@synthesize btnLeftMenu,btnCart,btnBack,btnContinue,tblPaymentMethods;
@synthesize Scroll;
@synthesize pkCardType,pkMonth,pkYear;
@synthesize txtCardNumber;
@synthesize arrCCType;
@synthesize arrMonth,arrYear;
@synthesize lblCardType;
@synthesize lblMonth,lblYear;
@synthesize txtCCId;
@synthesize arrCType;
@synthesize arrDigitMonth;

AppDelegate *app;
NSString *str;
int np;
int introw,intmonthrow;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    np=1000;
    app = (AppDelegate*)[[UIApplication sharedApplication] delegate];
    app.PaymentMethodArr = [[NSMutableArray alloc]init];
    WebApiController *obj=[[WebApiController alloc]init];
    
    NSUserDefaults *defaults = [NSUserDefaults standardUserDefaults];
    NSString *cartId = [defaults objectForKey:@"cartId"];
    
    NSMutableDictionary *param = [[NSMutableDictionary alloc]init];
    [param setValue:cartId forKey:@"cart_id"];
    
    [obj callAPI_GET:@"PaymentMethodList.php" andParams:param SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
   
   [Scroll setContentSize:CGSizeMake(Scroll.frame.size.width,500)];
    
    arrCCType = [[NSMutableArray alloc]init];
    [arrCCType addObject:@"American Express"];
    [arrCCType addObject:@"Visa"];
    [arrCCType addObject:@"Master Card"];
    [arrCCType addObject:@"Discover"];
    
    arrCType = [[NSMutableArray alloc]init];
    [arrCType addObject:@"AE"];
    [arrCType addObject:@"VI"];
    [arrCType addObject:@"MC"];
    [arrCType addObject:@"DI"];
    
    arrMonth = [[NSMutableArray alloc]init];
    [arrMonth addObject:@"January"];
    [arrMonth addObject:@"Fabruary"];
    [arrMonth addObject:@"March"];
    [arrMonth addObject:@"April"];
    [arrMonth addObject:@"May"];
    [arrMonth addObject:@"June"];
    [arrMonth addObject:@"July"];
    [arrMonth addObject:@"August"];
    [arrMonth addObject:@"September"];
    [arrMonth addObject:@"October"];
    [arrMonth addObject:@"November"];
    [arrMonth addObject:@"December"];
    
    arrDigitMonth = [[NSMutableArray alloc]init];
    [arrDigitMonth addObject:@"1"];
        [arrDigitMonth addObject:@"2"];
        [arrDigitMonth addObject:@"3"];
        [arrDigitMonth addObject:@"4"];
        [arrDigitMonth addObject:@"5"];
        [arrDigitMonth addObject:@"6"];
        [arrDigitMonth addObject:@"7"];
        [arrDigitMonth addObject:@"8"];
        [arrDigitMonth addObject:@"9"];
        [arrDigitMonth addObject:@"10"];
        [arrDigitMonth addObject:@"11"];
        [arrDigitMonth addObject:@"12"];
    
    
    
    arrYear = [[NSMutableArray alloc]init];
    [arrYear addObject:@"2014"];
    [arrYear addObject:@"2015"];
    [arrYear addObject:@"2016"];
    [arrYear addObject:@"2017"];
    [arrYear addObject:@"2018"];
    [arrYear addObject:@"2019"];
    [arrYear addObject:@"2020"];
    [arrYear addObject:@"2021"];
    
    [Scroll setHidden:YES];
    
    
    [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
}

#pragma mark - PickerView Methods...
- (NSInteger)numberOfComponentsInPickerView:(UIPickerView *)pickerView
{
    return 1;
}
- (NSInteger)pickerView:(UIPickerView *)pickerView numberOfRowsInComponent:(NSInteger)component
{
    if (pickerView == pkCardType)
    {
        return [arrCCType count];
    }
    else if (pickerView == pkMonth)
    {
        return [arrMonth count];
    }
    else if (pickerView == pkYear)
    {
        return [arrYear count];
    }
    else
    {
        return 0;
    }
}
- (NSString *)pickerView:(UIPickerView *)pickerView titleForRow:(NSInteger)row forComponent:(NSInteger)component
{
    if (pickerView == pkCardType)
    {
        return [arrCCType objectAtIndex:row];
    }
    else if (pickerView == pkMonth)
    {
        return [arrMonth objectAtIndex:row];
    }
    else if (pickerView == pkYear)
    {
        return [arrYear objectAtIndex:row];
    }
    else
    {
        return 0;
    }
}
- (void)pickerView:(UIPickerView *)pickerView didSelectRow: (NSInteger)row inComponent:(NSInteger)component
{
    if (pickerView == pkCardType)
    {
        //txtCerviaclFluid.text = [CervicalFluidArr objectAtIndex:row];
        lblCardType.text = [arrCCType objectAtIndex:row];
        introw = row;
    }
    else if (pickerView == pkMonth)
    {
        lblMonth.text = [arrMonth objectAtIndex:row];
        intmonthrow = row;
    }
    else if (pickerView == pkYear)
    {
        lblYear.text = [arrYear objectAtIndex:row];
    }
       else
    {
        
    }
}
-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    
    [textField resignFirstResponder];
    return YES;
}

#pragma mark call api
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    
    for (int i=0; i<[jsonDictionary count]; i++)
    {
        ObjectClass *obj = [[ObjectClass alloc]init];
        [obj setPaymentIsActive:[[jsonDictionary objectAtIndex:i]valueForKey:@"code"]];
        [obj setPaymentMethodName:[[jsonDictionary objectAtIndex:i]valueForKey:@"title"]];
        
        
            [app.PaymentMethodArr addObject:obj];
    }
    [SVProgressHUD dismiss];
    [tblPaymentMethods reloadData];
}
#pragma mark button click event
-(IBAction)btnLeftMenuClick:(id)sender
{
    str=@"menu";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnCartClick:(id)sender
{
    str=@"cart";
    UIAlertView *alert = [[UIAlertView alloc]
                          initWithTitle:@""
                          message:@"Are you sure you want to Leave this Page."
                          delegate:self
                          cancelButtonTitle:@"YES"
                          otherButtonTitles:@"NO",
                          nil];
    [alert setDelegate:self];
    [alert show];
    
}
-(IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    NSString *title = [alertView buttonTitleAtIndex:buttonIndex];
    if([title isEqualToString:@"YES"])
    {
        if ([str isEqualToString:@"menu"])
        {
            LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
            [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
            [obj release];
        }
        else if ([str isEqualToString:@"cart"])
        {
            MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
            [self.navigationController pushViewController:obj animated:YES];
            [obj release];
        }
        
    }
    else if([title isEqualToString:@"NO"])
    {
        NSLog(@"Button 2 was selected.");
    }
}
-(IBAction)btnContinueClick:(id)sender
{
    if (np==1000)
    {
        UIAlertView *alert = [[UIAlertView alloc]
                              initWithTitle:@"Warning"
                              message:@"Please select any Method for Payment then proceed."
                              delegate:self
                              cancelButtonTitle:@"OK"
                              otherButtonTitles:nil,
                              nil];
        [alert setDelegate:self];
        [alert show];
    }
    else
    {
        ObjectClass *obj1 = [[ObjectClass alloc]init];
        obj1=[app.COArr objectAtIndex:0];
        ObjectClass *obj2 = [[ObjectClass alloc]init];
        obj2=[app.PaymentMethodArr objectAtIndex:np];        
        obj1.coPaymentMethod=obj2.PaymentMethodName;
        NSString *str = [arrCType objectAtIndex:introw];
        NSLog(@"string :: %@",str);
        obj1.strCardType = str;
        
        obj1.strCCNumber = txtCardNumber.text;
        NSString *month = [arrDigitMonth objectAtIndex:intmonthrow];
        
        obj1.strCCMonth = month;
        obj1.strCCYear = lblYear.text;
        obj1.strCCCid = txtCCId.text;
        
        [app.COArr addObject:obj1];
        
        OrderReviewVC *objVC = [[OrderReviewVC alloc] initWithNibName:@"OrderReviewVC" bundle:[NSBundle mainBundle]];
        ObjectClass *obj = [[ObjectClass alloc]init];
        obj=[app.PaymentMethodArr objectAtIndex:np];
       // app.SelectedPaymentMethod=obj.PaymentMethodName;
        app.SelectedPaymentMethod = obj.PaymentIsActive;
        NSLog(@"payament method :: %@",app.SelectedPaymentMethod);
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
    }    

}


#pragma
#pragma mark - TableView Methods...
-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return 60;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    return [app.PaymentMethodArr count];
}
-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *simpleTableIdentifier = @"RadioButtonCell";
    RadioButtonCell *cell = (RadioButtonCell *)[tableView dequeueReusableCellWithIdentifier:simpleTableIdentifier];
    if (cell == nil)
    {
        NSArray *nib = [[NSBundle mainBundle] loadNibNamed:@"RadioButtonCell" owner:self options:nil];
        cell = [nib objectAtIndex:0];
    }
    if ([indexPath row]==np)
        [cell.btnRadio setBackgroundImage:[UIImage imageNamed:@"RadioChecked.png"] forState:UIControlStateNormal];
    else
        [cell.btnRadio setBackgroundImage:[UIImage imageNamed:@"RadioUnchecked.png"] forState:UIControlStateNormal];
    
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.PaymentMethodArr objectAtIndex:[indexPath row]];
    cell.lblMethod.text=obj.PaymentMethodName;
    [cell.btnRadio setTag:[indexPath row]];
    [cell.btnRadio addTarget:self action:@selector(btnRadioClick:) forControlEvents:UIControlEventTouchUpInside];
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    np=[indexPath row];
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.PaymentMethodArr objectAtIndex:[indexPath row]];
    app.strSelectedPaymentMethod = obj.PaymentIsActive;
    NSLog(@"payment method :: %@",app.strSelectedPaymentMethod);
    [tblPaymentMethods reloadData];
    
    if([app.strSelectedPaymentMethod isEqualToString:@"authorizenet" ] || [app.strSelectedPaymentMethod isEqualToString:@"ccsave"])
    {
        [Scroll setHidden:NO];
    }
    else
    {
        [Scroll setHidden:YES];
    }
    
}
-(void)btnRadioClick: (id) sender
{
    NSLog(@"Radio Button Tapped = %d",[sender tag]);
    np=[sender tag];
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[app.PaymentMethodArr objectAtIndex:np];
    app.strSelectedPaymentMethod = obj.PaymentIsActive;
    NSLog(@"payment method :: %@",app.strSelectedPaymentMethod);
    [tblPaymentMethods reloadData];
    
    if([app.strSelectedPaymentMethod isEqualToString:@"authorizenet" ] || [app.strSelectedPaymentMethod isEqualToString:@"ccsave"])
    {
        [Scroll setHidden:NO];
    }
    else
    {
        [Scroll setHidden:YES];
    }
    [tblPaymentMethods reloadData];
}


- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
