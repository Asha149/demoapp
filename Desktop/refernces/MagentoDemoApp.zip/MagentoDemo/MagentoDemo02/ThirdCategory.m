//
//  ThirdCategory.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 25/12/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "ThirdCategory.h"

@implementation ThirdCategory
    
    @synthesize strThirdCategory,strThirdCategoryId,strParentId;
@synthesize proImages;
@end
