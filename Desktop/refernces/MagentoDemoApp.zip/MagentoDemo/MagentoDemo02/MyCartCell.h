//
//  MyCartCell.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 20/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface MyCartCell : UITableViewCell
{
    UILabel *lblProductName,*lblProductPrice,*lblProductQty;
    UIButton *btnRemove;
    UIImageView *imgProductImage;
}
@property (nonatomic,retain) IBOutlet UILabel *lblProductName,*lblProductPrice,*lblProductQty;
@property (nonatomic,retain) IBOutlet UIButton *btnRemove;
@property (nonatomic,retain) IBOutlet UIImageView *imgProductImage;

@end
