//
//  LoginVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 07/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "LoginVC.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"
#import "ObjectClass.h"
#import "AppDelegate.h"
#import "MyCartVC.h"
#import "RegistrationVC.h"
#import "ViewController.h"

@interface LoginVC ()

@end

@implementation LoginVC
@synthesize btnLeftMenu,btnCart;
@synthesize btnLogin,btnCancel,btnRegister;
@synthesize txtUserName,txtPassword;
AppDelegate *app;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    app.ProductsObjArr = [[NSMutableArray alloc]init];
}

-(IBAction)btnLoginClick:(id)sender
{
    UIAlertView *CheckAlert = [[UIAlertView alloc]initWithTitle:@"Some Fields are Empty"
                                                        message:@"..."
                                                       delegate:self
                                              cancelButtonTitle:@"OK"
                                              otherButtonTitles:nil, nil];
    [CheckAlert setDelegate:self];
    [CheckAlert setTitle:@"Warning"];
    NSLog(@"btnLoginClick");
    NSString *textUserName= [txtUserName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    NSString *textPassword= [txtPassword.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
    if (textUserName.length==0 || textPassword.length==0)
    {
        if (textUserName.length==0)
        {
            [CheckAlert setMessage:@"Please Enter UserName"];
        }
        else if (textPassword.length==0)
        {
            [CheckAlert setMessage:@"Please Enter Password"];
        }
        else
        {
            [CheckAlert setMessage:@"Some Fields are Blank"];
        }
        [CheckAlert show];
    }
    else
    {
        NSLog(@"Login Successfully...");
        NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
        [param setValue:textUserName forKey:@"email"];
       // [param setValue:textPassword forKey:@"password"];
        WebApiController *obj=[[WebApiController alloc]init];
        [obj callAPI_GET:@"LoginUser.php" andParams:param SuccessCallback:@selector(service_reponse:Response:) andDelegate:self];
        [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
    }
}
-(void)service_reponse:(NSString *)apiAlias Response:(NSData *)response
{
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    NSLog(@"Json dictionary :: %@",jsonDictionary);
    NSString *EntityID = [jsonDictionary valueForKey:@"customer_id"];
    if (EntityID == nil)
    {
        UIAlertView *CheckAlert = [[UIAlertView alloc]initWithTitle:@"Warning"
                                                            message:@"Email id or Password mismatch"
                                                           delegate:self
                                                  cancelButtonTitle:@"OK"
                                                  otherButtonTitles:nil, nil];
        [CheckAlert show];
        txtPassword.text = @"";
    }
    else
    {
         app.UserFname=[jsonDictionary valueForKey:@"firstname"];
        app.strCustomer_id = [jsonDictionary valueForKey:@"customer_id"];
        NSLog(@"user name :: %@",app.UserFname);
        NSLog(@"Customer_id :: %@",app.strCustomer_id);
        ViewController *objVC = [[ViewController alloc] initWithNibName:@"ViewController" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
//        NSMutableDictionary *param=[[NSMutableDictionary alloc]init];
//        [param setValue:EntityID forKey:@"eid"];
//        WebApiController *obj=[[WebApiController alloc]init];
//        [obj callAPI_GET:@"getFname.php" andParams:param SuccessCallback:@selector(service_reponse2:Response:) andDelegate:self];
        [SVProgressHUD showWithMaskType:SVProgressHUDMaskTypeBlack];
    }
    [SVProgressHUD dismiss];
}
-(void)service_reponse2:(NSString *)apiAlias Response:(NSData *)response
{
    NSMutableArray *jsonDictionary=[NSJSONSerialization JSONObjectWithData:response options:NSJSONReadingMutableContainers error:nil];
    app.UserFname=[[jsonDictionary objectAtIndex:0]valueForKey:@"firstname"];
    app.strCustomer_id = [[jsonDictionary objectAtIndex:0]valueForKey:@"customer_id"];
    NSLog(@"user name :: %@",app.UserFname);
    NSLog(@"Customer_id :: %@",app.strCustomer_id);
//    NSString *textUserName= [txtUserName.text stringByTrimmingCharactersInSet:[NSCharacterSet whitespaceAndNewlineCharacterSet]];
//    app.Email_ID=textUserName;
    
    ViewController *objVC = [[ViewController alloc] initWithNibName:@"ViewController" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:objVC animated:YES];
    [objVC release];
    
    [SVProgressHUD dismiss];
}
-(IBAction)btnCancelClick:(id)sender
{
    txtUserName.text=@"";
    txtPassword.text=@"";
    [txtUserName resignFirstResponder];
    [txtPassword resignFirstResponder];
}
-(IBAction)btnRegisterClick:(id)sender
{
    RegistrationVC *objVC = [[RegistrationVC alloc] initWithNibName:@"RegistrationVC" bundle:[NSBundle mainBundle]];
    objVC.From = @"login";
    [self.navigationController pushViewController:objVC animated:YES];
    [objVC release];
}
-(IBAction)btnLeftMenuClick:(id)sender
{
    LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
    [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
    [obj release];
}
-(IBAction)btnCartClick:(id)sender
{
    MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:obj animated:YES];
    [obj release];
}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
    [textField resignFirstResponder];
    return YES;
}
- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

@end
