//
//  MyCartCell.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 20/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "MyCartCell.h"

@implementation MyCartCell
@synthesize lblProductName,lblProductPrice,lblProductQty;
@synthesize btnRemove,imgProductImage;

- (id)initWithStyle:(UITableViewCellStyle)style reuseIdentifier:(NSString *)reuseIdentifier
{
    self = [super initWithStyle:style reuseIdentifier:reuseIdentifier];
    if (self) {
        // Initialization code
    }
    return self;
}

- (void)setSelected:(BOOL)selected animated:(BOOL)animated
{
    [super setSelected:selected animated:animated];

    // Configure the view for the selected state
}

@end
