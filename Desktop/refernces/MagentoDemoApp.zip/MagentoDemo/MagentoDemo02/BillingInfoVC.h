//
//  BillingInfoVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BillingInfoVC : UIViewController <UITextFieldDelegate,UITextViewDelegate>
{
    UIButton *btnLeftMenu,*btnCart,*btnBack,*btnContinue,*btnShipToThis,*btnShipToDiff;
    UITextField *txtFirstName,*txtLastName,*txtCompany,*txtEmailAddress,*txtCity,*txtState,*txtZipCode,*txtCountry,*txtTelephone,*txtFax;
    UITextView *txtAddress;
    UIScrollView *Scroll;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart,*btnBack,*btnContinue,*btnShipToThis,*btnShipToDiff;
@property (nonatomic,retain) IBOutlet UITextField *txtFirstName,*txtLastName,*txtCompany,*txtEmailAddress,*txtCity,*txtState,*txtZipCode,*txtCountry,*txtTelephone,*txtFax;
@property (nonatomic,retain) IBOutlet UITextView *txtAddress;
@property (nonatomic,retain) IBOutlet UIScrollView *Scroll;
@property (nonatomic,retain) NSString *checked;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnBack:(id)sender;
-(IBAction)btnContinueClick:(id)sender;
-(IBAction)btnShipToThisClick:(id)sender;
-(IBAction)btnShipToDiffClick:(id)sender;
@end
