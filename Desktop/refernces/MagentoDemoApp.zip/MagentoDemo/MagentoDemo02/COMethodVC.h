//
//  COMethodVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 15/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface COMethodVC : UIViewController <UITextFieldDelegate>
{
    UIButton *btnLeftMenu,*btnCart,*btnLogin,*btnContinue,*btnAsGuest,*btnRegister;
    UITextField *txtEmailAddress,*txtPassword;
    UIScrollView *Scroll;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart,*btnLogin,*btnContinue,*btnAsGuest,*btnRegister;
@property (nonatomic,retain) IBOutlet UITextField *txtEmailAddress,*txtPassword;
@property (nonatomic,retain) IBOutlet UIScrollView *Scroll;
@property (nonatomic,retain) NSString *checked;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
-(IBAction)btnLoginClick:(id)sender;
-(IBAction)btnContinueClick:(id)sender;
-(IBAction)btnAsGuestClick:(id)sender;
-(IBAction)btnRegisterClick:(id)sender;
@end
