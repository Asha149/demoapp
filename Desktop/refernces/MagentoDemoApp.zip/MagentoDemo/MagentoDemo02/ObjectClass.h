//
//  ObjectClass.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 06/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface ObjectClass : NSObject
{
    NSString *MainCategoryID,*MainCategoryTitle,*SubCategoryID,*SubCategoryTitle,*SubCategoryAttribID,*ProductID,*ProductTitle,*ProductPrice,*ProductDesc,*ProductAttribID,*ProductImagePath,*PID,*ShippingMethodName,*ShippingIsActive,*PaymentMethodName,*PaymentIsActive, *strShippingPrice;
    NSString *coFirstName,*coLastName,*coCompany,*coEmailAddress,*coAddress,*coCity,*coState,*coZipCode,*coCountry,*coTelephone,*coFax,*coShipFirstName,*coShipLastName,*coShipCompany,*coShipEmailAddress,*coShipAddress,*coShipCity,*coShipState,*coShipZipCode,*coShipCountry,*coShipTelephone,*coShipFax,*coAs,*coShipTo,*coUseBilling,*coShippingMethod,*coPaymentMethod,*coOrderId,*coGrandTotal,*strOrderID;
    UIImage *ProductImage;
}
@property(nonatomic,retain) NSString *MainCategoryID,*MainCategoryTitle,*SubCategoryID,*SubCategoryTitle,*SubCategoryAttribID,*ProductID,*ProductTitle,*ProductPrice,*ProductDesc,*ProductAttribID,*ProductImagePath,*PID,*ShippingMethodName,*ShippingIsActive,*PaymentMethodName,*PaymentIsActive;
@property(nonatomic,retain) NSString *coFirstName,*coLastName,*coCompany,*coEmailAddress,*coAddress,*coCity,*coState,*coZipCode,*coCountry,*coTelephone,*coFax,*coShipFirstName,*coShipLastName,*coShipCompany,*coShipEmailAddress,*coShipAddress,*coShipCity,*coShipState,*coShipZipCode,*coShipCountry,*coShipTelephone,*coShipFax,*coAs,*coShipTo,*coUseBilling,*coShippingMethod,*coPaymentMethod,*coOrderId,*coGrandTotal;
@property(nonatomic,retain) UIImage *ProductImage;
@property (nonatomic,retain)NSMutableArray *arrProImages;
    
    @property (nonatomic,retain)NSString *strShippingPrice;
    @property (nonatomic,retain)NSString *strOrderID;

@property (nonatomic,retain)NSString *strCardType;
@property (nonatomic,retain)NSString *strCCNumber;
@property (nonatomic,retain)NSString *strCCMonth;
@property (nonatomic,retain)NSString *strCCYear;
@property (nonatomic,retain)NSString *strCCCid;

-(id)initWithTask:(NSString *)task;
@end
