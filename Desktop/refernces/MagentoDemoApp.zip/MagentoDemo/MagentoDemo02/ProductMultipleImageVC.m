//
//  ProductMultipleImageVC.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 26/12/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "ProductMultipleImageVC.h"
#import "ObjectClass.h"
#import "UIImageView+WebCache.h"
#import "LeftMenuController.h"
#import "MyCartVC.h"
#import "LoginVC.h"

@interface ProductMultipleImageVC ()

@end

@implementation ProductMultipleImageVC
@synthesize imgbig,imgs1,imgs2,imgs3;
@synthesize btnImage1,btnImage2,btnImage3;
@synthesize lblHeading;
@synthesize strHeading;
@synthesize intSelectedIndex;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
    // Do any additional setup after loading the view from its nib.
    appDelegate = (AppDelegate *)[[UIApplication sharedApplication]delegate];
   
     ObjectClass *obj = [[ObjectClass alloc]init];
    NSLog(@"selected index :: %d",intSelectedIndex);
    obj=[appDelegate.ProductsObjArr objectAtIndex:intSelectedIndex];
    
    lblHeading.text = strHeading;
    NSLog(@"image count  :: %d",[obj.arrProImages count]);
    NSLog(@"image path :: %@",[obj.arrProImages objectAtIndex:0]);
    [imgbig setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:0]]];
    
    if([obj.arrProImages count] == 1)
    {
        [imgbig setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:0]]];
        [imgs1 setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:0]]];
        [imgs2 setHidden:YES];
        [imgs3 setHidden: YES];
        [btnImage2 setHidden:YES];
        [btnImage3 setHidden:YES];
    }
    
    if([obj.arrProImages count] == 2)
    {
        [imgs2 setHidden:NO];
        [imgs3 setHidden: YES];
        [btnImage2 setHidden:NO];
        [btnImage3 setHidden:YES];
        [imgbig setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:0]]];
        [imgs1 setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:0]]];
        [imgs2 setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:1]]];

    }
    
    if([obj.arrProImages count] == 3)
    {
        [imgs2 setHidden:NO];
        [imgs3 setHidden: NO];
        [btnImage2 setHidden:NO];
        [btnImage3 setHidden:NO];
        [imgbig setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:0]]];
         [imgs1 setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:0]]];
         [imgs2 setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:1]]];
         [imgs3 setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:2]]];
        
    }
    
    
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark button click event

-(IBAction)btnImage1_click:(id)sender
{
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[appDelegate.ProductsObjArr objectAtIndex:intSelectedIndex];

   [imgbig setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:0]]];
   // imgbig = imgs1;
   
}
-(IBAction)btnImage2_click:(id)sender
{
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[appDelegate.ProductsObjArr objectAtIndex:intSelectedIndex];
    
    [imgbig setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:1]]];
   //     imgbig = imgs2;
  
}
-(IBAction)btnImage3_click:(id)sender
{
    ObjectClass *obj = [[ObjectClass alloc]init];
    obj=[appDelegate.ProductsObjArr objectAtIndex:intSelectedIndex];
    
    [imgbig setImageWithURL:[NSURL URLWithString:[obj.arrProImages objectAtIndex:2]]];
//        imgbig = imgs3;
    
}
-(IBAction)btnCartClick:(id)sender
{
    MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:obj animated:YES];
    [obj release];
}
-(IBAction)btnBack:(id)sender
{
    [self.navigationController popViewControllerAnimated:YES];
}
-(IBAction)btnLeftMenuClick:(id)sender
{
    LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
    [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
    [obj release];
}
-(IBAction)btnLoginLinkClick:(id)sender
{
    if (appDelegate.UserFname.length==0)
    {
        LoginVC *objVC = [[LoginVC alloc] initWithNibName:@"LoginVC" bundle:[NSBundle mainBundle]];
        [self.navigationController pushViewController:objVC animated:YES];
        [objVC release];
    }
}
@end
