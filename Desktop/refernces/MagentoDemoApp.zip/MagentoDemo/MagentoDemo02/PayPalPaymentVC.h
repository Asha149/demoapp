//
//  PayPalPaymentVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 09/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "ZZFlipsideViewController.h"
#import "PayPalMobile.h"

@interface PayPalPaymentVC : UIViewController <PayPalPaymentDelegate, ZZFlipsideViewControllerDelegate, UIPopoverControllerDelegate>

@property(nonatomic, strong, readwrite) UIPopoverController *flipsidePopoverController;

@property(nonatomic, strong, readwrite) NSString *environment;
@property(nonatomic, assign, readwrite) BOOL acceptCreditCards;
@property(nonatomic, strong, readwrite) PayPalPayment *completedPayment;
@end
