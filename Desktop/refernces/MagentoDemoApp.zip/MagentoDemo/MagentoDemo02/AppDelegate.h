//
//  AppDelegate.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 30/10/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "PPRevealSideViewController.h"

@interface AppDelegate : UIResponder <UIApplicationDelegate, PPRevealSideViewControllerDelegate>
{
    NSString *databaseName;
	NSString *databasePath;
}

@property (strong, nonatomic) UIWindow *window;

@property (strong, nonatomic) PPRevealSideViewController *revealSideViewController;

@property (nonatomic,retain) NSMutableArray *MainCategoryObjArr,*SubCategoryObjArr, *ProductsObjArr, *ShippingMethodArr, *PaymentMethodArr, *COArr, *OrderArr,*arrProductImages;
@property (nonatomic,retain) NSString *UserFname,*SelectedShippingMethod,*SelectedPaymentMethod,*Email_ID;
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu;
-(NSString *) getDBPath;
@property (nonatomic,retain)NSMutableArray *arrProducts;
@property (nonatomic,retain)NSString *strCustomer_id;
@property (nonatomic,retain)NSString *strSelectedShippingMethod;
@property (nonatomic,retain)NSString *strSelectedPaymentMethod;
    
@end
