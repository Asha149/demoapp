//
//  MyOrderVC.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 25/11/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>
#import <sqlite3.h>

@interface MyOrderVC : UIViewController <UITableViewDelegate,UITableViewDataSource>
{
    sqlite3 *_database;
    UIButton *btnLeftMenu,*btnCart;
    UITableView *tblOrders;
    UILabel *lblEmptyOrder,*lblGT;
    UIView *HeadingPopUp;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart;
@property (nonatomic,retain) IBOutlet UITableView *tblOrders;
@property (nonatomic,retain) IBOutlet UILabel *lblEmptyOrder,*lblGT;
@property (nonatomic,retain) IBOutlet UIView *HeadingPopUp;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
@end
