//
//  ViewController.m
//  MagentoDemo02
//
//  Created by ajeet Singh on 30/10/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import "ViewController.h"
#import "PPRevealSideViewController.h"
#import "LeftMenuController.h"
#import "WebApiController.h"
#import "SVProgressHUD.h"
#import "ObjectClass.h"
#import "AppDelegate.h"
#import "MyCartVC.h"

@interface ViewController ()

@end

@implementation ViewController
@synthesize btnLeftMenu,btnCart,lblUserName;
AppDelegate *app;

- (void)viewDidLoad
{
    [super viewDidLoad];
    [self.navigationController setNavigationBarHidden:YES];
    app=(AppDelegate *)[[UIApplication sharedApplication]delegate];
    NSLog(@"app.UserFname = %@",app.UserFname);
    if ([app.UserFname isEqual:NULL])
    {
        NSLog(@"ABC");
    }
    else
    {
        [lblUserName setHidden:NO];
        lblUserName.text = app.UserFname;
    }
}

-(IBAction)btnLeftMenuClick:(id)sender
{
    LeftMenuController *obj = [[LeftMenuController alloc] initWithNibName:@"LeftMenuController" bundle:[NSBundle mainBundle]];
    [self.revealSideViewController pushViewController:obj onDirection:PPRevealSideDirectionLeft withOffset:50 animated:YES];
    [obj release];
}
-(IBAction)btnCartClick:(id)sender
{
    MyCartVC *obj = [[MyCartVC alloc] initWithNibName:@"MyCartVC" bundle:[NSBundle mainBundle]];
    [self.navigationController pushViewController:obj animated:YES];
    [obj release];
}

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}
- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    //      how many Days Stipent i get???
    //   1day Stipend = 195 and i got 4day stipend
    //   1Leave 600 16240afterPF
    //   if 18000 then 580
    //   total 27 days count 27*580 = 15660-13393= 2267
    //   if 18 then 16240 so PF = 1760
}

@end
