//
//  ViewController.h
//  MagentoDemo02
//
//  Created by ajeet Singh on 30/10/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ViewController : UIViewController
{
    UIButton *btnLeftMenu,*btnCart;
    UILabel *lblUserName;
}
@property (nonatomic,retain) IBOutlet UIButton *btnLeftMenu,*btnCart;
@property (nonatomic,retain) IBOutlet UILabel *lblUserName;

-(IBAction)btnLeftMenuClick:(id)sender;
-(IBAction)btnCartClick:(id)sender;
@end
