//
//  TipsViewController.h
//  PhraseCrazyApp
//
//  Created by ajeet Singh on 16/09/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface TipsViewController : UIViewController

@property (nonatomic,retain)IBOutlet UITextView *txtTips;

-(IBAction)btnBack:(id)sender;

@end
