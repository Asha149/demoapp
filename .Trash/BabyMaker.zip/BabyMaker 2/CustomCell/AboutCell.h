//
//  AboutCell.h
//  BabyMaker
//
//  Created by Ajeet on 10/17/13.
//  Copyright (c) 2013 ajeet Singh. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutCell : UITableViewCell

@end
