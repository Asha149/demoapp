//
//  ImageViewController.m
//  ImageUpload
//
//  Created by LaNet Team on 16/01/14.
//  Copyright (c) 2014 Gaurav Parvadiya. All rights reserved.
//

#import "ImageViewController.h"
#import "EditImageController.h"
#import <QuartzCore/QuartzCore.h>
#import "AboutUsViewController.h"
#import "LikeViewController.h"

@interface ImageViewController ()

@end

@implementation ImageViewController

@synthesize btnCancel;
@synthesize btnEdit;
@synthesize btnNewUpload;
@synthesize customActionSheetView;
@synthesize btnAddImage;
@synthesize btnEditImage;

NSInteger intImage;

- (id)initWithNibName:(NSString *)nibNameOrNil bundle:(NSBundle *)nibBundleOrNil
{
    self = [super initWithNibName:nibNameOrNil bundle:nibBundleOrNil];
    if (self) {
        // Custom initialization
    }
    return self;
}

- (void)viewDidLoad
{
    [super viewDidLoad];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)addImage:(id)sender {
    
//    UIActionSheet *actionSheet = [[UIActionSheet alloc]initWithTitle:nil delegate:self cancelButtonTitle:@"Cancel" destructiveButtonTitle:nil otherButtonTitles:@"",@"", nil];
//    
//    [[[actionSheet valueForKey:@"_buttons"] objectAtIndex:0] setImage:[UIImage imageNamed:@"camera_button.png"] forState:UIControlStateNormal];
//    [[[actionSheet valueForKey:@"_buttons"] objectAtIndex:1] setImage:[UIImage imageNamed:@"existing_button.png"] forState:UIControlStateNormal];
//    
//    [actionSheet showInView:self.view];
    
    
    [btnAddImage setImage:[UIImage imageNamed:@"upload_button_hover.png"] forState:UIControlStateHighlighted];
    
    CATransition *transDown=[CATransition animation];
    [transDown setDuration:0.5];
    [transDown setType:kCATransitionPush];
    [transDown setSubtype:kCATransitionFromTop];
    [transDown setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    
    [customActionSheetView.layer addAnimation:transDown forKey:nil];
    
    [btnAddImage setEnabled:NO];
    [btnEditImage setEnabled:NO];
    [customActionSheetView setHidden:NO];
}

- (IBAction)editSample:(id)sender {
    
    EditImageController *eic = [[EditImageController alloc]initWithNibName:@"EditImageController" bundle:nil];
    UIImage *image = [UIImage imageNamed:@"image_only.png"];
    eic.originalImage = image;
    [self.navigationController pushViewController:eic animated:YES];
}
- (IBAction)btnLike_click:(id)sender
{
    LikeViewController *vc = [[LikeViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
}
- (IBAction)btnSetting_click:(id)sender
{
    AboutUsViewController *vc = [[AboutUsViewController alloc]init];
    [self.navigationController pushViewController:vc animated:YES];
   
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    switch (buttonIndex) {
        case 0:
            [self takeNewPhotoFromCamera];
            break;
        case 1:
            [self choosePhotoFromExistingImages];
        default:
            break;
    }
}

- (void)takeNewPhotoFromCamera
{
    
}

-(void)choosePhotoFromExistingImages
{
    
}

- (IBAction)choosePhotoFromExistingImages:(id)sender {
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypePhotoLibrary])
    {
        intImage =1;
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        controller.allowsEditing = NO;
        controller.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType: UIImagePickerControllerSourceTypePhotoLibrary];
        controller.delegate = self;
        [self.navigationController presentViewController: controller animated: YES completion: nil];
    }
}


- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
   
//    //obtaining saving path
//    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
//    NSString *documentsDirectory = [paths objectAtIndex:0];
//    NSString *imagePath = [documentsDirectory stringByAppendingPathComponent:@"latest_photo.png"];
//    
//    //extracting image from the picker and saving it
//    NSString *mediaType = [info objectForKey:UIImagePickerControllerMediaType];
//    if ([mediaType isEqualToString:@"public.image"]){
//        UIImage *editedImage = [info objectForKey:UIImagePickerControllerEditedImage];
//        NSData *webData = UIImagePNGRepresentation(editedImage);
//        [webData writeToFile:imagePath atomically:YES];
//    }
      EditImageController *eic = [[EditImageController alloc]initWithNibName:@"EditImageController" bundle:nil];
    UIImage *image;
    if(intImage == 1)
    {
       image =  [info objectForKey:@"UIImagePickerControllerOriginalImage"];
       
    }
    else if (intImage ==2)
    {
        image = [info valueForKey: UIImagePickerControllerEditedImage];
        
    }
    else
    {
    
    }
   
    
     eic.originalImage = image;
    [self.navigationController dismissViewControllerAnimated: YES completion: nil];
    [self.navigationController pushViewController:eic animated:YES];
    
}

- (void)imagePickerControllerDidCancel:(UIImagePickerController *)picker;
{
    [self.navigationController dismissViewControllerAnimated: YES completion: nil];
}

-(void)viewWillAppear:(BOOL)animated{
    [self.navigationController setNavigationBarHidden:YES];
    [customActionSheetView setHidden:YES];
    [btnAddImage setEnabled:YES];
    [btnEditImage setEnabled:YES];
}

- (IBAction)hideActionSheetView:(id)sender {
    CATransition *transDown=[CATransition animation];
    [transDown setDuration:0.5];
    [transDown setType:kCATransitionPush];
    [transDown setSubtype:kCATransitionFromBottom];
    [transDown setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionEaseInEaseOut]];
    
    [customActionSheetView.layer addAnimation:transDown forKey:nil];
    
    [customActionSheetView setHidden:YES];
    [btnAddImage setEnabled:YES];
    [btnEditImage setEnabled:YES];
}

- (IBAction)takeNewPhotoFromCamera:(id)sender {
    
    if ([UIImagePickerController isSourceTypeAvailable: UIImagePickerControllerSourceTypeCamera])
    {
        intImage = 2;
        UIImagePickerController *controller = [[UIImagePickerController alloc] init];
        controller.sourceType = UIImagePickerControllerSourceTypeCamera;
        controller.allowsEditing = YES;
        controller.mediaTypes = [UIImagePickerController availableMediaTypesForSourceType: UIImagePickerControllerSourceTypeCamera];
        controller.delegate = self;
        [self.navigationController presentViewController: controller animated: YES completion: nil];
    }
}
@end
