 //
//  EditImageController.m
//  ImageUpload
//
//  Created by lanetteam on 12/02/14.
//  Copyright (c) 2014 Gaurav Parvadiya. All rights reserved.
//

#import "EditImageController.h"
#import <QuartzCore/QuartzCore.h>
#import "PECropViewController.h"
#import "ZDStickerView.h"
#import "TLTiltSlider.h"



@interface EditImageController () <PECropViewControllerDelegate>

@end

@implementation EditImageController

@synthesize originalImage;
@synthesize imageViewFrame;
@synthesize imageViewDisplay;
@synthesize menuScrollView;
@synthesize frameScrollView;
@synthesize btnGoHome;
@synthesize viewHeader;
@synthesize viewScrollBottom;
@synthesize btnGoEditorMenu;
@synthesize cancelBtnName;
@synthesize applyBtn;
@synthesize applyBtnName;
@synthesize brightnessSlider;
@synthesize saturationSlider;
@synthesize contrastSlider;
@synthesize contrastSliderView;
@synthesize saturationSliderView;
@synthesize brightnessSliderView;
@synthesize filter;
@synthesize cgimg;
@synthesize result;
@synthesize newimg;
@synthesize beginImage;
@synthesize context;
@synthesize filterScrollView;
@synthesize filterTempImage;
@synthesize commonSliderLower;
@synthesize btnFlipHorizontal;
@synthesize btnFlipVertical;
@synthesize btnRotate;
@synthesize flipRotateView;
@synthesize lastSavedImage;
@synthesize stickerScrollView;
@synthesize stickerIconScrollView;
@synthesize stickerOptionView;
@synthesize lblStickerOptionTitle;
@synthesize adjsutMenuTag;
@synthesize lblBrightness;
@synthesize lblContrast;
@synthesize lblSaturation;
@synthesize lblBlur;
@synthesize viewAdjustOptions;
@synthesize tableViewFontName;
@synthesize textManageView;
@synthesize viewTextOptions;
@synthesize textFieldText;
@synthesize tableViewFontStyle;
@synthesize viewTextfield;
@synthesize initialTransformation;
@synthesize lblText;
@synthesize btnCross,btnedit;
@synthesize imgCurrent;
@synthesize sticker_icon_name;

NSInteger inttag;




#pragma mark - Main Methods

- (void)viewDidLoad
{
    [super viewDidLoad];
    imageViewDisplay.image = originalImage;
    lastSavedImage  =[[UIImage alloc]init] ;
    [self setLastSavedImage:imageViewDisplay.image ];
    imgCurrent = [[UIImageView alloc]init];
    imgCurrent.image = imageViewDisplay.image;
    newimg = imageViewDisplay.image;
    [menuScrollView setContentSize:CGSizeMake(320, 530)];
    
    btnGoHome.layer.shouldRasterize = YES;
    btnGoHome.layer.shouldRasterize = YES;
    animation = [CATransition animation];
    animation.type = kCATransitionFade;
    animation.duration = 0.4;
    
    [self setupMenu];
    
    //Slider & Slider View Setup
    [contrastSlider setThumbImage: [UIImage imageNamed:@"white-round-md.png"] forState:UIControlStateNormal];
    context=[CIContext contextWithOptions:nil];
    beginImage = [[CIImage alloc] initWithImage:imageViewDisplay.image];
    newimg= imageViewDisplay.image;
    
    [self setAdjustment];

    textFieldText.layer.borderWidth = 1;
    textFieldText.layer.borderColor = [[UIColor redColor] CGColor];

    [imageViewDisplay addGestureRecognizer:self.pinchImage];
    
    
    imagearry = [[NSMutableArray alloc]initWithObjects:
                                 [UIImage imageNamed: @"frame_1.png"],
                                 [UIImage imageNamed: @"frame_2.png"],
                                 [UIImage imageNamed: @"frame_3.png"],
                                 [UIImage imageNamed: @"frame_4.png"],
                                 [UIImage imageNamed: @"frame_5.png"],
                                 [UIImage imageNamed: @"frame_6.png"],
                                 [UIImage imageNamed: @"frame_7.png"],
                                 [UIImage imageNamed: @"frame_8.png"],
                                 [UIImage imageNamed: @"frame_9.png"],
                                 [UIImage imageNamed: @"frame_10.png"],
                                 [UIImage imageNamed: @"frame_11.png"],
                                 [UIImage imageNamed: @"frame_12.png"],
                                 [UIImage imageNamed: @"frame_13.png"],
                                 [UIImage imageNamed: @"frame_14.png"],
                                 [UIImage imageNamed: @"frame_15.png"]
                                 , nil];
}

- (IBAction)pan:(UIPanGestureRecognizer *)sender
{

    CGPoint translation = [sender translationInView:self.view];
    
    CGRect bbFrame = [[UIScreen mainScreen] bounds];
    CGRect frame = self.viewTextfield.frame;
    frame.origin.x += translation.x;
    frame.origin.y += translation.y;
    
    frame.origin.x = MAX(CGRectGetMinX(bbFrame), MIN(frame.origin.x, CGRectGetMaxX(bbFrame) - frame.size.width));
    frame.origin.y = MAX(CGRectGetMinY(bbFrame), MIN(frame.origin.y, CGRectGetMaxY(bbFrame) - frame.size.height));
    
    self.viewTextfield.frame = frame;
    [sender setTranslation:CGPointMake(0, 0) inView:self.view];
    
}
-(IBAction)btnEdittext_click:(id)sender
{
    //lblText.text = textFieldText.text;
    //[textFieldText setHidden:YES];
    [btnedit setHidden:YES];
    [btnCross setHidden:YES];
    //[self.viewTextfield setHidden:YES];
    //[textFieldText setHidden:NO];
    textFieldText.layer.borderWidth = 1;
    textFieldText.layer.borderColor = [[UIColor clearColor] CGColor];
    

    
}
-(IBAction)btnCrossText_click:(id)sender
{
//    [viewTextfield setHidden:NO];
//    [textFieldText setHidden:NO];
//    [btnCross setHidden:NO];
//    [btnedit setHidden:NO];
    
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@""
                                                      message:@"Do you want to remove?"
                                                     delegate:self
                                            cancelButtonTitle:@"OK"
                                            otherButtonTitles:nil];
    message.tag = 2;
    
  //  message setDelegate:self.
	
    [message show];
}

- (void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if(alertView.tag == 2)
    {
        if(buttonIndex == 0)
        {
//            [self.viewTextfield removeFromSuperview];
            [viewTextfield setHidden:YES];
        }
    }
    if (alertView.tag ==1) {
        if(buttonIndex == 0)
        {
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                
                
                UIImage *imgsave=[self captureView:self.bottomView];
                
                UIImageWriteToSavedPhotosAlbum(imgsave  , nil, nil, nil);
            });
        }
        else
        {
            
        }
    }
}

- (void)tableView:(UITableView *)tableView willDisplayCell:(UITableViewCell *)cell forRowAtIndexPath:(NSIndexPath *)indexPath
{
    //UIView *card = [(CTCardCell* )cell mainView];
    
    viewTextfield.layer.transform = self.initialTransformation;
    viewTextfield.layer.opacity = 0.8;
}
-(void)viewWillAppear:(BOOL)animated{
    
    [self.navigationController setNavigationBarHidden:YES];
}

- (void)didReceiveMemoryWarning
{
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Setup Menu Methods

-(void)setupMenu
{
	menuScrollView.contentSize = CGSizeMake(320,78);
    NSArray *menu_name = [NSArray arrayWithObjects:@"icon_adjust.png",@"icon_filter.png",@"icon_frame.png",@"rotate-3_icon.png",@"crop_icon.png",@"sticker_icon.png",@"text_icon.png", nil];
    NSArray *menu_label = [NSArray arrayWithObjects:@"Adjust",@"Filter",@"Frame",@"Rotate",@"Crop",@"Sticker",@"Text", nil];
    int x=15;
    int y=5;
    int width=40;
    int cntWidth = width;
    for (int i=0; i<[menu_name count]; i++)
    {
        UIButton *btn = [[UIButton alloc]init];
        UILabel *menu = [[UILabel alloc]init];
        [menu setText:menu_label[i]];
        [btn setImage:[UIImage imageNamed:menu_name[i]] forState:UIControlStateNormal];
        [btn setTag:i+1];
        [menu setTag:i+101];
        btn.frame = CGRectMake(x, y, width, 27);
        menu.frame = CGRectMake(x+4,30, width, 27);
        btn.backgroundColor = [UIColor clearColor];
        [menu setBackgroundColor:[UIColor clearColor]];
        if (i==0) {
            [menu setTextColor:[UIColor redColor]];
        }
        else {
            [menu setTextColor:[UIColor whiteColor]];
        }
        //[menu setTextColor:[UIColor whiteColor]];
        [menu setFont:[UIFont systemFontOfSize:12]];
        btn.alpha = 1;
        [btn addTarget:self action:@selector(buttonPressed:) forControlEvents:UIControlEventTouchUpInside];
        x=x+width+45;
        cntWidth = x+width;
        [menuScrollView addSubview:btn];
        [menuScrollView addSubview:menu];
        if(cntWidth>320)
        {
            menuScrollView.contentSize = CGSizeMake(cntWidth, 27);
        }
    }
}
//- (void)viewDidAppear:(BOOL)animated
//{
//    [super viewDidAppear:animated];
//    
//    // for convenience I'm pulling these values out in to variables.
//   
//}
- (void)buttonPressed:(UIButton *)button
{
    switch (button.tag) {
        case 1:
        {
            applyBtnName = @"Adjust";
            cancelBtnName = @"Adjust";
            for (int i=101; i<=110; i++) {
                UILabel *label = (UILabel *)[self.view viewWithTag:i];
                if (i==101) {
                        [label setTextColor:[UIColor redColor]];
                }
                else {
                        [label setTextColor:[UIColor whiteColor]];
                }
                
            }
            
            [self setAdjustment];
            break;
        }
        case 2:
        {
            applyBtnName = @"Filter";
            cancelBtnName = @"Filter";
            for (int i=101; i<=110; i++) {
                UILabel *label = (UILabel *)[self.view viewWithTag:i];
                if (i==102) {
                    [label setTextColor:[UIColor redColor]];
                }
                else {
                    [label setTextColor:[UIColor whiteColor]];
                }
            }
            [self setupFilterMenu];
            break;
        }
        case 3:
        {
            applyBtnName = @"Frame";
            cancelBtnName = @"Frame";
            for (int i=101; i<=110; i++) {
                UILabel *label = (UILabel *)[self.view viewWithTag:i];
                if (i==103) {
                    [label setTextColor:[UIColor redColor]];
                }
                else {
                    [label setTextColor:[UIColor whiteColor]];
                }
                
            }
            [self setFrame];
            break;
        }
        case 4:
        {
            applyBtnName = @"Rotate";
            cancelBtnName = @"Rotate";
            [self setupRotate];
            for (int i=101; i<=108; i++) {
                UILabel *label = (UILabel *)[self.view viewWithTag:i];
                if (i==105) {
                    [label setTextColor:[UIColor redColor]];
                }
                else {
                    [label setTextColor:[UIColor whiteColor]];
                }
                
            }
            break;
        }
        case 5:
        {
            applyBtnName = @"Crop";
            cancelBtnName = @"Crop";
            [self setupCrop];
            for (int i=101; i<=108; i++) {
                UILabel *label = (UILabel *)[self.view viewWithTag:i];
                if (i==106) {
                    [label setTextColor:[UIColor redColor]];
                }
                else {
                    [label setTextColor:[UIColor whiteColor]];
                }
                
            }
            break;
   
        }
        case 6:
        {
            applyBtnName = @"Sticker";
            cancelBtnName = @"Sticker";
            [self setupSticker];
            for (int i=101; i<=108; i++) {
                UILabel *label = (UILabel *)[self.view viewWithTag:i];
                if (i==107) {
                    [label setTextColor:[UIColor redColor]];
                }
                else {
                    [label setTextColor:[UIColor whiteColor]];
                }
                
            }
            break;
        }
        case 7:
        {
            applyBtnName = @"Text";
            cancelBtnName = @"Text";
            [self setupText];
            for (int i=101; i<=108; i++) {
                UILabel *label = (UILabel *)[self.view viewWithTag:i];
                if (i==108) {
                    [label setTextColor:[UIColor redColor]];
                }
                else {
                    [label setTextColor:[UIColor whiteColor]];
                }
                
            }
            break;
        }
        case 8:
        {
            
        }
        default:
            break;
    }
}

#pragma mark - Setup Frame Methods

-(void)setFrame
{
    [btnGoEditorMenu.layer addAnimation:animation forKey:nil];
    [frameScrollView.layer addAnimation:animation forKey:nil];
    //menuScrollView.hidden = TRUE;
    [filterScrollView setHidden:YES];
    [viewAdjustOptions setHidden:YES];
    [stickerIconScrollView setHidden:YES];
    [stickerOptionView setHidden:YES];
    [stickerScrollView setHidden:YES];
    [flipRotateView setHidden:YES];
    [contrastSlider setHidden:YES];
    btnGoHome.hidden = TRUE;
    btnGoEditorMenu.hidden = FALSE;
    applyBtn.hidden = NO;
    
//    NSArray *frame_name = [NSArray arrayWithObjects:@"frame_1.png",@"frame_2.png",@"frame_3.png",@"frame_4.png",@"frame_5.png",@"frame_6.png",@"frame_7.png",@"frame_8.png",@"frame_9.png",@"frame_10.png",@"frame_11.png",@"frame_12.png",@"frame_13.png",@"frame_14.png",@"frame_15.png", nil];
    
//    NSMutableArray *frame_name = [NSMutableArray init:@"frame_1.png",@"frame_2.png",@"frame_3.png",@"frame_4.png",@"frame_5.png",@"frame_6.png",@"frame_7.png",@"frame_8.png",@"frame_9.png",@"frame_10.png",@"frame_11.png",@"frame_12.png",@"frame_13.png",@"frame_14.png",@"frame_15.png", nil];

    
    frameScrollView.contentSize = CGSizeMake(320, 78);
    NSLog(@"frame name count %d",[imagearry count]);
    int x=5;
    int y=15;
    int width=30;
    int cntWidth = width;
    for (int i=0; i<[imagearry count]; i++)
    {
        UIButton *btn = [[UIButton alloc]init];
        [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
        NSLog(@"image name :: %@",imagearry[i]);
//        [btn setImage:[UIImage imageNamed:frame_name[i] ] forState:UIControlStateNormal];
        [btn setImage:[imagearry objectAtIndex:i] forState:UIControlStateNormal];
        
        [btn setBackgroundImage:originalImage forState:UIControlStateNormal];
        btn.layer.cornerRadius = 2;
        btn.layer.masksToBounds = YES;
        [btn setTag:i+1];
        btn.layer.borderColor = [[UIColor whiteColor]CGColor];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btn.frame = CGRectMake(x, y, width,40);
        btn.backgroundColor = [UIColor clearColor];
        btn.alpha = 1;
        [btn addTarget:self action:@selector(frameButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        x=x+width+25;
        cntWidth = x+width;
        [frameScrollView addSubview:btn];
        if(cntWidth>320)
        {
            frameScrollView.contentSize = CGSizeMake(cntWidth, 52);
        }
    }
    frameScrollView.hidden = FALSE;
}

-(void)frameButtonPressed:(UIButton *)button
{
    switch (button.tag) {
        case 1:
            NSLog(@"1 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_1@2x.png"];
            break;
        case 2:
            NSLog(@"2 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_2@2x.png"];
            break;
        case 3:
            NSLog(@"3 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_3@2x.png"];
            break;
        case 4:
            NSLog(@"4 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_4@2x.png"];
            break;
        case 5:
            NSLog(@"5 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_5@2x.png"];
            break;
        case 6:
            NSLog(@"6 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_6@2x.png"];
            break;
        case 7:
            NSLog(@"7 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_7@2x.png"];
            break;
        case 8:
            NSLog(@"8 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_8@2x.png"];
            break;
        case 9:
            NSLog(@"9 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_9@2x.png"];
            break;
        case 10:
            NSLog(@"10 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_10@2x.png"];
            break;
        case 11:
            NSLog(@"11 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_11@2x.png"];
            break;
        case 12:
            NSLog(@"11 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_12@2x.png"];
            break;
        case 13:
            NSLog(@"11 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_13@2x.png"];
            break;
        case 14:
            NSLog(@"11 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_14@2x.png"];
            break;
        case 15:
            NSLog(@"11 Clicked");
            imageViewFrame.image = [UIImage imageNamed:@"frame_15@2x.png"];
            break;
        default:
            break;
    }
}

#pragma mark - Adjustment Methods
-(void)setAdjustment
{
    applyBtnName = @"Adjust";
    cancelBtnName = @"Adjust";
    [contrastSliderView setHidden:NO];
    [viewAdjustOptions setHidden:NO];
    [contrastSlider setHidden:NO];
    [frameScrollView setHidden:YES];
    [filterScrollView setHidden:YES];
    [flipRotateView setHidden:YES];
    [stickerOptionView setHidden:YES];
    [stickerIconScrollView setHidden:YES];
    [stickerScrollView setHidden:YES];
    CGAffineTransform trans = CGAffineTransformMakeRotation(M_PI * 0.5);
    contrastSlider.transform = trans;
    
    [contrastSliderView setHidden:NO];
    btnGoEditorMenu.hidden = FALSE;
    applyBtn.hidden = NO;
    [btnGoHome setHidden:YES];
    
    contrastSliderView.layer.cornerRadius = 17.0f;
    //contrastSliderView.layer.cornerRadius = 0.0f;
    
    filter=NULL;
    result=NULL;
    cgimg=NULL;
   // newimg=NULL;
    
    filter=[CIFilter filterWithName:@"CIColorControls"];
    [filter setDefaults];
    
    [filter setValue:beginImage forKey:@"inputImage"];
    [self showBrightnessSlider:self];
}

#pragma mark - Filter Methods
-(void)setupFilterMenu{
    
    [viewAdjustOptions setHidden:YES];
    [contrastSliderView setHidden:YES];
    [btnGoHome setHidden:YES];
    [flipRotateView setHidden:YES];
    [frameScrollView setHidden:YES];
    [btnGoEditorMenu setHidden:NO];
    [applyBtn setHidden:NO];
    filterTempImage = originalImage;
     [contrastSlider setHidden:YES];
    NSArray *filter_images = [NSArray arrayWithObjects:@"filter_image.png",@"blur_image.png",@"clouds_image.png",@"aqua_image.png",@"gradiant_image.png",@"mosic_image.png",@"sharpen_image.png",@"posterize_image.png",@"pure_image.png",@"pinch_image.png",@"soft_image.png",@"stylize_image.png",nil];

    
    int x=5;
    int y=5;
    int width=50;
    int cntWidth = width;
    for (int i=0; i<11; i++)
    {
        UIButton *btn = [[UIButton alloc]init];
        [btn setImage:[UIImage imageNamed:filter_images[i]] forState:UIControlStateNormal];
        btn.layer.cornerRadius = 2;
        btn.layer.masksToBounds = YES;
        [btn setTag:i+1];
        btn.layer.borderColor = [[UIColor whiteColor]CGColor];
        btn.frame = CGRectMake(x, y, width, 70);
        btn.alpha = 1;
        [btn addTarget:self action:@selector(filterButtonPressed:) forControlEvents:UIControlEventTouchUpInside];
        x=x+width+8;
        cntWidth = x+width;
        [filterScrollView addSubview:btn];
        if(cntWidth>320)
        {
            filterScrollView.contentSize = CGSizeMake(cntWidth, 52);
        }
    }
    filterScrollView.hidden = FALSE;
}

-(void)filterButtonPressed:(UIButton *)button
{
    switch (button.tag) {
        case 1:
            NSLog(@"1 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        case 2:
            NSLog(@"2 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        case 3:
            NSLog(@"3 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        case 4:
            NSLog(@"4 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        case 5:
            NSLog(@"5 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        case 6:
            NSLog(@"6 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        case 7:
            NSLog(@"7 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        case 8:
            NSLog(@"8 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        case 9:
            NSLog(@"9 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        case 10:
            NSLog(@"10 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        case 11:
            NSLog(@"11 Clicked");
            imageViewDisplay.image = [self filterImages:button.tag];
            break;
        default:
            break;
    }
}

-(UIImage *)filterImages:(NSInteger)btnTag
{
    filter=NULL;
    result=NULL;
    cgimg=NULL;
    newimg=NULL;
    
    if(btnTag==1)
    {
        filter=[CIFilter filterWithName:@"CISepiaTone"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:-2.0] forKey:@"inputIntensity"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
    }
    if(btnTag == 2)
    {
        filter = [CIFilter filterWithName:@"CIGaussianBlur"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:10.0f] forKey:@"inputRadius"];
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg = [context createCGImage:result fromRect:[result extent]];
        newimg = [UIImage imageWithCGImage:cgimg];
    }
    else if(btnTag == 3)
    {
        filter=[CIFilter filterWithName:@"CIColorMonochrome"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
    }
    else if(btnTag == 4)
    {
        filter=[CIFilter filterWithName:@"CIHueAdjust"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat: 0.5+0.7] forKey:@"inputAngle"];
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
    }
    else if(btnTag==5)
    {
        filter=[CIFilter filterWithName:@"CISepiaTone"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:-1.0] forKey:@"inputIntensity"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
    }
    else if(btnTag==6)
    {
        filter=[CIFilter filterWithName:@"CIGammaAdjust"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:0.5+0.6] forKey:@"inputPower"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
    }
    else if(btnTag==7)
    {
        filter=[CIFilter filterWithName:@"CISharpenLuminance"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:0.8*70] forKey:@"inputSharpness"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
    }
    else if(btnTag==8)
    {
        filter=[CIFilter filterWithName:@"CIColorPosterize"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:6.0] forKey:@"inputLevels"] ;
        //[filter setValue:[NSNumber numberWithFloat:0.5] forKey:@"inputRadius"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
    }
    else if(btnTag==9)
    {
        filter=[CIFilter filterWithName:@"CIVibrance"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:0.2] forKey:@"inputAmount"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
    }
    else if(btnTag==10)
    {
        filter=[CIFilter filterWithName:@"CIPinchDistortion"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[CIVector vectorWithCGPoint:CGPointMake(150, 150)]
                  forKey:@"inputCenter"];
        [filter setValue:[NSNumber numberWithFloat:300.0] forKey:@"inputRadius"] ;
        [filter setValue:[NSNumber numberWithFloat:0.20] forKey:@"inputScale"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
    }
    else if(btnTag==11)
    {
        filter=[CIFilter filterWithName:@"CIColorControls"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:0.2] forKey:@"inputBrightness"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
    }
    CFRelease(cgimg);
    return newimg;
}

#pragma mark - Blur Methods
-(void)setupBlur
{
    [btnGoHome setHidden:YES];
    [btnGoEditorMenu setHidden:NO];
    [applyBtn setHidden:NO];
    [flipRotateView setHidden:YES];
    [frameScrollView setHidden:YES];
    [commonSliderLower setHidden:NO];
    [brightnessSlider setHidden:YES];
    [brightnessSliderView setHidden:NO];
    brightnessSliderView.layer.cornerRadius = 17.0f;
}

#pragma mark - Rotate & Flip Methods
-(void)setupRotate
{
    [viewAdjustOptions setHidden:YES];
    [frameScrollView setHidden:YES];
    [filterScrollView setHidden:YES];
    [contrastSliderView setHidden:YES];
    [btnGoHome setHidden:YES];
    [btnGoEditorMenu setHidden:NO];
    [applyBtn setHidden:NO];
    [flipRotateView setHidden:NO];
    [btnFlipHorizontal setHidden:NO];
    [btnFlipVertical setHidden:NO];
    [btnRotate setHidden:NO];
    [btnGoHome setHidden:YES];
    [btnGoEditorMenu setHidden:NO];
    [applyBtn setHidden:NO];
    
    [viewAdjustOptions setHidden:YES];
    [contrastSliderView setHidden:YES];
    [stickerScrollView setHidden:YES];
    [stickerIconScrollView setHidden:YES];
    [stickerOptionView setHidden:YES];
    [frameScrollView setHidden:YES];
    [filterScrollView setHidden:YES];
   
    [viewTextOptions setHidden:YES];
    [textFieldText setHidden:YES];
    [btnedit setHidden:YES];
    [btnCross setHidden:YES];
}

#pragma mark - Crop Image Method
-(void)setupCrop
{
    [btnGoHome setHidden:YES];
    [flipRotateView setHidden:YES];
    PECropViewController *controller = [[PECropViewController alloc] init];
    controller.delegate = self;
    controller.image = self.imageViewDisplay.image;
    
    UIImage *image = self.imageViewDisplay.image;
    CGFloat width = image.size.width;
    CGFloat height = image.size.height;
    CGFloat length = MIN(width, height);
    controller.imageCropRect = CGRectMake((width - length) / 2,
                                          (height - length) / 2,
                                          length,
                                          length);
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:controller];
    [self presentViewController:navigationController animated:YES completion:NULL];
}

- (void)cropViewController:(PECropViewController *)controller didFinishCroppingImage:(UIImage *)croppedImage
{
    [controller dismissViewControllerAnimated:YES completion:NULL];
    newimg = croppedImage;
    lastSavedImage = croppedImage;
    imageViewDisplay.image = newimg;
    [btnGoEditorMenu setHidden:YES];
    [btnGoHome setHidden:NO];
    [applyBtn setHidden:YES];
}

- (void)cropViewControllerDidCancel:(PECropViewController *)controller
{
    [controller dismissViewControllerAnimated:YES completion:NULL];
    [menuScrollView setHidden:NO];
    [btnGoEditorMenu setHidden:YES];
    [btnGoHome setHidden:NO];
    imageViewDisplay.image = lastSavedImage;
    [applyBtn setHidden:YES];
}
#pragma mark - Resize Methods
-(void)setupResize
{
    [btnGoHome setHidden:YES];
    [menuScrollView setHidden:YES];
    [btnGoEditorMenu setHidden:NO];
    [applyBtn setHidden:NO];
    //[stickerScrollView setHidden:YES];
    
    
}

#pragma mark - Sticker Remove Methods
-(IBAction)btnClose_Clicked:(id)sender
{

    UIButton * close = (UIButton *)sender;
    
    UIView *viewtest=[[UIView alloc]init];
    
    viewtest =close.superview;
    
    [viewtest setHidden:YES];

}

#pragma mark - Sticker Methods

-(void)setupSticker
{
    UIRotationGestureRecognizer *rotationGestureRecognizer = [[UIRotationGestureRecognizer alloc] initWithTarget:self action:@selector(rotationGestureDetected1:)];
    [rotationGestureRecognizer setDelegate:self];
    [self.stickerIconScrollView addGestureRecognizer:rotationGestureRecognizer];
    
  //  pinchRecognizer.delegate = self;
   // panRecognizer.delegate = self;
    rotationGestureRecognizer.delegate = self;
    [stickerIconScrollView setContentSize:CGSizeMake(320, 530)];
    
    [btnGoHome setHidden:YES];
    [btnGoEditorMenu setHidden:NO];
    [applyBtn setHidden:NO];
    [viewAdjustOptions setHidden:YES];
    [contrastSliderView setHidden:YES];
    [stickerScrollView setHidden:NO];
    [stickerIconScrollView setHidden:NO];
    [stickerOptionView setHidden:NO];
    [frameScrollView setHidden:YES];
    [filterScrollView setHidden:YES];
    [applyBtn setHidden:NO];
    [viewTextOptions setHidden:YES];
    [textFieldText setHidden:YES];
    [btnedit setHidden:YES];
    [btnCross setHidden:YES];
    [btnFlipHorizontal setHidden:YES];
    [btnFlipVertical setHidden:YES];
    
    NSArray *sticker_menu = [NSArray arrayWithObjects:@"snu_1.png",@"rage_1.png",@"cat_1.png",@"expr_1.png",@"bolly_1.png",@"mus_16.png",@"hat_8.png",@"bow_3.png",@"sunglasses_6.png",@"funny_caricatures1.png", nil];
    frameScrollView.contentSize = CGSizeMake(320, 78);
    int x=10;
    int y=10;
    int width=50;
    int cntWidth = width;
    for (int i=0; i<[sticker_menu count]; i++)
    {
        UIButton *btn = [[UIButton alloc]init];
        [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
        [btn setImage:[UIImage imageNamed:sticker_menu[i]] forState:UIControlStateNormal];
        //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
        btn.layer.cornerRadius = 2;
        btn.layer.masksToBounds = YES;
        [btn setTag:i+1];
        btn.layer.borderColor = [[UIColor whiteColor]CGColor];
        [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btn.frame = CGRectMake(x, y, width, 50);
        btn.backgroundColor = [UIColor clearColor];
        btn.alpha = 1;
        [btn addTarget:self action:@selector(stickerMenuPressed:) forControlEvents:UIControlEventTouchUpInside];
        x=x+width+30;
        cntWidth = x+width;
        [stickerScrollView addSubview:btn];
        if(cntWidth>320)
        {
            stickerScrollView.contentSize = CGSizeMake(cntWidth, 52);
        }
    }
    stickerScrollView.hidden = FALSE;
    
    [lblStickerOptionTitle setText:@"Snuggles"];
    for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
        [subview1 removeFromSuperview];
    }
    
    
    UIButton *btn1;
//    stickerIconScrollView.contentSize = CGSizeMake(320, 82);
//    [stickerOptionView setHidden:NO];
//    sticker_icon_name = [[NSMutableArray alloc]init];
//    sticker_icon_name = [NSMutableArray arrayWithObjects:@"snu_1.png",@"snu_2.png",@"snu_3.png",@"snu_4.png",@"snu_5.png",@"snu_6.png",@"snu_7.png",@"snu_8.png", nil];
//    x=17;
//    y=5;
//    width=50;
//    cntWidth = width;
//    for (int i=0; i<[sticker_icon_name count]; i++)
//    {
//        btn1 = [[UIButton alloc]init];
//        [btn1.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
//        [btn1 setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
//        //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
//        btn1.layer.cornerRadius = 2;
//        btn1.layer.masksToBounds = YES;
//        [btn1 setTag:i+1];
//        btn1.layer.borderColor = [[UIColor whiteColor]CGColor];
//        [btn1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//        btn1.frame = CGRectMake(x, y, width, 50);
//        btn1.backgroundColor = [UIColor clearColor];
//        btn1.alpha = 1;
//        [btn1 addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
//        x=x+width+30;
//        cntWidth = x+width;
//        inttag = 1;
//        [stickerIconScrollView addSubview:btn1];
//        if(cntWidth>=320)
//        {
//            stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
//            y=y+60;
//            x=17;
//        }
//    }
    inttag = 2;
    [lblStickerOptionTitle setText:@"Rage Faces"];
    for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
        [subview1 removeFromSuperview];
    }
    
    sticker_icon_name = [[NSMutableArray alloc]init];
   sticker_icon_name = [NSMutableArray arrayWithObjects:@"snu_1.png",@"snu_2.png",@"snu_3.png",@"snu_4.png",@"snu_5.png",@"snu_6.png",@"snu_7.png",@"snu_8.png", nil];
    x=17;
    y=5;
    width=50;
    cntWidth = width;
    for (int i=0; i<[sticker_icon_name count]; i++)
    {
        btn1 = [[UIButton alloc]init];
        [btn1.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
        [btn1 setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
        //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
        btn1.layer.cornerRadius = 2;
        btn1.layer.masksToBounds = YES;
        [btn1 setTag:i];
        btn1.layer.borderColor = [[UIColor whiteColor]CGColor];
        [btn1 setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
        btn1.frame = CGRectMake(x, y, width, 50);
        btn1.backgroundColor = [UIColor clearColor];
        btn1.alpha = 1;
        [btn1 addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
        x=x+width+30;
        cntWidth = x+width;
        [stickerIconScrollView addSubview:btn1];
        if(cntWidth>=320)
        {
            stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
            y=y+60;
            x=17;
        }
    }

//    UIPinchGestureRecognizer *pinchRecognizer1 = [[UIPinchGestureRecognizer alloc] initWithTarget:self action:@selector(pinchDetected1:)];
//    [self.bottomView addGestureRecognizer:pinchRecognizer1];
}

-(void)stickerMenuPressed:(UIButton *)button
{
   
    UIButton *btn;
    stickerIconScrollView.contentSize = CGSizeMake(320, 82);
    [stickerOptionView setHidden:NO];
    
    int x=17;
    int y=5;
    int width=50;
    int cntWidth = width;
    NSLog(@"button tag : %d",button.tag);
    switch (button.tag) {
        case 1:
//            inttag =1;
//            [lblStickerOptionTitle setText:@"Snuggles"];
//            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
//                [subview1 removeFromSuperview];
//            }
//            sticker_icon_name = [[NSMutableArray alloc]init];
//            sticker_icon_name = [NSMutableArray arrayWithObjects:@"snu_1.png",@"snu_2.png",@"snu_3.png",@"snu_4.png",@"snu_5.png",@"snu_6.png",@"snu_7.png",@"snu_8.png", nil];
//            x=17;
//            y=5;
//            width=50;
//            cntWidth = width;
//            for (int i=0; i<[sticker_icon_name count]; i++)
//            {
//                btn = [[UIButton alloc]init];
//                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
//                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
//                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
//                btn.layer.cornerRadius = 2;
//                btn.layer.masksToBounds = YES;
//                [btn setTag:i];
//                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
//                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
//                btn.frame = CGRectMake(x, y, width, 50);
//                btn.backgroundColor = [UIColor clearColor];
//                btn.alpha = 1;
//                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
//                x=x+width+30;
//                cntWidth = x+width;
//                [stickerIconScrollView addSubview:btn];
//                if(cntWidth>=320)
//                {
//                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
//                    y=y+60;
//                    x=17;
//                }
//            }
            //                inttag = 2;
            [lblStickerOptionTitle setText:@"Rage Faces"];
            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
                [subview1 removeFromSuperview];
            }
            
            sticker_icon_name = [[NSMutableArray alloc]init];
           sticker_icon_name = [NSMutableArray arrayWithObjects:@"snu_1.png",@"snu_2.png",@"snu_3.png",@"snu_4.png",@"snu_5.png",@"snu_6.png",@"snu_7.png",@"snu_8.png", nil];
            x=17;
            y=5;
            width=50;
            cntWidth = width;
            for (int i=0; i<[sticker_icon_name count]; i++)
            {
                btn = [[UIButton alloc]init];
                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
                btn.layer.cornerRadius = 2;
                btn.layer.masksToBounds = YES;
                [btn setTag:i];
                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.frame = CGRectMake(x, y, width, 50);
                btn.backgroundColor = [UIColor clearColor];
                btn.alpha = 1;
                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
                x=x+width+30;
                cntWidth = x+width;
                [stickerIconScrollView addSubview:btn];
                if(cntWidth>=320)
                {
                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
                    y=y+60;
                    x=17;
                }
            }

            break;
        case 2:
                        inttag = 2;
            [lblStickerOptionTitle setText:@"Rage Faces"];
            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
                [subview1 removeFromSuperview];
            }
            
            sticker_icon_name = [[NSMutableArray alloc]init];
            sticker_icon_name = [NSMutableArray  arrayWithObjects:@"rage_1.png",@"rage_2.png",@"rage_3.png",@"rage_4.png",@"rage_5.png",@"rage_6.png",@"rage_7.png",@"rage_8.png",@"rage_9.png",@"rage_10.png",@"rage_11.png",@"rage_12.png",@"rage_13.png",@"rage_14.png",@"rage_15.png",@"rage_16.png",@"rage_17.png",@"rage_18.png",@"rage_19.png",@"rage_20.png",@"rage_21.png",@"rage_22.png",@"rage_23.png",@"rage_24.png", nil];
             x=17;
             y=5;
             width=50;
             cntWidth = width;
            for (int i=0; i<[sticker_icon_name count]; i++)
            {
                btn = [[UIButton alloc]init];
                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
                btn.layer.cornerRadius = 2;
                btn.layer.masksToBounds = YES;
               [btn setTag:i];
                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.frame = CGRectMake(x, y, width, 50);
                btn.backgroundColor = [UIColor clearColor];
                btn.alpha = 1;
                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
                x=x+width+30;
                cntWidth = x+width;
                [stickerIconScrollView addSubview:btn];
                if(cntWidth>=320)
                {
                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
                    y=y+60;
                    x=17;
                }
            }
            break;
        case 3:
                        inttag = 3;
            [lblStickerOptionTitle setText:@"Miley Cat"];
            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
                [subview1 removeFromSuperview];
            }
            
            sticker_icon_name = [[NSMutableArray alloc]init];
            sticker_icon_name = [NSMutableArray  arrayWithObjects:@"cat_1.png",@"cat_2.png",@"cat_3.png",@"cat_4.png",@"cat_5.png",@"cat_6.png",@"cat_7.png",@"cat_8.png", nil];
            x=17;
            y=5;
            width=50;
            cntWidth = width;
            for (int i=0; i<[sticker_icon_name count]; i++)
            {
                btn = [[UIButton alloc]init];
                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
                btn.layer.cornerRadius = 2;
                btn.layer.masksToBounds = YES;
                [btn setTag:i];
                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.frame = CGRectMake(x, y, width, 50);
                btn.backgroundColor = [UIColor clearColor];
                btn.alpha = 1;
                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
                x=x+width+30;
                cntWidth = x+width;
                [stickerIconScrollView addSubview:btn];
                if(cntWidth>=320)
                {
                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
                    y=y+60;
                    x=17;
                }
            }
            break;
        case 4:
                        inttag = 4 ;
            [lblStickerOptionTitle setText:@"Expressions"];
            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
                [subview1 removeFromSuperview];
            }
            
            sticker_icon_name = [[NSMutableArray alloc]init];
            sticker_icon_name = [NSMutableArray   arrayWithObjects:@"expr_1.png",@"expr_2.png",@"expr_3.png",@"expr_4.png",@"expr_5.png",@"expr_6.png",@"expr_7.png",@"expr_8.png",@"expr_9.png",@"expr_10.png",@"expr_11.png",@"expr_12.png",@"expr_13.png",@"expr_14.png",@"expr_15.png",@"expr_16.png", nil];
            x=17;
            y=5;
            width=50;
            cntWidth = width;
            for (int i=0; i<[sticker_icon_name count]; i++)
            {
                btn = [[UIButton alloc]init];
                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
                btn.layer.cornerRadius = 2;
                btn.layer.masksToBounds = YES;
                [btn setTag:i];
                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.frame = CGRectMake(x, y, width, 50);
                btn.backgroundColor = [UIColor clearColor];
                btn.alpha = 1;
                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
                x=x+width+30;
                cntWidth = x+width;
                [stickerIconScrollView addSubview:btn];
                if(cntWidth>=320)
                {
                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
                    y=y+60;
                    x=17;
                }
            }
            break;
        case 5:
                        inttag = 5;
            [lblStickerOptionTitle setText:@"Bollywood"];
            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
                [subview1 removeFromSuperview];
            }
            
            sticker_icon_name = [[NSMutableArray alloc]init];
            sticker_icon_name = [NSMutableArray  arrayWithObjects:@"bolly_1.png",@"bolly_2.png",@"bolly_3.png",@"bolly_4.png",@"bolly_5.png",@"bolly_6.png",@"bolly_7.png",@"bolly_8.png", nil];
            x=17;
            y=5;
            width=50;
            cntWidth = width;
            for (int i=0; i<[sticker_icon_name count]; i++)
            {
                btn = [[UIButton alloc]init];
                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
                btn.layer.cornerRadius = 2;
                btn.layer.masksToBounds = YES;
                [btn setTag:i];
                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.frame = CGRectMake(x, y, width, 50);
                btn.backgroundColor = [UIColor clearColor];
                btn.alpha = 1;
                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
                x=x+width+30;
                cntWidth = x+width;
                [stickerIconScrollView addSubview:btn];
                if(cntWidth>=320)
                {
                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
                    y=y+60;
                    x=17;
                }
            }
            break;
        case 6:
                        inttag =6;
            [lblStickerOptionTitle setText:@"Mustache"];
            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
                [subview1 removeFromSuperview];
            }
            
            sticker_icon_name = [[NSMutableArray alloc]init];
            sticker_icon_name = [NSMutableArray  arrayWithObjects:@"mus_1.png",@"mus_2.png",@"mus_3.png",@"mus_4.png",@"mus_5.png",@"mus_6.png",@"mus_7.png",@"mus_8.png",@"mus_9.png",@"mus_10.png",@"mus_11.png",@"mus_12.png",@"mus_13.png",@"mus_14.png",@"mus_15.png",@"mus_16.png",nil];
            x=17;
            y=5;
            width=50;
            cntWidth = width;
            for (int i=0; i<[sticker_icon_name count]; i++)
            {
                btn = [[UIButton alloc]init];
                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
                btn.layer.cornerRadius = 2;
                btn.layer.masksToBounds = YES;
                [btn setTag:i];
                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.frame = CGRectMake(x, y, width, 30);
                btn.backgroundColor = [UIColor clearColor];
                btn.alpha = 1;
                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
                x=x+width+30;
                cntWidth = x+width;
                [stickerIconScrollView addSubview:btn];
                if(cntWidth>=320)
                {
                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
                    y=y+60;
                    x=17;
                }
            }
            break;
        case 7:
                        inttag =7;
            [lblStickerOptionTitle setText:@"Hat"];
            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
                [subview1 removeFromSuperview];
            }
            
            sticker_icon_name = [[NSMutableArray alloc]init];
            sticker_icon_name = [NSMutableArray   arrayWithObjects:@"hat_1.png",@"hat_2.png",@"hat_3.png",@"hat_4.png",@"hat_5.png",@"hat_6.png",@"hat_7.png",@"hat_8.png",nil];
            x=17;
            y=5;
            width=50;
            cntWidth = width;
            for (int i=0; i<[sticker_icon_name count]; i++)
            {
                btn = [[UIButton alloc]init];
                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
                btn.layer.cornerRadius = 2;
                btn.layer.masksToBounds = YES;
                [btn setTag:i];
                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.frame = CGRectMake(x, y, width, 30);
                btn.backgroundColor = [UIColor clearColor];
                btn.alpha = 1;
                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
                x=x+width+30;
                cntWidth = x+width;
                [stickerIconScrollView addSubview:btn];
                if(cntWidth>=320)
                {
                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
                    y=y+60;
                    x=17;
                }
            }
            break;
        case 9:
                        inttag =9;
            [lblStickerOptionTitle setText:@"Sunglasses"];
            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
                [subview1 removeFromSuperview];
            }
            
            sticker_icon_name = [[NSMutableArray alloc]init];
            sticker_icon_name = [NSMutableArray  arrayWithObjects:@"sunglasses_1.png",@"sunglasses_2.png",@"sunglasses_3.png",@"sunglasses_4.png",@"sunglasses_5.png",@"sunglasses_6.png",@"sunglasses_7.png",@"sunglasses_8.png",nil];
            x=17;
            y=5;
            width=50;
            cntWidth = width;
            for (int i=0; i<[sticker_icon_name count]; i++)
            {
                btn = [[UIButton alloc]init];
                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
                btn.layer.cornerRadius = 2;
                btn.layer.masksToBounds = YES;
                [btn setTag:i];
                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.frame = CGRectMake(x, y, width, 30);
                btn.backgroundColor = [UIColor clearColor];
                btn.alpha = 1;
                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
                x=x+width+30;
                cntWidth = x+width;
                [stickerIconScrollView addSubview:btn];
                if(cntWidth>=320)
                {
                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
                    y=y+60;
                    x=17;
                }
            }
            break;
        case 10:
            inttag =10;
            [lblStickerOptionTitle setText:@"Funny Character"];
            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
                [subview1 removeFromSuperview];
            }
            
            sticker_icon_name = [[NSMutableArray alloc]init];
            sticker_icon_name = [NSMutableArray   arrayWithObjects:@"funny_caricatures1.png",@"funny_caricatures2.png",@"funny_caricatures3.png",@"funny_caricatures4.png",@"funny_caricatures5.png",@"funny_caricatures6.png",@"funny_caricatures7.png",@"funny_caricatures8.png",nil];
            x=17;
            y=5;
            width=50;
            cntWidth = width;
            for (int i=0; i<[sticker_icon_name count]; i++)
            {
                btn = [[UIButton alloc]init];
                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
                btn.layer.cornerRadius = 2;
                btn.layer.masksToBounds = YES;
                [btn setTag:i];
                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.frame = CGRectMake(x, y, width, 50);
                btn.backgroundColor = [UIColor clearColor];
                btn.alpha = 1;
                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
                x=x+width+30;
                cntWidth = x+width;
                [stickerIconScrollView addSubview:btn];
                if(cntWidth>=320)
                {
                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
                    y=y+60;
                    x=17;
                }
            }
            break;
        case 8:
                        inttag =8;
            [lblStickerOptionTitle setText:@"Bow"];
            for(UIView *subview1 in [self.stickerIconScrollView subviews]) {
                [subview1 removeFromSuperview];
            }
            
            sticker_icon_name = [[NSMutableArray alloc]init];
            sticker_icon_name = [NSMutableArray   arrayWithObjects:@"bow_1.png",@"bow_2.png",@"bow_3.png",@"bow_4.png",@"bow_5.png",@"bow_6.png",@"bow_7.png",@"bow_8.png",nil];
            x=17;
            y=5;
            width=50;
            cntWidth = width;
            for (int i=0; i<[sticker_icon_name count]; i++)
            {
                btn = [[UIButton alloc]init];
                [btn.titleLabel setFont:[UIFont boldSystemFontOfSize:16] ];
                [btn setImage:[UIImage imageNamed:sticker_icon_name[i]] forState:UIControlStateNormal];
                //[btn setBackgroundImage:originalImage forState:UIControlStateNormal];
                btn.layer.cornerRadius = 2;
                btn.layer.masksToBounds = YES;
               [btn setTag:i];
                btn.layer.borderColor = [[UIColor whiteColor]CGColor];
                [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
                btn.frame = CGRectMake(x, y, width, 30);
                btn.backgroundColor = [UIColor clearColor];
                btn.alpha = 1;
                [btn addTarget:self action:@selector(addSticker:) forControlEvents:UIControlEventTouchUpInside];
                x=x+width+30;
                cntWidth = x+width;
                [stickerIconScrollView addSubview:btn];
                if(cntWidth>=320)
                {
                    stickerIconScrollView.contentSize = CGSizeMake(320,y+60);
                    y=y+60;
                    x=17;
                }
            }
            break;
        default:
            break;
    }
}

-(void)addSticker:(UIButton *)button{
    
    [closeVw setHidden:YES];
    [resizeVw setHidden:YES];
    [rotateVw setHidden:YES];
    imgvw.layer.borderColor = [[UIColor clearColor]CGColor];

   
    
    
    UIView *testVw = [[UIView alloc]initWithFrame:CGRectMake(100, 100, 85, 85)];
    testVw.backgroundColor = [UIColor clearColor];
    
    imgvw = [[UIImageView alloc]initWithFrame:CGRectMake(12, 12, testVw.frame.size.width-24, testVw.frame.size.height-27)];
    imgvw.backgroundColor = [UIColor clearColor];
    imgvw.layer.borderColor = [[UIColor brownColor]CGColor];
    imgvw.layer.borderWidth = 2.0f;
    imgvw.userInteractionEnabled = YES;
    
    //    NSLog(@"image name :: %@",[sticker_icon_name objectAtIndex:button.tag]);
    NSLog(@"sticker count :: %d",[sticker_icon_name count]);
     NSLog(@"button tag :: %d",button.tag);
    
    imgvw.image = [UIImage imageNamed:[sticker_icon_name objectAtIndex:button.tag] ];
    
    [testVw addSubview:imgvw];
    closeVw = [[UIImageView alloc]initWithFrame:CGRectMake(0, 0, 25, 25)];
    closeVw.backgroundColor = [UIColor clearColor];
    closeVw.image = [UIImage imageNamed:@"close_gold.png" ];
    closeVw.userInteractionEnabled = YES;
    [testVw addSubview:closeVw];
    
    
    UIButton *btnCloseSticker=[[UIButton alloc]init];
    [btnCloseSticker setFrame:CGRectMake(0, 0, 25, 25)];
    [btnCloseSticker addTarget:self action:@selector(btnClose_Clicked:) forControlEvents:UIControlEventTouchUpInside];
    
    
    [testVw addSubview:btnCloseSticker];
    
    [testVw addGestureRecognizer:self.pinchSticker];
    
    
    //Resizing view which is in bottom right corner
    
    UIPanGestureRecognizer * panMoveGesture = [[UIPanGestureRecognizer alloc] initWithTarget:self action:@selector(panGestureAction:)];
    [testVw addGestureRecognizer:panMoveGesture];
    [panMoveGesture requireGestureRecognizerToFail:panMoveGesture];
    
//      [imageViewDisplay addSubview:testVw];
    [self.bottomView addSubview:testVw];
    [stickerOptionView setHidden:YES];
}
- (IBAction)handlePinch:(UIPinchGestureRecognizer *)recognizer {
    
    recognizer.view.transform = CGAffineTransformScale(recognizer.view.transform, recognizer.scale, recognizer.scale);
    recognizer.scale = 1;
    
}

- (IBAction)handleRotate:(UIRotationGestureRecognizer *)recognizer {
    
    recognizer.view.transform = CGAffineTransformRotate(recognizer.view.transform, recognizer.rotation);
    recognizer.rotation = 0;
    
}

-(void)panGestureAction:(UIPanGestureRecognizer *)pan {
   
    
        CGPoint velocity = [pan velocityInView:self.view];
        CGFloat magnitude = sqrtf((velocity.x * velocity.x) + (velocity.y * velocity.y));
        CGFloat slideMult = magnitude / 400;
        NSLog(@"magnitude: %f, slideMult: %f", magnitude, slideMult);
        
        float slideFactor = 0.05 * slideMult; // Increase for more of a slide
        CGPoint finalPoint = CGPointMake(pan.view.center.x + (velocity.x * slideFactor),
                                         pan.view.center.y + (velocity.y * slideFactor));
        finalPoint.x = MIN(MAX(finalPoint.x, 0), self.view.bounds.size.width);
        finalPoint.y = MIN(MAX(finalPoint.y, 0), self.view.bounds.size.height);
        
        [UIView animateWithDuration:slideFactor*2 delay:0 options:UIViewAnimationOptionCurveEaseOut animations:^{
            pan.view.center = finalPoint;
        } completion:nil];

}


-(void)resizeTranslate:(UIPanGestureRecognizer *)recognizer
{
    UIView *testVw =recognizer.view;
    
    //recognizer.view.tag
    resizeVw = (UIImageView *)[testVw viewWithTag:10002];
    imgvw = (UIImageView *)[testVw viewWithTag:10004];
    closeVw = (UIImageView *)[testVw viewWithTag:10003];
    rotateVw = (UIImageView *)[testVw viewWithTag:10001];
    
    if ([recognizer state]== UIGestureRecognizerStateBegan)
    {
        prevPoint = [recognizer locationInView:testVw.superview];
        [testVw setNeedsDisplay];
    }
    else if ([recognizer state] == UIGestureRecognizerStateChanged)
    {
        if (testVw.bounds.size.width < 20)
        {
            
            testVw.bounds = CGRectMake(testVw.bounds.origin.x, testVw.bounds.origin.y, 20, testVw.bounds.size.height);
        }
        
        if(testVw.bounds.size.height < 20)
        {
            testVw.bounds = CGRectMake(testVw.bounds.origin.x, testVw.bounds.origin.y, testVw.bounds.size.width, 20);
        }
        
        CGPoint point = [recognizer locationInView:testVw.superview];
        float wChange = 0.0, hChange = 0.0;
        
        wChange = (point.x - prevPoint.x); //Slow down increment
        hChange = (point.y - prevPoint.y); //Slow down increment
        
        
        testVw.bounds = CGRectMake(testVw.bounds.origin.x, testVw.bounds.origin.y, testVw.bounds.size.width + (wChange), testVw.bounds.size.height + (hChange));
        prevPoint = [recognizer locationInView:testVw.superview];
        
        [testVw setNeedsDisplay];
    }
    else if ([recognizer state] == UIGestureRecognizerStateEnded)
    {
        
        prevPoint = [recognizer locationInView:testVw.superview];
        [testVw setNeedsDisplay];
    }
}

-(void)rotateViewPanGesture:(UIPanGestureRecognizer *)recognizer
{
    UIView *testVw =(UIView *)recognizer.view;
    resizeVw = (UIImageView *)[testVw viewWithTag:10002];
    imgvw = (UIImageView *)[testVw viewWithTag:10004];
    closeVw = (UIImageView *)[testVw viewWithTag:10003];
    rotateVw = (UIImageView *)[testVw viewWithTag:10001];
    if ([recognizer state] == UIGestureRecognizerStateBegan)
    {
        deltaAngle = atan2([recognizer locationInView:testVw].y-testVw.center.y, [recognizer locationInView:testVw].x-testVw.center.x);
        startTransform = testVw.transform;
    }
    else if ([recognizer state] == UIGestureRecognizerStateChanged)
    {
        float ang = atan2([recognizer locationInView:testVw.superview].y - testVw.center.y, [recognizer locationInView:testVw.superview].x - testVw.center.x);
        float angleDiff = deltaAngle - ang;
        testVw.transform = CGAffineTransformMakeRotation(-angleDiff);
        [testVw setNeedsDisplay];
    }
    else if ([recognizer state] == UIGestureRecognizerStateEnded)
    {
        deltaAngle = atan2([recognizer locationInView:testVw].y-testVw.center.y, [recognizer locationInView:testVw].x-testVw.center.x);
        startTransform = testVw.transform;
        [testVw setNeedsDisplay];
    }
}
- (BOOL)shouldAutorotateToInterfaceOrientation:(UIInterfaceOrientation)interfaceOrientation
{
    // Return YES for supported orientations
    return (interfaceOrientation == UIInterfaceOrientationPortraitUpsideDown);
}

#pragma mark - Text Manage Methods
-(void)setupText
{
    [viewAdjustOptions setHidden:YES];
    [filterScrollView setHidden:YES];
    [frameScrollView setHidden:YES];
    [contrastSliderView setHidden:YES];
    [contrastSlider setHidden:YES];
    [flipRotateView setHidden:YES];
    [btnFlipHorizontal setHidden:YES];
    [btnFlipVertical setHidden:YES];
    [stickerIconScrollView setHidden:YES];
    [stickerOptionView setHidden:YES];
    [stickerScrollView setHidden:YES];
    [btnGoEditorMenu setHidden:NO];
    [applyBtn setHidden:NO];
    [viewTextOptions setHidden:NO];
    [textFieldText setHidden:NO];
    [textFieldText setDelegate:self];
    
    [btnGoHome setHidden:YES];
//    [UIView animateWithDuration:0.animations:^{
//        viewTextfield.layer.transform = CATransform3DIdentity;
//        viewTextfield.layer.opacity = 1;
//    }];
    
  
    [viewTextfield setHidden:NO];

//    SMRotaryWheel *wheel = [[SMRotaryWheel alloc] initWithFrame:CGRectMake(0, 0, 200, 200)
//                                                    andDelegate:self
//                                                   withSections:0];
//    
//    wheel.center = CGPointMake(160, 240);
//    [self.view addSubview:wheel];

    
    
    
}
 

- (IBAction)rotate:(UIRotationGestureRecognizer *)recognizer {
    
    if (recognizer.view == viewTextfield) {
        recognizer.view.transform = CGAffineTransformRotate(recognizer.view.transform, recognizer.rotation);
        recognizer.rotation = 0;
        
    }

}

-(BOOL)textFieldShouldReturn:(UITextField *)textField
{
   [textFieldText setBorderStyle:UITextBorderStyleNone];
   return [textField resignFirstResponder];
}

-(void)textFieldDidEndEditing:(UITextField *)textField{
    
}
-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    textFieldText.layer.borderWidth = 1;
   // textFieldText.layer.borderColor = [[UIColor redColor] CGColor];
    return true;
}
- (IBAction)changeFontStyle:(id)sender {
    tag = 1;
    [textManageView setHidden:NO];
    [tableViewFontName setHidden:NO];
    [tableViewFontStyle setHidden:YES];
    indFontNames = [[NSMutableArray alloc]init];
    familyNames = [[NSArray alloc] initWithArray:[UIFont familyNames]];
    for (indFamily=0; indFamily<[familyNames count]; ++indFamily)
    {
        fontNames = [[NSArray alloc] initWithArray:
                     [UIFont fontNamesForFamilyName:
                      [familyNames objectAtIndex:indFamily]]];
        for (indFont=0; indFont<[fontNames count]; ++indFont)
        {
            [indFontNames addObject:[fontNames objectAtIndex:indFont]];
        }
    }
    [self.tableViewFontName setDelegate:self];

    [tableViewFontName reloadData];
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tag==1) {
        return [indFontNames count];
    } else {
        return [fontSize count];
    }
}

-(UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    static NSString *CellIdentifier = @"Cell";
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    if (cell == nil) {
        cell = [[UITableViewCell alloc]
                initWithStyle:UITableViewCellStyleDefault
                reuseIdentifier:CellIdentifier];
    }
    if (tag==1) {
        cell.textLabel.text = [indFontNames
                               objectAtIndex: [indexPath row]];
    }
    else{
        cell.textLabel.text = [fontSize
                               objectAtIndex: [indexPath row]];
    }
    return cell;
}
-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    UITableViewCell *cell = [tableView cellForRowAtIndexPath:indexPath];
    if (tag==1) {
        NSString *fname = cell.textLabel.text;
        textFieldText.font = [UIFont fontWithName:fname size:20];
    } else {
        NSInteger size1 = (NSInteger)cell.textLabel.text;
        [textFieldText setFont:[UIFont systemFontOfSize:size1]];
    }
    
}

- (IBAction)changeFontSize:(id)sender {
    tag = 2;
    [textManageView setHidden:NO];
    [tableViewFontName setHidden:YES];
    [tableViewFontStyle setHidden:NO];
    fontNames = [[NSArray alloc]initWithObjects:@"11",@"12",@"14",@"16",@"18",@"20",@"24",@"28",@"32",@"36",@"48",@"72", nil];
    [tableViewFontStyle setDelegate:self];
    [tableViewFontStyle reloadData];
}

- (IBAction)changeFontColor:(id)sender {
    [textManageView setHidden:YES];
    FCColorPickerViewController *colorView = [[FCColorPickerViewController alloc]init];
    [colorView setDelegate:self];
    UINavigationController *navigationController = [[UINavigationController alloc] initWithRootViewController:colorView];
    [colorView.navigationController setNavigationBarHidden:YES];
    [self presentViewController:navigationController animated:YES completion:NULL];
}

- (void)colorPickerViewController:(FCColorPickerViewController *)colorPicker didSelectColor:(UIColor *)color
{
    textFieldText.textColor = color;
    [self dismissViewControllerAnimated:YES completion:nil];
}

- (void)colorPickerViewControllerDidCancel:(FCColorPickerViewController *)colorPicker
{
    [self dismissViewControllerAnimated:YES completion:nil];
}

#pragma mark - Gesture Events

- (IBAction)handlePan:(UIPanGestureRecognizer *)recognizer
{
    CGPoint translation = [recognizer translationInView:self.imageViewDisplay];
    recognizer.view.center = CGPointMake(recognizer.view.center.x + translation.x,
                                         recognizer.view.center.y + translation.y);
    [recognizer setTranslation:CGPointMake(0, 0) inView:self.imageViewDisplay];
}
- (IBAction)handlePanfortext:(UIPanGestureRecognizer *)recognizer {
    
    // Comment for panning
    // Uncomment for tickling
    //return;
    
    CGPoint translation = [recognizer translationInView:self.view];
    recognizer.view.center = CGPointMake(recognizer.view.center.x + translation.x,
                                         recognizer.view.center.y + translation.y);
    [recognizer setTranslation:CGPointMake(0, 0) inView:self.view];
    
    
    CGPoint translationbtn = [recognizer translationInView:self.view];
    btnCross.center = CGPointMake(recognizer.view.center.x-115 + translationbtn.x,
                                recognizer.view.center.y-35 + translationbtn.y);
    [recognizer setTranslation:CGPointMake(0, 0) inView:self.view];
}



- (void)rotationGestureDetected:(UIRotationGestureRecognizer *)recognizer
{
    CGFloat angle = recognizer.rotation;
    self.imageViewDisplay.transform = CGAffineTransformRotate(self.imageViewDisplay.transform, angle);
    recognizer.rotation = 0.0;
    
}
- (void)rotationGestureDetected1:(UIRotationGestureRecognizer *)recognizer
{
    CGFloat angle = recognizer.rotation;
    self.stickerIconScrollView.transform = CGAffineTransformRotate(self.stickerIconScrollView.transform, angle);
    recognizer.rotation = 0.0;
    
}
- (BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldRecognizeSimultaneouslyWithGestureRecognizer:(UIGestureRecognizer *)otherGestureRecognizer
{
    return YES;
}
-(BOOL)gestureRecognizer:(UIGestureRecognizer *)gestureRecognizer shouldReceiveTouch:(UITouch *)touch
{
   // NSLog(@"touched");
    return YES;
}

#pragma mark - Handle Buttons (Apply,Cancel)
- (IBAction)goHome:(id)sender {
    
    [self.navigationController popToRootViewControllerAnimated:YES];
}

- (IBAction)goEditorMenu:(id)sender {
    
    if([cancelBtnName isEqualToString:@"Frame"])
    {
        [btnGoHome.layer addAnimation:animation forKey:nil];
        [frameScrollView.layer addAnimation:animation forKey:nil];
        applyBtn.hidden = YES;
        btnGoHome.hidden = FALSE;
        btnGoEditorMenu.hidden = TRUE;
        imageViewFrame.image = nil;
    }
    else if([cancelBtnName isEqualToString:@"Adjust"])
    {
        [contrastSliderView.layer addAnimation:animation forKey:nil];
        applyBtn.hidden = YES;
        btnGoHome.hidden = FALSE;
        btnGoEditorMenu.hidden = TRUE;
        [menuScrollView.layer addAnimation:animation forKey:nil];
        imageViewDisplay.image = originalImage;
    }
    else if([cancelBtnName isEqualToString:@"Filter"]){
        
        [btnGoHome.layer addAnimation:animation forKey:nil];
        applyBtn.hidden = YES;
        btnGoHome.hidden = FALSE;
        btnGoEditorMenu.hidden = TRUE;
        [menuScrollView.layer addAnimation:animation forKey:nil];
        imageViewDisplay.image = originalImage;
    }
    else if([cancelBtnName isEqualToString:@"Rotate"]){
        [applyBtn setHidden:YES];
        [btnGoEditorMenu setHidden:YES];
        [btnGoHome setHidden:NO];
        [menuScrollView setHidden:NO];
        imageViewDisplay.image = originalImage;
    }
    else if([cancelBtnName isEqualToString:@"Sticker"]){
        [applyBtn setHidden:YES];
        [btnGoEditorMenu setHidden:YES];
        [btnGoHome setHidden:NO];
        [menuScrollView setHidden:NO];
        [stickerScrollView setHidden:YES];
        imageViewDisplay.image = originalImage;
        [stickerOptionView setHidden:YES];
    }
    else if([cancelBtnName
             isEqualToString:@"Text"]){
        [applyBtn setHidden:YES];
        [btnGoEditorMenu setHidden:YES];
        [btnGoHome setHidden:NO];
        [menuScrollView setHidden:NO];
        [textManageView setHidden:YES];
        [viewTextOptions setHidden:NO];
    }
}

//- (UIImage*)captureView:(UIView *)yourView {
////    CGRect rect = [[UIScreen mainScreen] bounds];
//    CGRect rect = CGRectMake(250,61 ,410, 255);
//    UIGraphicsBeginImageContext(rect.size);
//    CGContextRef context = UIGraphicsGetCurrentContext();
//    [yourView.layer renderInContext:context];
//    newimg = UIGraphicsGetImageFromCurrentImageContext();
//    UIGraphicsEndImageContext();
//    return newimg;
//}

- (UIImage *)captureView:(UIView *)view {
   // CGRect screenRect = [[UIScreen mainScreen] bounds];
//    CGRect screenRect = CGRectMake(250,61 ,410, 255);
//    UIGraphicsBeginImageContext(screenRect.size);
//    
//    CGContextRef ctx = UIGraphicsGetCurrentContext();
//    [[UIColor clearColor] set];
//    CGContextFillRect(ctx, screenRect);
//    
//    [view.layer renderInContext:ctx];
//    
//    newimg = UIGraphicsGetImageFromCurrentImageContext();
//    
//    UIGraphicsEndImageContext();
//    
//    return newimg;
    
    UIGraphicsBeginImageContextWithOptions(view.bounds.size, view.opaque, 0.0);
    [view.layer renderInContext:UIGraphicsGetCurrentContext()];
    
    UIImage * img = UIGraphicsGetImageFromCurrentImageContext();
    
    UIGraphicsEndImageContext();
    
    return img;
}

- (IBAction)applyDone:(id)sender {
    
    
    if ([applyBtnName isEqualToString:@"Frame"]) {
        applyBtn.hidden = YES;
        [btnGoHome.layer addAnimation:animation forKey:nil];
        [frameScrollView.layer addAnimation:animation forKey:nil];
        frameScrollView.hidden = TRUE;
        btnGoHome.hidden = FALSE;
        btnGoEditorMenu.hidden = TRUE;
    }
    else if([applyBtnName isEqualToString:@"Adjust"])
    {
        applyBtn.hidden = YES;
        [contrastSliderView.layer addAnimation:animation forKey:nil];
        [brightnessSliderView.layer addAnimation:animation forKey:nil];
        [saturationSliderView.layer addAnimation:animation forKey:nil];
        [btnGoHome.layer addAnimation:animation forKey:nil];
        [menuScrollView.layer addAnimation:animation forKey:nil];
        
        
        btnGoHome.hidden = FALSE;
        btnGoEditorMenu.hidden = TRUE;
        [contrastSliderView setHidden:YES];
        [saturationSliderView setHidden:YES];
        [brightnessSliderView setHidden:YES];
        imageViewDisplay.image = newimg;
    }
    else if([applyBtnName isEqualToString:@"Filter"]){
        
        [applyBtn setHidden:YES];
        [btnGoHome.layer addAnimation:animation forKey:nil];
        [menuScrollView setHidden:NO];
        [btnGoHome setHidden:NO];
        [btnGoEditorMenu setHidden:YES];
        [filterScrollView setHidden:YES];
        [frameScrollView setHidden:YES];
    }
    else if([applyBtnName isEqualToString:@"Blur"]){
        [applyBtn setHidden:YES];
        [btnGoEditorMenu setHidden:YES];
        [btnGoHome setHidden:NO];
        [brightnessSliderView setHidden:YES];
        [commonSliderLower setHidden:YES];
        [menuScrollView setHidden:NO];
        imageViewDisplay.image = newimg;
        
    }
    else if([applyBtnName isEqualToString:@"Rotate"]){
        [applyBtn setHidden:YES];
        [btnGoEditorMenu setHidden:YES];
        [flipRotateView setHidden:YES];
        [btnGoHome setHidden:NO];
        [menuScrollView setHidden:NO];
    }
    else if([applyBtnName isEqualToString:@"Resize"]){
        [applyBtn setHidden:YES];
        [btnGoEditorMenu setHidden:YES];
        [btnGoHome setHidden:NO];
        [menuScrollView setHidden:NO];
    }
    else if([applyBtnName isEqualToString:@"Sticker"]){
        [applyBtn setHidden:YES];
        [btnGoEditorMenu setHidden:YES];
        [btnGoHome setHidden:NO];
        [menuScrollView setHidden:NO];
        [stickerScrollView setHidden:YES];
        [stickerOptionView setHidden:YES];
        [closeVw setHidden:YES];
        [resizeVw setHidden:YES];
        [rotateVw setHidden:YES];
         imgvw.layer.borderColor = [[UIColor clearColor]CGColor];
        
    }
    else if([applyBtnName isEqualToString:@"Text"]){
        [applyBtn setHidden:YES];
        [btnGoEditorMenu setHidden:YES];
        [btnGoHome setHidden:NO];
        [menuScrollView setHidden:NO];
        [textManageView setHidden:YES];
        [viewTextOptions setHidden:NO];
    }
    
    UIAlertView *message = [[UIAlertView alloc] initWithTitle:@""
                                                      message:@"Do you want to save ?"
                                                     delegate:self
                                            cancelButtonTitle:@"Yes"
                                            otherButtonTitles:@"No", nil];
    message.tag = 1;
    
    [message show];
    
    
    

}

#pragma mark - Adjustment Slider Value Changed(Contrast, Saturation, Brightness)

- (IBAction)contrastSliderValueChanged:(id)sender {
    
    filter=NULL;
    result=NULL;
    cgimg=NULL;
    newimg=NULL;
    
    
    
    if (adjustMenuTag==1) {
        
        filter=[CIFilter filterWithName:@"CIColorControls"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:contrastSlider.value] forKey:@"inputBrightness"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
       
        
        imageViewDisplay.image=newimg;
        CFRelease(cgimg);
        
    } else if(adjustMenuTag ==2 ) {
        
        filter=[CIFilter filterWithName:@"CIColorControls"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:contrastSlider.value+0.5] forKey:@"inputContrast"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
        imageViewDisplay.image=newimg;
        CFRelease(cgimg);
    }
    else if (adjustMenuTag==3)
    {
        filter=[CIFilter filterWithName:@"CIColorControls"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:contrastSlider.value*2] forKey:@"inputSaturation"] ;
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg=[context createCGImage:result fromRect:[result extent]];
        newimg=[UIImage imageWithCGImage:cgimg];
        imageViewDisplay.image=newimg;
        CFRelease(cgimg);
    }
    else if (adjustMenuTag == 4)
    {
        
        filter = [CIFilter filterWithName:@"CIGaussianBlur"];
        [filter setDefaults];
        [filter setValue:beginImage forKey:@"inputImage"];
        [filter setValue:[NSNumber numberWithFloat:contrastSlider.value+0.5] forKey:@"inputRadius"];
        result=[filter valueForKey:kCIOutputImageKey];
        cgimg = [context createCGImage:result fromRect:[result extent]];
        newimg = [UIImage imageWithCGImage:cgimg];
        imageViewDisplay.image = newimg;
        CFRelease(cgimg);
    }
    
}

- (IBAction)saturationSliderValueChanged:(id)sender
{
    
}

- (IBAction)brightnessSliderValueChanged:(id)sender
{
    
}

#pragma mark - Common Sliders

- (IBAction)sliderLowerValueChanged:(id)sender
{
    
}
- (IBAction)doRotate:(id)sender
{
    
   // UIImageOrientation orientation;
    UIGraphicsBeginImageContext(newimg.size);
     
     CGContextRef context1 = UIGraphicsGetCurrentContext();
     
     if (newimg.imageOrientation == UIImageOrientationRight) {
         imageViewDisplay.transform = CGAffineTransformMakeRotation(M_PI/180 * 90);
     } else if (newimg.imageOrientation == UIImageOrientationLeft) {
         CGContextRotateCTM (context1,(-90 * M_PI/180));
     } else if (newimg.imageOrientation == UIImageOrientationDown) {
         // NOTHING
     } else if (newimg.imageOrientation == UIImageOrientationUp) {
         imageViewDisplay.transform = CGAffineTransformMakeRotation(M_PI/180 * 90);
     }
     
     [newimg drawAtPoint:CGPointMake(0, 0)];
     
     newimg = UIGraphicsGetImageFromCurrentImageContext();
    imageViewDisplay.image = newimg;
}

- (IBAction)doFlipHorizontal:(id)sender
{
    
     imageViewDisplay.image=[self flipImageUpDown:newimg];
    
}
- (IBAction)doFlipVertical:(id)sender
{
    
    imageViewDisplay.image=[self flipImageLeftRight:newimg];
}
#pragma mark flip images

- (UIImage *) flipImageLeftRight:(UIImage *)originalImage {
    UIImageView *tempImageView = [[UIImageView alloc] initWithImage:imageViewDisplay.image];
    
    UIGraphicsBeginImageContext(tempImageView.frame.size);
    CGContextRef contexts = UIGraphicsGetCurrentContext();
    
    CGAffineTransform flipHorizontal = CGAffineTransformMake(-1.0, 0.0, 0.0, 1.0, tempImageView.frame.size.width,0.0);
    
    
    CGContextConcatCTM(contexts, flipHorizontal);
    
    [tempImageView.layer renderInContext:contexts];
    
    UIImage *flipedImage = UIGraphicsGetImageFromCurrentImageContext();
    //flipedImage = [UIImage imageWithCGImage:flipedImage.CGImage scale:1.0 orientation:UIImageOrientationDownMirrored];
    UIGraphicsEndImageContext();
    [UIView transitionWithView:imageViewDisplay duration:0.5 options:UIViewAnimationOptionTransitionFlipFromLeft animations:^{imageViewDisplay.image = newimg;} completion:nil];

    
    return flipedImage;
}

- (UIImage *) flipImageUpDown:(UIImage *)originalImage
{
    UIImageView *tempImageView = [[UIImageView alloc] initWithImage:imageViewDisplay.image];
    
    UIGraphicsBeginImageContext(tempImageView.frame.size);
    CGContextRef contexts = UIGraphicsGetCurrentContext();
    
    CGAffineTransform flipVertical = CGAffineTransformMake(
                                                           1, 0,
                                                           0, -1,
                                                           0, tempImageView.frame.size.height
                                                           );
    CGContextConcatCTM(contexts, flipVertical);
    
    [tempImageView.layer renderInContext:contexts];
    
    UIImage *flipedImage = UIGraphicsGetImageFromCurrentImageContext();
    //flipedImage = [UIImage imageWithCGImage:flipedImage.CGImage scale:1.0 orientation:UIImageOrientationUp];
    UIGraphicsEndImageContext();
    
    [UIView transitionWithView:imageViewDisplay duration:0.5 options:UIViewAnimationOptionTransitionFlipFromBottom animations:^{imageViewDisplay.image = newimg;} completion:nil];
    return flipedImage;
}


- (IBAction)showBrightnessSlider:(id)sender {
    //adjsutMenuTag = [[NSInteger alloc]init];
    adjustMenuTag = 1;
    //Change Lable Color
    [lblBrightness setTextColor:[UIColor redColor]];
    [lblContrast setTextColor:[UIColor whiteColor]];
    [lblSaturation setTextColor:[UIColor whiteColor]];
    [lblBlur setTextColor:[UIColor whiteColor]];
    
    //Set Slider Value
    [contrastSlider setValue:0.0f];
    [contrastSlider setMinimumValue:0.0f];
    [contrastSlider setMaximumValue:1.0f];
}
- (IBAction)showContrastSlider:(id)sender {
    adjustMenuTag = 2;
    
    //Change Lable Color
    [lblBrightness setTextColor:[UIColor whiteColor]];
    [lblContrast setTextColor:[UIColor redColor]];
    [lblSaturation setTextColor:[UIColor whiteColor]];
    [lblBlur setTextColor:[UIColor whiteColor]];
    
    //Set Slider Value
    
    [contrastSlider setValue:0.2f];
    [contrastSlider setMinimumValue:0.0f];
    [contrastSlider setMaximumValue:1.0f];
}
- (IBAction)showBlurSlider:(id)sender {
    adjustMenuTag = 4;
    
    //Change Lable Color
    [lblBrightness setTextColor:[UIColor whiteColor]];
    [lblContrast setTextColor:[UIColor whiteColor]];
    [lblSaturation setTextColor:[UIColor whiteColor]];
    [lblBlur setTextColor:[UIColor redColor]];
    
    //Set Slider Value
    [contrastSlider setValue:5.0f];
    [contrastSlider setMinimumValue:0.0f];
    [contrastSlider setMaximumValue:30.0f];
    
    
}
- (IBAction)showSaturationSlider:(id)sender {
    adjustMenuTag = 3;
    
    //Change Lable Color
    [lblBrightness setTextColor:[UIColor whiteColor]];
    [lblContrast setTextColor:[UIColor whiteColor]];
    [lblSaturation setTextColor:[UIColor redColor]];
    [lblBlur setTextColor:[UIColor whiteColor]];
    
    //Set Slider Value
    
    [contrastSlider setValue:0.2f];
    [contrastSlider setMinimumValue:0.0f];
    [contrastSlider setMaximumValue:1.0f];
}

@end
