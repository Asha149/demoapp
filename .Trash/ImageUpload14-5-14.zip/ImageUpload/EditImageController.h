//
//  EditImageController.h
//  ImageUpload
//
//  Created by lanetteam on 12/02/14.
//  Copyright (c) 2014 Gaurav Parvadiya. All rights reserved.
//
#import <UIKit/UIKit.h>

#import "FCColorPickerViewController.h"
#import <AVFoundation/AVFoundation.h>
#import "TickleGestureRecognizer.h"
@interface EditImageController : UIViewController <UIGestureRecognizerDelegate, UITableViewDataSource, UITableViewDelegate,UITextFieldDelegate,FCColorPickerViewControllerDelegate,UIAlertViewDelegate, UIGestureRecognizerDelegate>

{
    //UIView *testVw;
    
    UIImageView *resizeVw;
    UIImageView *imgvw;
    UIImageView *rotateVw;
    UIImageView *closeVw;
    
    float deltaAngle;
    CGPoint prevPoint;
    CGAffineTransform startTransform;
    
    CATransition *animation;
    int adjustMenuTag;
    NSArray *familyNames;
    NSArray *fontNames,*fontSize;
    NSMutableArray *indFontNames;
    NSInteger indFamily, indFont, tag;
    NSMutableArray *imagearry;
}


@property (strong, nonatomic) IBOutlet UIPinchGestureRecognizer *pinchSticker;
@property (strong, nonatomic) IBOutlet UIPinchGestureRecognizer *pinchImage;

//Bind From xib

- (IBAction)handlePan:(UIPanGestureRecognizer *)recognizer;
@property (strong, nonatomic) IBOutlet UIImageView *imageViewFrame;
@property (strong, nonatomic) IBOutlet UIView *bottomView;
@property (strong, nonatomic) IBOutlet UIImageView *imageViewDisplay;
@property (strong, nonatomic) IBOutlet UIScrollView *menuScrollView;
@property (strong, nonatomic) IBOutlet UIScrollView *frameScrollView;
@property (strong, nonatomic) IBOutlet UIView *viewScrollBottom;
@property (strong, nonatomic) IBOutlet UIView *viewHeader;
@property (strong, nonatomic) IBOutlet UIButton *btnGoHome;
@property (strong, nonatomic) IBOutlet UIButton *btnGoEditorMenu;
@property (assign, nonatomic) CATransform3D initialTransformation;
@property (nonatomic,retain) IBOutlet UILabel *lblText;
@property (nonatomic,retain) IBOutlet UIButton *btnCross;
@property (nonatomic,retain) IBOutlet UIButton *btnedit;
@property (nonatomic,retain) IBOutlet UIImageView *imgCurrent;
@property (nonatomic,retain) NSMutableArray *sticker_icon_name;
- (IBAction)goHome:(id)sender;
- (IBAction)goEditorMenu:(id)sender;
- (void)handleTap:(UITapGestureRecognizer *)recognizer;
@property (strong, nonatomic) IBOutlet UIButton *applyBtn;
- (IBAction)applyDone:(id)sender;
@property (strong, nonatomic) IBOutlet UISlider *brightnessSlider;
@property (strong, nonatomic) IBOutlet UISlider *saturationSlider;
@property (strong, nonatomic) IBOutlet UISlider *contrastSlider;
@property (strong, nonatomic) IBOutlet UIView *contrastSliderView;
@property (strong, nonatomic) IBOutlet UIView *saturationSliderView;
@property (strong, nonatomic) IBOutlet UIView *brightnessSliderView;
@property (nonatomic,retain) IBOutlet UIView *viewTextfield;

- (IBAction)contrastSliderValueChanged:(id)sender;
- (IBAction)saturationSliderValueChanged:(id)sender;
- (IBAction)brightnessSliderValueChanged:(id)sender;

@property (strong, nonatomic) IBOutlet UIScrollView *filterScrollView;
@property (strong, nonatomic) IBOutlet UISlider *commonSliderLower;
- (IBAction)sliderLowerValueChanged:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnRotate;
- (IBAction)doRotate:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnFlipHorizontal;
- (IBAction)doFlipHorizontal:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnFlipVertical;
- (IBAction)doFlipVertical:(id)sender;
@property (strong, nonatomic) IBOutlet UIView *flipRotateView;
@property (strong, nonatomic) IBOutlet UIScrollView *stickerScrollView;
@property (strong, nonatomic) IBOutlet UIView *stickerOptionView;
@property (strong, nonatomic) IBOutlet UILabel *lblStickerOptionTitle;
@property (strong, nonatomic) IBOutlet UIScrollView *stickerIconScrollView;
- (IBAction)showBrightnessSlider:(id)sender;
@property (strong, nonatomic) IBOutlet UIButton *btnBrightness;
@property (strong, nonatomic) IBOutlet UIButton *btnContrast;
@property (strong, nonatomic) IBOutlet UIButton *btnSaturation;
@property (strong, nonatomic) IBOutlet UIButton *btnBlur;
- (IBAction)showContrastSlider:(id)sender;
- (IBAction)showBlurSlider:(id)sender;
- (IBAction)showSaturationSlider:(id)sender;
@property (strong, nonatomic) IBOutlet UILabel *lblBrightness;
@property (strong, nonatomic) IBOutlet UILabel *lblContrast;
@property (strong, nonatomic) IBOutlet UILabel *lblSaturation;
@property (strong, nonatomic) IBOutlet UILabel *lblBlur;
@property (strong, nonatomic) IBOutlet UIView *viewAdjustOptions;
@property (strong, nonatomic) IBOutlet UITableView *tableViewFontName;
@property (weak, nonatomic) IBOutlet UIView *textManageView;
- (IBAction)changeFontStyle:(id)sender;
- (IBAction)changeFontSize:(id)sender;
- (IBAction)changeFontColor:(id)sender;
@property (weak, nonatomic) IBOutlet UIView *viewTextOptions;
@property (weak, nonatomic) IBOutlet UITextField *textFieldText;
@property (strong, nonatomic) IBOutlet UITableView *tableViewFontStyle;
@property (nonatomic,retain) IBOutlet UIButton *btnCloseSticker;


//Extra Properties
@property (strong,nonatomic) UIImage *originalImage;
@property (strong,nonatomic) NSString *cancelBtnName;
@property (strong,nonatomic) NSString *applyBtnName;
@property (strong,nonatomic) CIFilter *filter;
@property (assign,nonatomic) CGImageRef cgimg;
@property (strong,nonatomic) CIImage *result;
@property (strong,nonatomic) UIImage *newimg;
@property (strong,nonatomic) CIImage *beginImage;
@property (strong,nonatomic) CIContext *context;
@property (strong,nonatomic) UIImage *filterTempImage;
@property (retain,nonatomic) UIImage *lastSavedImage;
@property (nonatomic) NSInteger *adjsutMenuTag;


@end
