//
//  FCBrightDarkGradView.h
//  ColorPicker
//
//  Created by Fabián Cañas
//  Copyright 2010-2014. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface FCBrightDarkGradView : UIView

@property (readwrite,nonatomic,copy) UIColor *color;

@end
