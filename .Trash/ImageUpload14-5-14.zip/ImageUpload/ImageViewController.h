//
//  ImageViewController.h
//  ImageUpload
//
//  Created by LaNet Team on 16/01/14.
//  Copyright (c) 2014 Gaurav Parvadiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface ImageViewController : UIViewController <UIActionSheetDelegate, UINavigationControllerDelegate, UIImagePickerControllerDelegate , UIGestureRecognizerDelegate>

- (IBAction)addImage:(id)sender;
- (IBAction)editSample:(id)sender;
- (IBAction)btnLike_click:(id)sender;
- (IBAction)btnSetting_click:(id)sender;

@property (strong, nonatomic) IBOutlet UIButton *btnAddImage;
@property (strong, nonatomic) IBOutlet UIButton *btnEditImage;

@property (strong, nonatomic) IBOutlet UIView *viewHeader;
@property (strong, nonatomic) IBOutlet UIImageView *geaderBgImageView;
@property (strong, nonatomic) IBOutlet UIButton *btnSetting;
@property (strong, nonatomic) IBOutlet UIButton *btnDone;

@property (strong, nonatomic) IBOutlet UIView *customActionSheetView;

@property (strong, nonatomic) IBOutlet UIButton *btnNewUpload;
@property (strong, nonatomic) IBOutlet UIButton *btnEdit;
@property (strong, nonatomic) IBOutlet UIButton *btnCancel;
- (IBAction)hideActionSheetView:(id)sender;
- (IBAction)takeNewPhotoFromCamera:(id)sender;
- (IBAction)choosePhotoFromExistingImages:(id)sender;

@end
