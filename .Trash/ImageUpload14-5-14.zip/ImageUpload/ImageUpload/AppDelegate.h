//
//  AppDelegate.h
//  ImageUpload
//
//  Created by LaNet Team on 16/01/14.
//  Copyright (c) 2014 Gaurav Parvadiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AppDelegate : UIResponder <UIApplicationDelegate>

@property (strong, nonatomic) UIWindow *window;
@property (strong,nonatomic) UINavigationController *nav;

@end
