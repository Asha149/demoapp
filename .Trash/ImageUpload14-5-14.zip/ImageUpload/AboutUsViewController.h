//
//  AboutUsViewController.h
//  ImageUpload
//
//  Created by ajeet Singh on 24/04/14.
//  Copyright (c) 2014 Gaurav Parvadiya. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface AboutUsViewController : UIViewController
@property (nonatomic,retain) IBOutlet UIButton *btnhome;

-(IBAction)btnHome_click:(id)sender;
@end
