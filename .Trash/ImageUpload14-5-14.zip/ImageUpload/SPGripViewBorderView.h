//
//  SPGripViewBorderView.h
//
//  Created by Seonghyun Kim on 6/3/13.
//  Copyright (c) 2013 scipi. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SPGripViewBorderView : UIView

@end
