<?php


if (!$link = mysql_connect('localhost', 'root', '')) {
    echo 'Could not connect to mysql';
    exit;
}

if (!mysql_select_db('TempAbc', $link)) {
    echo 'Could not select database';
    exit;
}

$query="select entity_id from customer_entity where email='".$_GET['email']."' and  entity_id in(SELECT entity_id FROM `customer_entity_varchar` WHERE value=md5('".$_GET['password']."'))";


$result = mysql_query ($query,$link) or die ("Could not execute the query." . mysql_error());
    //$nrows = mysql_num_rows ($result);
    //while ($row = mysql_fetch_assoc($result))
    
    while ($row = mysql_fetch_assoc($result))
    {
        $output[] = $row;
    }
    mysql_free_result($result);
    
    //print_r($output);
    print(json_encode(($output)));

 ?>
