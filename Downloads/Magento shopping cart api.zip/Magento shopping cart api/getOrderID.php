<?php
    session_start();
    header('Content-type: application/json');
$host = "http://localhost/project01/index.php";
$user = 'nirmal';
$password = '123456789@10';
$proxy = new SoapClient($host."/api/v2_soap/?wsdl");
$sessionId = $proxy->login($user, $password);
$cartId = $_GET['cart_id'];
// load the customer list and select the first customer from the list
$customerList = $proxy->customerCustomerList($sessionId, array());
$customer = (array) $customerList[0];
$customer['mode'] = 'customer';
$proxy->shoppingCartCustomerSet($sessionId, $cartId, $customer);
// load the product list and select the first product from the list
$productList = $proxy->catalogProductList($sessionId);
$product = (array) $productList[0];
$product['qty'] = 1;
$proxy->shoppingCartProductAdd($sessionId, $cartId, array($product));
    $fname = $_GET['fname'];
    $lname = $_GET['lname'];
    $street = $_GET['street'];
    $city = $_GET['city'];
    $regions = $_GET['state'];
    $telephone = $_GET['tele'];
    $postcode = $_GET['postcode'];
    $country = $_GET['country'];
    $paymentmethod = $_GET['Pmethod'];
    $ShippingMethod = $_GET['Smethod'];
    
    $Sfname = $_GET['Sfname'];
    $Slname = $_GET['Slname'];
    $Sstreet = $_GET['Sstreet'];
    $Scity = $_GET['Scity'];
    $Sregions = $_GET['Sstate'];
    $Stelephone = $_GET['Stele'];
    $Spostcode = $_GET['Spostcode'];
    $Scountry = $_GET['Scountry'];
    
try
{
$address = array(
                 array(
                       'mode' => 'shipping',
                       'firstname' => $fname,
                       'lastname' => $lname,
                       'street' => $street,
                       'city' => $city,
                       'region' => $regions,
                       'telephone' => $telephone,
                       'postcode' => $postcode,
                       'country_id' => $country,
                       'is_default_shipping' => 0,
                       'is_default_billing' => 0
                       ),
                 array(
                       'mode' => 'billing',
                       'firstname' => $Sfname,
                       'lastname' => $Slname,
                       'street' => $Sstreet,
                       'city' => $Scity,
                       'region' => $Sregions,
                       'telephone' => $Stelephone,
                       'postcode' => $Spostcode,
                       'country_id' => $Scountry,
                       'is_default_shipping' => 0,
                       'is_default_billing' => 0
                       ),
                 );
// add customer address
$proxy->shoppingCartCustomerAddresses($sessionId, $cartId, $address);
// add shipping method
$proxy->shoppingCartShippingMethod($sessionId, $cartId,$ShippingMethod );

$paymentMethod =  array(
                        'po_number' => null,
                        'method' => $paymentmethod,
                        'cc_cid' => null,
                        'cc_owner' => null,
                        'cc_number' => null,
                        'cc_type' => null,
                        'cc_exp_year' => null,
                        'cc_exp_month' => null
                        );
// add payment method
$proxy->shoppingCartPaymentMethod($sessionId, $cartId, $paymentMethod);
// place the order
$orderId = $proxy->shoppingCartOrder($sessionId, $cartId, null, null);

$array1=array();
$array1['order_id']=$orderId;

echo json_encode($array1);

}
catch (Exception $e)
{
    echo "==> Error: ".$e->getMessage();
    exit();
}
    exit;
?>