<?php
session_start();
    header('Content-type: application/json');
    $host = "http://localhost/project01/index.php";
    $client = new SoapClient($host."/api/soap/?wsdl");
    $apiuser= "nirmal";
    $apikey = "123456789@10";
    $action = "catalog_category.tree";
    try
    {
        $sess_id= $client->login($apiuser, $apikey);
        $result = $client->call($sess_id, $action);
        echo json_encode($result);
    }
    catch (Exception $e)
    {
        echo "==> Error: ".$e->getMessage();
        exit();
    }
exit;
?>
