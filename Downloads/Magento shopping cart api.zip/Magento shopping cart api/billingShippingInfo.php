<?php
    session_start();
    
    //echo json_encode(array('UserDetail'=>$posts,"ResponseCode"=>"1","ResponseMsg"=> "Sucessful Transaction"));
    header('Content-type: application/json');
    $host = "http://localhost/project01/index.php";
    $client = new SoapClient($host."/api/soap/?wsdl");
    $apiuser= "nirmal";
    $apikey = "123456789@10";
    $action = "catalog_category.tree"; //an action to call later (loading Sales Order List)
    try {
        
        $sess_id= $client->login($apiuser, $apikey); //we do login
        
        
        
        $arrAddresses = array(
                              array(
                                    "mode" => "shipping",
                                    "firstname" => $_GET['fname'],
                                    "lastname" => $_GET['lname'],
                                    "company" => $_GET['company'],
                                    "street" => $_GET['street'],
                                    "city" => $_GET['city'],
                                    "region" => $_GET['region'],
                                    "postcode" => $_GET['zipCode'],
                                    "country_id" => $_GET['country'],
                                    "telephone" => $_GET['telephone'],
                                    "fax" => $_GET['fax'],
                                    "is_default_shipping" => 0,
                                    "is_default_billing" => 0
                                    ),
                              array(
                                    "mode" => "billing",
                                    "address_id" => 1
                                            )

                              
                              );
        
        $resultCustomerAddresses = $client->call(
                                                 $sess_id,
                                                 "cart_customer.addresses",
                                                 array(
                                                       $_GET['cart_id'],
                                                       $arrAddresses,
                                                       )
                                                 );
        
		echo json_encode($resultCustomerAddresses);
     	//echo json_encode($resultCartProductAdd);
    }
    catch (Exception $e) { //while an error has occured
        echo "==> Error: ".$e->getMessage(); //we print this
        exit();
    }
    exit;
    ?>