<?php
    session_start();
    header('Content-type: application/json;charset=utf-8');
    //echo json_encode(array('UserDetail'=>$posts,"ResponseCode"=>"1","ResponseMsg"=> "Sucessful Transaction"));
    $host = "http://localhost/project01/index.php";
    $client = new SoapClient($host."/api/soap/?wsdl");
    $apiuser= "nirmal";
    $apikey = "123456789@10";
    $action = "catalog_category.tree"; //an action to call later (loading Sales Order List)
    try {
        
        $sess_id= $client->login($apiuser, $apikey); //we do login
        $result = $client->call($sess_id, 'catalog_category.assignedProducts',$_GET['cid']);
        //$result = $client->call($sess_id, 'catalog_product_attribute_media.list', '151');
        
        $prod_info=array();
        for($i=0;$i<count($result);$i++){
                       $pid=$result[$i]['product_id'];
                       $result1 = $client->call($sess_id, 'catalog_product.info',$pid);
                       $prod_info[$i]["ProductDetail"]=$result1;
            
            $result2 = $client->call($sess_id, 'catalog_product_attribute_media.list', $pid);
            $prod_info[$i]["ProductImage"]=$result2;
        }
        echo json_encode($prod_info);
		
    }
    catch (Exception $e) { //while an error has occured
        echo "==> Error: ".$e->getMessage(); //we print this
        exit();
    }
    //exit;
?>

