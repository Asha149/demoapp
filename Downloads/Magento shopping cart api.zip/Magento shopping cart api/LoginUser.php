<?php
    session_start();
    
    //echo json_encode(array('UserDetail'=>$posts,"ResponseCode"=>"1","ResponseMsg"=> "Sucessful Transaction"));
    header('Content-type: application/json');
    $host = "http://localhost/project01/index.php";
    $client = new SoapClient($host."/api/soap/?wsdl");
    $apiuser= "nirmal";
    $apikey = "123456789@10";
    $action = "catalog_category.tree"; //an action to call later (loading Sales Order List)
    try {
        
        $sess_id= $client->login($apiuser, $apikey); //we do login
        $email = $_GET['email'];
       // $password = $_GET['pwd'];
       // $pwd = md5($password);
        //$has = crypt($pwd,$password);
        $array1=array();
      //  $array1['response']=0;
       $result = $client->call($sess_id, 'customer.list');
        for($i=0;$i< count($result);$i++)
        {
            if(($result[$i]['email'] == $email))
            {
                
                $array1['response']=1;
                echo json_encode($result[$i]);
            }
        }
		
    }
    catch (Exception $e) { //while an error has occured
        echo "==> Error: ".$e->getMessage(); //we print this
        exit();
    }
    exit;
    ?>
