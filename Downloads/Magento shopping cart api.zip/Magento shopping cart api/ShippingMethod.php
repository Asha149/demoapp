<?php
    session_start();
    
    //echo json_encode(array('UserDetail'=>$posts,"ResponseCode"=>"1","ResponseMsg"=> "Sucessful Transaction"));
    header('Content-type: application/json');
    $host = "http://localhost/project01/index.php";
    $client = new SoapClient($host."/api/soap/?wsdl");
    $apiuser= "nirmal";
    $apikey = "123456789@10";
    $action = "catalog_category.tree"; //an action to call later (loading Sales Order List)
    try {
        
        $sess_id= $client->login($apiuser, $apikey); //we do login

        
       	$result = $client->call($sess_id, 'cart_shipping.list', $_GET['cart_id']	);
        
        echo json_encode($result);
     	//echo json_encode($resultCartProductAdd);
    }
    catch (Exception $e) { //while an error has occured
        echo "==> Error: ".$e->getMessage(); //we print this
        exit();
    }
    exit;
    ?>