<?php
    session_start();
    
    //echo json_encode(array('UserDetail'=>$posts,"ResponseCode"=>"1","ResponseMsg"=> "Sucessful Transaction"));
    header('Content-type: application/json');
    $host = "http://localhost/project01/index.php";
    $client = new SoapClient($host."/api/soap/?wsdl");
    $apiuser= "nirmal";
    $apikey = "123456789@10";
    $action = "catalog_category.tree"; //an action to call later (loading Sales Order List)
    try {
        
        $sess_id= $client->login($apiuser, $apikey); //we do login
        
        
        
        $resultOrderCreation = $client->call(
                                             $sess_id,
                                             'cart.info', 33
                                             );

        $array1=array();
        $array1['result']=$resultOrderCreation;
        
		echo json_encode($resultOrderCreation);
        //print_r($array1);
        
     	//echo json_encode($resultCartProductAdd);
    }
    catch (Exception $e) { //while an error has occured
        echo "==> Error: ".$e->getMessage(); //we print this
        exit();
    }
    exit;
    ?>